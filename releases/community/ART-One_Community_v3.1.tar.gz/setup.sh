#!/bin/bash

# Script para configurar/desinstalar/actualizar el servidor ART-One Enterprise Command and Control (Ver. 2.2.1)
# Creadores: Adrián Gisbert, Ramón Frizat
# Ejecutar con sudo: sudo ./setup.sh [-d dominio] [-u] [-a] [-h] [--docker]

# Estilo y colores
RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
CYAN='\033[1;36m'
GRAY='\033[1;90m'
NC='\033[0m'

# Logo estilizado
LOGO=$(cat << 'EOF'
     █████╗ ██████╗ ████████╗    ██████╗ ███╗   ██╗███████╗
    ██╔══██╗██╔══██╗╚══██╔══╝    ██║ ██║ ████╗  ██║██╔════╝
    ███████║██████╔╝   ██║       ██║ ██║ ██╔██╗ ██║█████╗  
    ██╔══██║██╔══██╗   ██║       ██║ ██║ ██║╚██╗██║██╔══╝  
    ██║  ██║██║  ██║   ██║       ██████║ ██║ ╚████║███████╗
    ╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝        ╚════╝ ╚═╝  ╚═══╝╚══════╝
EOF
)

# Información del proyecto
VERSION="2.2.1"
CREATORS=(
    "Adrián Gisbert|https://www.linkedin.com/in/sr-gisbert/"
    "Ramón Frizat|https://www.linkedin.com/in/ramonfrizat/"
)
# Establecer PROJECT_DIR como el directorio desde donde se ejecuta el script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$SCRIPT_DIR"
VENV_DIR="$PROJECT_DIR/venv"
PROJECT_DEST="/var/www/html/artone"
SETUP_MARKER="/etc/artone/.installed"
APACHE_CONF_DIR="/etc/apache2/sites-available"
APACHE_ENABLED_DIR="/etc/apache2/sites-enabled"
LOG_FILE="/var/log/artone_setup.log"
UPDATE_URL="https://artone.site/updates"
PYTHON_DEPS="quart hypercorn aiosqlite bcrypt colorama pyotp qrcode requests cryptography psutil croniter reportlab aiohttp rich appdirs"
MIN_PYTHON_VERSION="3.8"
REQUIRED_PORTS=(80 4135 8443)
MIN_DISK_SPACE_MB=500
DOCKER_IMAGE_NAME="artone-c2"
DOCKER_CONTAINER_NAME="artone-c2-container"

# Valores predeterminados
DEFAULT_DOMAIN="art-one.site"
DOMAIN=""
UNINSTALL=false
UPDATE=false
USE_DOCKER=false

# Función para registrar mensajes en el log
log_message() {
    local level=$1
    local message=$2
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [$level] $message" >> "$LOG_FILE"
}

# Función para limpiar la pantalla
clear_screen() {
    clear
    echo -e "${CYAN}$LOGO${NC}"
    echo -e "${BLUE}══════════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}  ART-One Enterprise  (Ver. $VERSION)  ${NC}"
    echo
    echo -e "${GRAY}  Creadores:${NC}"
    echo -e "${GRAY}  ┌─────────────────────────────────────────────────────────────────────┐${NC}"
    for creator in "${CREATORS[@]}"; do
        name=$(echo "$creator" | cut -d'|' -f1)
        link=$(echo "$creator" | cut -d'|' -f2)
        printf "${GRAY}  │ %-20s │ ${CYAN}%-25s${GRAY} │${NC}\n" "$name" "$link"
    done
    echo -e "${GRAY}  └─────────────────────────────────────────────────────────────────────┘${NC}"
    echo -e "${BLUE}══════════════════════════════════════════════════════════════${NC}"
}

# Función para mostrar términos y condiciones
display_terms_and_conditions() {
    clear_screen
    echo -e "${CYAN}📜 Términos y Condiciones de ART-One Enterprise Command and Control (Versión $VERSION)${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════════════════════════${NC}"
    echo -e "${YELLOW}1. Introducción${NC}"
    echo -e "ART-One Enterprise Command and Control (en adelante \"ART-One\"), se encuentra en fase BETA y es propiedad de [Nombre de la Empresa]."
    echo -e "Su uso está estrictamente reservado para fines éticos y legales, incluyendo pruebas de seguridad autorizadas, auditorías y actividades de investigación."
    echo -e "Cualquier utilización no autorizada o malintencionada queda expresamente prohibida y podrá dar lugar a responsabilidades civiles o penales."
    echo -e ""
    echo -e "${YELLOW}2. Concesión de Licencia${NC}"
    echo -e "- Se le otorga una licencia personal, no exclusiva, intransferible y revocable para usar ART-One."
    echo -e "- No adquiere derechos de propiedad intelectual ni titularidad sobre el software."
    echo -e ""
    echo -e "${YELLOW}3. Requisitos del Sistema${NC}"
    echo -e "Para un funcionamiento óptimo de ART-One, usted debe contar con:"
    echo -e "  • Sistema operativo: Distribución Linux compatible (Debian, Ubuntu, CentOS o similar)."
    echo -e "  • Puertos abiertos: Asegúrese de que los puertos TCP/UDP configurados en el software estén abiertos en el firewall."
    echo -e "  • IP Pública fija: El servidor debe disponer de una dirección IP estática asignada."
    echo -e "  • Dominio: Debe tener un nombre de dominio válido apuntando a la IP pública del servidor."
    echo -e ""
    echo -e "${YELLOW}4. Uso Permitido${NC}"
    echo -e "- Pruebas de intrusión y penetración con autorización previa del propietario del sistema."
    echo -e "- Evaluaciones de seguridad en entornos controlados y de laboratorio."
    echo -e "- Propósitos educativos y de investigación, siempre que se cumplan las leyes aplicables."
    echo -e ""
    echo -e "${YELLOW}5. Restricciones${NC}"
    echo -e "- Prohibida la reventa, sublicencia, distribución o comercialización de ART-One sin el consentimiento expreso de los autores."
    echo -e "- No se permite ingeniería inversa, descompilación, desensamblado o análisis del código, salvo cuando la ley lo permita."
    echo -e "- Queda prohibido el uso de ART-One para actividades maliciosas, no éticas o ilegales."
    echo -e ""
    echo -e "${YELLOW}6. Terminación de la Licencia${NC}"
    echo -e "El incumplimiento de cualquiera de los términos de este acuerdo provocará la terminación inmediata de la licencia."
    echo -e "Al finalizar la licencia, usted deberá cesar el uso y eliminar todas las copias de ART-One de cualquier dispositivo."
    echo -e ""
    echo -e "${YELLOW}7. Renuncia de Garantías${NC}"
    echo -e "ART-One se proporciona \"TAL CUAL\" y \"SEGÚN DISPONIBILIDAD\"."
    echo -e "Los autores no ofrecen garantías de ningún tipo, ya sean implícitas o explícitas, incluyendo, sin limitación, garantías de comerciabilidad, idoneidad para un propósito particular o no infracción."
    echo -e ""
    echo -e "${YELLOW}8. Limitación de Responsabilidad${NC}"
    echo -e "En ningún caso los autores serán responsables de daños directos, indirectos, especiales, incidentales o consecuentes,"
    echo -e "incluyendo pérdida de datos, beneficios o interrupción de negocio, incluso si han sido advertidos de la posibilidad de dichos daños."
    echo -e ""
    echo -e "${YELLOW}9. Política de Privacidad${NC}"
    echo -e "- El uso de ART-One puede generar registros (logs) y datos relacionados con la actividad de red."
    echo -e "- Usted es responsable de la gestión, almacenamiento y protección de los datos recopilados."
    echo -e "- No se recopilan datos personales del usuario sin su consentimiento explícito."
    echo -e ""
    echo -e "${YELLOW}10. Soporte y Actualizaciones${NC}"
    echo -e "- ART-One está en fase BETA: puede contener errores o funciones en desarrollo."
    echo -e "- Las actualizaciones estarán disponibles a través del repositorio oficial."
    echo -e "- Para soporte, consulte la documentación o el canal de comunicación oficial."
    echo -e ""
    echo -e "${YELLOW}11. Ley Aplicable y Jurisdicción${NC}"
    echo -e "Este acuerdo se rige por las leyes de España."
    echo -e "Cualquier disputa derivada de este acuerdo será sometida a los tribunales de la ciudad de Madrid."
    echo -e ""
    echo -ne "${CYAN}¿Acepta estos Términos y Condiciones? [s/n]: ${NC}"
    read -n 1 response
    echo ""
    if [[ ! "$response" =~ ^[Ss]$ ]]; then
        echo -e "${RED}🚫 Instalación cancelada. Debe aceptar los Términos y Condiciones para continuar.${NC}"
        log_message "INFO" "Instalación cancelada: Términos y Condiciones no aceptados"
        exit 1
    fi
    echo -e "${GREEN}✔ Términos y Condiciones aceptados${NC}"
    log_message "INFO" "Términos y Condiciones aceptados"
    sleep 2
}

# Función para mostrar ayuda
display_help() {
    clear_screen
    echo -e "${CYAN}📖 Ayuda del Instalador ART-One${NC}"
    echo -e "${BLUE}──────────────────────────────────────────────────────────────${NC}"
    echo -e "${CYAN}Uso:${NC}"
    echo -e "  sudo $0 [-d dominio] [-u] [-a] [-h] [--docker]"
    echo -e "${CYAN}Opciones:${NC}"
    echo -e "  ${YELLOW}-d dominio${NC}  Especifica el dominio (predeterminado: $DEFAULT_DOMAIN)"
    echo -e "  ${YELLOW}-u${NC}        Desinstala ART-One completamente"
    echo -e "  ${YELLOW}-a${NC}        Actualiza los archivos desde $UPDATE_URL"
    echo -e "  ${YELLOW}-h${NC}        Muestra esta ayuda"
    echo -e "  ${YELLOW}--docker${NC}  Instala y ejecuta ART-One en un contenedor Docker"
    echo -e "${CYAN}Descripción:${NC}"
    echo -e "  Configura, desinstala o actualiza el servidor ART-One C2."
    echo -e "  Instala dependencias, configura Apache, y crea el comando 'artone'."
    echo -e "  Con --docker, se ejecuta en un contenedor usando Ubuntu 20.04."
    echo -e "  Usa el comando 'artone' con las mismas opciones (-h, -u, -a) tras la instalación."
    echo -e "${BLUE}──────────────────────────────────────────────────────────────${NC}"
    log_message "INFO" "Panel de ayuda mostrado"
    exit 0
}

# Función para mostrar estado
status() {
    local message=$1
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✔ $message${NC}"
        log_message "INFO" "$message"
    else
        echo -e "${RED}✘ $message${NC}"
        log_message "ERROR" "$message"
        echo -e "${YELLOW}Consulta $LOG_FILE para más detalles.${NC}"
        exit 1
    fi
}

# Función para animación de progreso (sin dependencia de bc)
progress_bar() {
    local message=$1
    local duration=$2
    local width=30
    local fill="█"
    local empty="─"
    local i=0
    echo -ne "${YELLOW}⏳ $message ["
    while [ $i -lt $width ]; do
        echo -ne "$fill"
        sleep 0.1
        ((i++))
    done
    echo -ne "]${NC}\n"
}

# Función para validar dominio
validate_domain() {
    local domain=$1
    [[ "$domain" =~ ^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$ ]]
}

# Función para verificar DNS
check_dns() {
    local domain=$1
    echo -ne "${YELLOW}🔍 Verificando DNS para $domain...${NC}"
    if host "$domain" >/dev/null 2>&1; then
        echo -e "${GREEN} ✔ Resuelve correctamente${NC}"
        log_message "INFO" "DNS para $domain resuelve correctamente"
    else
        echo -e "${YELLOW} ⚠ No resuelve. Continuando sin SSL en el contenedor.${NC}"
        log_message "WARNING" "DNS para $domain no resuelve"
    fi
}

# Función para confirmar acción
confirm_action() {
    local message=$1
    echo -ne "${YELLOW}⚠ $message [s/n]: ${NC}"
    read -n 1 response
    echo ""
    [[ "$response" =~ ^[Ss]$ ]] || [[ -z "$response" ]]
}

# Función para verificar prerrequisitos del sistema
check_prerequisites() {
    clear_screen
    echo -e "${CYAN}🔎 Verificando prerrequisitos del sistema${NC}"
    echo -e "${BLUE}──────────────────────────────────────────────────────────────${NC}"

    # Verificar conexión a internet
    ping -c 1 8.8.8.8 >/dev/null 2>&1
    status "Conexión a internet"

    # Verificar espacio en disco
    local available_space=$(df -m / | tail -1 | awk '{print $4}')
    if [ "$available_space" -lt "$MIN_DISK_SPACE_MB" ]; then
        echo -e "${RED}🚫 Espacio en disco insuficiente ($available_space MB, se requieren $MIN_DISK_SPACE_MB MB)${NC}"
        log_message "ERROR" "Espacio en disco insuficiente"
        exit 1
    fi
    status "Espacio en disco suficiente ($available_space MB)"

    # Verificar versión de Python
    local python_version=$(python3 --version 2>/dev/null | cut -d' ' -f2)
    if [[ ! "$python_version" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
        echo -e "${RED}🚫 Python 3 no está instalado${NC}"
        log_message "ERROR" "Python 3 no está instalado"
        exit 1
    fi
    if [[ "$(printf '%s\n' "$python_version" "$MIN_PYTHON_VERSION" | sort -V | head -n1)" != "$MIN_PYTHON_VERSION" ]]; then
        echo -e "${RED}🚫 Versión de Python $python_version es inferior a la requerida ($MIN_PYTHON_VERSION)${NC}"
        log_message "ERROR" "Versión de Python insuficiente"
        exit 1
    fi
    status "Versión de Python $python_version"

    # Verificar herramientas necesarias (excepto para Docker-only setup)
    if [ "$USE_DOCKER" = false ]; then
        for tool in apache2 certbot python3-pip wget sqlite3 netcat-traditional lsof curl; do
            command -v "$tool" >/dev/null 2>&1
            status "Herramienta $tool instalada"
        done
    else
        for tool in wget sqlite3; do
            command -v "$tool" >/dev/null 2>&1
            status "Herramienta $tool instalada"
        done
    fi

    # Verificar Docker si se usa
    if [ "$USE_DOCKER" = true ]; then
        systemctl is-active --quiet docker || install_docker
        status "Docker daemon activo"
        # Verificar permisos de Docker
        if ! docker info >/dev/null 2>&1; then
            echo -e "${RED}🚫 El usuario no tiene permisos para ejecutar Docker. Añade el usuario al grupo docker: sudo usermod -aG docker \$USER${NC}"
            log_message "ERROR" "Falta de permisos para Docker"
            exit 1
        fi
        status "Permisos de Docker verificados"
    fi
}

# Función para instalar Docker
install_docker() {
    clear_screen
    echo -e "${YELLOW}🐳 Instalando Docker${NC}"
    progress_bar "Instalando Docker" 2
    apt-get update -y
    apt-get install -y docker.io
    systemctl start docker
    systemctl enable docker
    status "Docker instalado y habilitado"
    log_message "INFO" "Docker instalado correctamente"
}

# Función para actualizar archivos
update_files() {
    clear_screen
    echo -e "${CYAN}📥 Actualizando ART-One Ver. $VERSION${NC}"
    confirm_action "🔄 ¿Confirmar actualización de archivos?" || { echo -e "${RED}Actualización cancelada.${NC}"; log_message "INFO" "Actualización cancelada por el usuario"; exit 0; }
    progress_bar "Descargando actualizaciones" 2

    local temp_dir="/tmp/artone_update"
    rm -rf "$temp_dir"
    mkdir -p "$temp_dir"
    local update_file="$temp_dir/update.tar.gz"

    wget -q "$UPDATE_URL" -O "$update_file"
    if [ $? -ne 0 ] || [ ! -f "$update_file" ]; then
        echo -e "${RED}🚫 Error al descargar actualizaciones desde $UPDATE_URL${NC}"
        log_message "ERROR" "Error al descargar actualizaciones"
        exit 1
    fi
    status "Actualizaciones descargadas"

    tar -xzf "$update_file" -C "$temp_dir"
    status "Actualizaciones extraídas"

    # Copiar archivos actualizados
    [ -f "$temp_dir/server" ] && cp "$temp_dir/server" "$PROJECT_DIR/server" && status "Actualizado server"
    [ -d "$temp_dir/templates" ] && cp -r "$temp_dir/templates" "$PROJECT_DIR/" && status "Actualizados templates"
    [ -d "$temp_dir/source" ] && cp -r "$temp_dir/source" "$PROJECT_DIR/" && status "Actualizados source"

    # Actualizar SERVER_IP en artone.db si existe
    if [ -f "$PROJECT_DIR/artone.db" ]; then
        sqlite3 "$PROJECT_DIR/artone.db" "INSERT OR REPLACE INTO config (key, value) VALUES ('SERVER_IP', '$DOMAIN');" && status "SERVER_IP actualizado a $DOMAIN en artone.db" || { echo -e "${RED}✘ Error al actualizar SERVER_IP en artone.db${NC}"; log_message "ERROR" "Fallo al actualizar SERVER_IP"; exit 1; }
    fi

    rm -rf "$temp_dir"
    status "Limpieza completada"

    clear_screen
    echo -e "${GREEN}✔ Actualización completada${NC}"
    echo -e "${BLUE}──────────────────────────────────────────────────────────────${NC}"
    echo -e "${CYAN}Notas:${NC}"
    echo -e "  - Los archivos han sido actualizados en $PROJECT_DIR."
    echo -e "  - Reinicia el servidor con: ${GREEN}sudo artone${NC}"
    echo -e "${BLUE}──────────────────────────────────────────────────────────────${NC}"
    log_message "INFO" "Actualización completada"
    exit 0
}

handle_letsencrypt_certificates() {
    clear_screen
    echo -e "${CYAN}🔍 Gestionando certificados Let's Encrypt${NC}"
    echo -e "${BLUE}──────────────────────────────────────────────────────────────${NC}"

    # Obtener lista de certificados
    local cert_list=($(certbot certificates 2>/dev/null | grep "Certificate Name:" | awk '{print $3}' | sort -u))
    if [ ${#cert_list[@]} -eq 0 ]; then
        echo -e "${YELLOW}⚠ No se encontraron certificados Let's Encrypt${NC}"
        log_message "INFO" "No se encontraron certificados Let's Encrypt"
        return
    fi

    echo -e "${CYAN}Certificados encontrados:${NC}"
    for i in "${!cert_list[@]}"; do
        echo -e "  ${YELLOW}$((i+1)). ${cert_list[i]}${NC}"
    done
    echo -e "${BLUE}──────────────────────────────────────────────────────────────${NC}"
    echo -e "${CYAN}Opciones:${NC}"
    echo -e "  ${YELLOW}a) Eliminar todos los certificados${NC}"
    echo -e "  ${YELLOW}s) Seleccionar certificados para eliminar${NC}"
    echo -e "  ${YELLOW}n) No eliminar ningún certificado${NC}"
    echo -ne "${CYAN}Selecciona una opción [a/s/n]: ${NC}"
    read -n 1 choice
    echo ""

    case "$choice" in
        a|A)
            echo -e "${YELLOW}🗑 Eliminando todos los certificados...${NC}"
            for cert in "${cert_list[@]}"; do
                certbot delete --cert-name "$cert" &>> "$LOG_FILE"
                if [ $? -eq 0 ]; then
                    status "Eliminado certificado: $cert"
                else
                    echo -e "${YELLOW}⚠ Error al eliminar certificado: $cert${NC}"
                    log_message "WARNING" "Error al eliminar certificado $cert"
                fi
            done
            ;;
        s|S)
            echo -e "${CYAN}Selecciona los certificados a eliminar (números separados por espacios, ej: 1 3):${NC}"
            read -r selections
            for index in $selections; do
                if [[ "$index" =~ ^[0-9]+$ ]] && [ "$index" -ge 1 ] && [ "$index" -le "${#cert_list[@]}" ]; then
                    cert="${cert_list[$((index-1))]}"
                    certbot delete --cert-name "$cert" &>> "$LOG_FILE"
                    if [ $? -eq 0 ]; then
                        status "Eliminado certificado: $cert"
                    else
                        echo -e "${YELLOW}⚠ Error al eliminar certificado: $cert${NC}"
                        log_message "WARNING" "Error al eliminar certificado $cert"
                    fi
                else
                    echo -e "${RED}✘ Selección inválida: $index${NC}"
                    log_message "ERROR" "Selección inválida de certificado: $index"
                fi
            done
            ;;
        n|N|*)
            echo -e "${GREEN}✔ No se eliminaron certificados${NC}"
            log_message "INFO" "Usuario eligió no eliminar certificados"
            ;;
    esac

    # Limpiar directorios de Let's Encrypt obsoletos
    for dir in /etc/letsencrypt/live/*; do
        if [ -d "$dir" ] && ! certbot certificates 2>/dev/null | grep -q "$(basename "$dir")"; then
            rm -rf "$dir"
            status "Eliminado directorio de certificado obsoleto: $dir"
        fi
    done
}

# Función para limpiar configuración
clear_setup() {
    clear_screen
    echo -e "${YELLOW}🧹 Limpiando configuración anterior${NC}"
    progress_bar "Eliminando archivos antiguos" 2

    [ -f "$SETUP_MARKER" ] && rm -f "$SETUP_MARKER" && status "Eliminado marcador de instalación"
    parent_dir=$(dirname "$SETUP_MARKER")
    [ -d "$parent_dir" ] && [ -z "$(ls -A "$parent_dir")" ] && rmdir "$parent_dir"

    if [ "$USE_DOCKER" = false ]; then
        local sites_disabled=false
        # Remove all ART-One related Apache configuration files
        for fname in "$APACHE_CONF_DIR"/*.conf; do
            if [ -f "$fname" ] && { grep -q "DocumentRoot /var/www/html/artone" "$fname" || grep -q "SSLCertificateFile /etc/letsencrypt/live" "$fname"; } 2>/dev/null; then
                site=$(basename "$fname" .conf)
                a2dissite "$site" &>/dev/null && sites_disabled=true
                rm -f "$fname"
                rm -f "$APACHE_ENABLED_DIR/$site.conf" 2>/dev/null
                status "Eliminada configuración: $fname"
            fi
        done

        # Ensure all enabled site links are removed
        for fname in "$APACHE_ENABLED_DIR"/*.conf; do
            if [ -L "$fname" ]; then
                site=$(basename "$fname" .conf)
                a2dissite "$site" &>/dev/null && sites_disabled=true
                rm -f "$fname"
                status "Eliminado enlace de sitio habilitado: $fname"
            fi
        done

        if $sites_disabled; then
            # Validate Apache configuration before reloading
            apache2ctl configtest &>> "$LOG_FILE"
            if [ $? -eq 0 ]; then
                systemctl restart apache2 && status "Apache reiniciado" || { echo -e "${RED}✘ Error al reiniciar Apache${NC}"; log_message "ERROR" "Fallo al reiniciar Apache"; exit 1; }
            else
                echo -e "${YELLOW}⚠ Configuración de Apache inválida, intentando corregir${NC}"
                # Remove all enabled sites to recover
                rm -f "$APACHE_ENABLED_DIR"/*.conf
                systemctl restart apache2 && status "Apache reiniciado tras corrección" || { echo -e "${RED}✘ Error crítico al reiniciar Apache${NC}"; log_message "ERROR" "Fallo crítico al reiniciar Apache"; exit 1; }
            fi
        fi

        [ -d "$PROJECT_DEST" ] && rm -rf "$PROJECT_DEST" && status "Eliminado directorio de despliegue"
        [ -f "/var/www/html/robots.txt" ] && rm -f "/var/www/html/robots.txt" && status "Eliminado robots.txt"

        handle_letsencrypt_certificates
    fi

    if [ "$USE_DOCKER" = true ]; then
        echo -e "${YELLOW}🧹 Eliminando contenedores e imágenes Docker relacionados con ART-One${NC}"
        local containers
        containers=$(docker ps -a -q -f name=artone)
        if [ -n "$containers" ]; then
            for container in $containers; do
                docker stop "$container" &>> "$LOG_FILE" && status "Contenedor detenido: $container" || echo -e "${YELLOW}⚠ No se pudo detener el contenedor: $container${NC}"
                docker rm "$container" &>> "$LOG_FILE" && status "Contenedor eliminado: $container" || echo -e "${YELLOW}⚠ No se pudo eliminar el contenedor: $container${NC}"
            done
        else
            echo -e "${GREEN}✔ No se encontraron contenedores Docker con nombre 'artone'${NC}"
            log_message "INFO" "No se encontraron contenedores Docker relacionados con ART-One"
        fi
        docker rmi "$DOCKER_IMAGE_NAME" &>> "$LOG_FILE" && status "Imagen Docker eliminada: $DOCKER_IMAGE_NAME" || echo -e "${YELLOW}⚠ No se pudo eliminar la imagen: $DOCKER_IMAGE_NAME${NC}"
    fi
}

# Función para desinstalar
uninstall() {
    clear_screen
    echo -e "${CYAN}🗑 Desinstalando ART-One Ver. $VERSION${NC}"
    confirm_action "🚨 ¿Confirmar desinstalación completa?" || { echo -e "${RED}Desinstalación cancelada.${NC}"; log_message "INFO" "Desinstalación cancelada por el usuario"; exit 0; }
    progress_bar "Desinstalando" 2

    # Limpiar configuraciones existentes (incluye eliminación de contenedor e imagen si USE_DOCKER=true)
    clear_setup

    # Eliminar todos los contenedores Docker relacionados con ART-One
    echo -e "${YELLOW}🧹 Eliminando contenedores Docker relacionados con ART-One${NC}"
    local containers
    containers=$(docker ps -a -q -f name=artone)
    if [ -n "$containers" ]; then
        for container in $containers; do
            docker stop "$container" &>> "$LOG_FILE" && status "Contenedor detenido: $container" || echo -e "${YELLOW}⚠ No se pudo detener el contenedor: $container${NC}"
            docker rm "$container" &>> "$LOG_FILE" && status "Contenedor eliminado: $container" || echo -e "${YELLOW}⚠ No se pudo eliminar el contenedor: $container${NC}"
        done
    else
        echo -e "${GREEN}✔ No se encontraron contenedores Docker con nombre 'artone'${NC}"
        log_message "INFO" "No se encontraron contenedores Docker relacionados con ART-One"
    fi

    # Eliminar todas las imágenes Docker relacionadas con ART-One
    echo -e "${YELLOW}🧹 Eliminando imágenes Docker relacionadas con ART-One${NC}"
    local images
    images=$(docker images -q -f reference='artone*' | sort -u)
    if [ -n "$images" ]; then
        for image in $images; do
            docker rmi "$image" &>> "$LOG_FILE" && status "Imagen eliminada: $image" || echo -e "${YELLOW}⚠ No se pudo eliminar la imagen: $image${NC}"
        done
    else
        echo -e "${GREEN}✔ No se encontraron imágenes Docker con nombre 'artone*'${NC}"
        log_message "INFO" "No se encontraron imágenes Docker relacionadas con ART-One"
    fi

    # Eliminar entorno virtual
    [ -d "$VENV_DIR" ] && rm -rf "$VENV_DIR" && status "Eliminado entorno virtual"

    # Eliminar script de configuración
    [ -f "/etc/artone/setup.sh" ] && rm -f "/etc/artone/setup.sh" && status "Eliminado setup.sh"
    parent_dir=$(dirname "/etc/artone/setup.sh")
    [ -d "$parent_dir" ] && [ -z "$(ls -A "$parent_dir")" ] && rmdir "$parent_dir" && status "Eliminado directorio /etc/artone"

    # Eliminar comando artone
    [ -f "/usr/local/bin/artone" ] && rm -f "/usr/local/bin/artone" && status "Eliminado comando artone"

    # Eliminar log de instalación
    [ -f "$LOG_FILE" ] && rm -f "$LOG_FILE" && status "Eliminado log de instalación"

    # Eliminar base de datos
    [ -f "$PROJECT_DIR/artone.db" ] && rm -f "$PROJECT_DIR/artone.db" && status "Eliminada base de datos artone.db"

    clear_screen
    echo -e "${GREEN}✔ Desinstalación completada${NC}"
    echo -e "${BLUE}──────────────────────────────────────────────────────────────${NC}"
    echo -e "${CYAN}Notas:${NC}"
    echo -e "  - Todos los archivos, configuraciones, contenedores e imágenes relacionados con ART-One han sido eliminados."
    echo -e "  - Reinstala ejecutando el script nuevamente."
    echo -e "${BLUE}──────────────────────────────────────────────────────────────${NC}"
    log_message "INFO" "Desinstalación completada"
    exit 0
}

# Función para configurar entorno virtual (non-Docker)
setup_venv() {
    clear_screen
    echo -e "${YELLOW}⚙ Configurando entorno virtual${NC}"
    progress_bar "Preparando entorno" 1

    apt-get install -y python3-venv
    status "Instalado python3-venv"

    [ ! -d "$VENV_DIR" ] && python3 -m venv "$VENV_DIR" && status "Creado entorno virtual"

    source "$VENV_DIR/bin/activate"
    progress_bar "Actualizando pip" 1
    pip install --upgrade pip
    status "Actualizado pip"

    progress_bar "Instalando dependencias" 2
    pip install $PYTHON_DEPS
    status "Instaladas dependencias"
    deactivate
}

# Función para configurar dominio
configure_domain() {
    clear_screen
    echo -e "${CYAN}🌐 Configurando dominio${NC}"
    echo -e "${BLUE}──────────────────────────────────────────────────────────────${NC}"
    if [ -z "$DOMAIN" ]; then
        while true; do
            echo -e "${CYAN}Introduce el dominio (predeterminado: $DEFAULT_DOMAIN):${NC}"
            read -p "Dominio: " input_domain
            input_domain=${input_domain:-$DEFAULT_DOMAIN}
            if validate_domain "$input_domain"; then
                DOMAIN="$input_domain"
                break
            else
                echo -e "${RED}🚫 Dominio inválido. Usa el formato 'dominio.com'.${NC}"
                log_message "ERROR" "Dominio inválido ingresado: $input_domain"
            fi
        done
    elif ! validate_domain "$DOMAIN"; then
        echo -e "${RED}🚫 Dominio proporcionado inválido: $DOMAIN${NC}"
        log_message "ERROR" "Dominio proporcionado inválido: $DOMAIN"
        exit 1
    fi
    echo -e "${GREEN}✔ Dominio seleccionado: $DOMAIN${NC}"
    check_dns "$DOMAIN"
    echo -e "${BLUE}──────────────────────────────────────────────────────────────${NC}"
    log_message "INFO" "Dominio configurado: $DOMAIN"
    sleep 2
}

# Función para verificar archivos del proyecto
check_project_files() {
    clear_screen
    echo -e "${YELLOW}🔍 Verificando archivos del proyecto${NC}"
    echo -e "${BLUE}──────────────────────────────────────────────────────────────${NC}"

    local missing_files=0
    if [ ! -f "$PROJECT_DIR/server" ]; then
        echo -e "${RED}✘ Falta server en $PROJECT_DIR${NC}"
        log_message "ERROR" "Falta server en $PROJECT_DIR"
        ((missing_files++))
    else
        echo -e "${GREEN}✔ server encontrado${NC}"
        log_message "INFO" "server encontrado en $PROJECT_DIR"
    fi

    if [ ! -d "$PROJECT_DIR/templates" ]; then
        echo -e "${RED}✘ Falta directorio templates/ en $PROJECT_DIR${NC}"
        log_message "ERROR" "Falta directorio templates/ en $PROJECT_DIR"
        ((missing_files++))
    else
        echo -e "${GREEN}✔ Directorio templates/ encontrado${NC}"
        log_message "INFO" "Directorio templates/ encontrado en $PROJECT_DIR"
    fi

    if [ ! -d "$PROJECT_DIR/source" ]; then
        echo -e "${RED}✘ Falta directorio source/ en $PROJECT_DIR${NC}"
        log_message "ERROR" "Falta directorio source/ en $PROJECT_DIR"
        ((missing_files++))
    else
        echo -e "${GREEN}✔ Directorio source/ encontrado${NC}"
        log_message "INFO" "Directorio source/ encontrado en $PROJECT_DIR"
    fi

    if [ $missing_files -gt 0 ]; then
        echo -e "${RED}🚫 Faltan $missing_files archivos/directorios necesarios en $PROJECT_DIR${NC}"
        echo -e "${YELLOW}Asegúrate de que server, templates/ y source/ estén presentes.${NC}"
        exit 1
    fi

    # Verificar permisos
    if [ ! -r "$PROJECT_DIR/server" ] || [ ! -r "$PROJECT_DIR/templates" ] || [ ! -r "$PROJECT_DIR/source" ]; then
        echo -e "${RED}✘ Permisos insuficientes en los archivos/directorios de $PROJECT_DIR${NC}"
        echo -e "${YELLOW}Ejecuta: sudo chmod -R u+r $PROJECT_DIR${NC}"
        log_message "ERROR" "Permisos insuficientes en $PROJECT_DIR"
        exit 1
    fi
    echo -e "${GREEN}✔ Permisos de archivos verificados${NC}"
    log_message "INFO" "Permisos de archivos verificados en $PROJECT_DIR"
}

# Función para configurar Docker
setup_docker() {
    clear_screen
    echo -e "${YELLOW}🐳 Configurando ART-One en Docker${NC}"
    echo -e "${BLUE}──────────────────────────────────────────────────────────────${NC}"

    # Verificar archivos del proyecto
    check_project_files

    # Descargar imagen base ubuntu:20.04
    progress_bar "Descargando imagen base ubuntu:20.04" 3
    docker pull ubuntu:20.04 >> "$LOG_FILE" 2>&1
    if [ $? -ne 0 ]; then
        echo -e "${RED}✘ Error al descargar la imagen ubuntu:20.04${NC}"
        echo -e "${YELLOW}Verifica la conexión a internet y el acceso a Docker Hub.${NC}"
        log_message "ERROR" "Fallo al descargar ubuntu:20.04"
        exit 1
    fi
    status "Imagen base ubuntu:20.04 descargada"

    # Crear directorio temporal para Docker build context
    local temp_dir="/tmp/artone_docker"
    rm -rf "$temp_dir"
    mkdir -p "$temp_dir"
    if ! cp -r "$PROJECT_DIR/." "$temp_dir/"; then
        echo -e "${RED}✘ Error al copiar archivos a $temp_dir${NC}"
        log_message "ERROR" "Fallo al copiar archivos a $temp_dir"
        exit 1
    fi
    status "Archivos copiados al directorio temporal"

    # Crear y configurar artone.db en el directorio temporal
    progress_bar "Creando base de datos artone.db para Docker" 1
    DB_FILE="$temp_dir/artone.db"
    sqlite3 "$DB_FILE" <<EOF
CREATE TABLE IF NOT EXISTS config (
    key TEXT PRIMARY KEY,
    value TEXT
);
INSERT OR REPLACE INTO config (key, value) VALUES ('SERVER_IP', '$DOMAIN');
EOF
    [ $? -eq 0 ] && status "Base de datos artone.db creada y SERVER_IP configurado a $DOMAIN" || { echo -e "${RED}✘ Error al crear artone.db${NC}"; log_message "ERROR" "Fallo al crear artone.db"; exit 1; }

    # Crear Dockerfile
    local dockerfile="$temp_dir/Dockerfile"
    cat > "$dockerfile" << EOF
FROM ubuntu:20.04

# Configurar variables de entorno para evitar interacciones
ENV DEBIAN_FRONTEND=noninteractive

# Instalar dependencias del sistema
RUN apt-get update && apt-get install -y \
    python3 \
    python3-pip \
    apache2 \
    libapache2-mod-wsgi-py3 \
    netcat-traditional \
    lsof \
    curl \
    && rm -rf /var/lib/apt/lists/*

# Configurar directorio de trabajo
WORKDIR /app
COPY . /app

# Instalar dependencias de Python
RUN pip3 install --no-cache-dir $PYTHON_DEPS

# Copiar archivos del proyecto
RUN mkdir -p /var/www/html/artone
COPY server /var/www/html/artone/
COPY templates /var/www/html/artone/templates/
COPY source /var/www/html/artone/source/
COPY artone.db /var/www/html/artone/artone.db

# Configurar Apache
RUN a2enmod wsgi
COPY artone.conf /etc/apache2/sites-available/$DOMAIN.conf
RUN a2ensite $DOMAIN
RUN echo "User-agent: *\nDisallow: /" > /var/www/html/robots.txt
RUN chown -R www-data:www-data /var/www/html/artone /var/www/html/robots.txt
RUN chmod -R 755 /var/www/html/artone
RUN chmod 644 /var/www/html/robots.txt

# Configurar WSGI
RUN echo "import sys\nsys.path.insert(0, '/var/www/html/artone')\nfrom server import app as application" > /var/www/html/artone/app.wsgi
RUN chown www-data:www-data /var/www/html/artone/app.wsgi
RUN chmod 644 /var/www/html/artone/app.wsgi

# Exponer puertos
EXPOSE 80 4135 8443

# Comando de inicio
CMD ["/usr/sbin/apache2ctl", "-D", "FOREGROUND"]
EOF
    status "Creado Dockerfile"

    # Crear archivo de configuración de Apache
    local apache_conf="$temp_dir/artone.conf"
    cat > "$apache_conf" << EOF
<VirtualHost *:80>
    ServerName $DOMAIN
    DocumentRoot /var/www/html/artone
    WSGIScriptAlias / /var/www/html/artone/app.wsgi
    <Directory /var/www/html/artone>
        Options -Indexes
        AllowOverride None
        Require all granted
    </Directory>
    <Directory /var/www/html/artone/templates>
        Require all denied
    </Directory>
    ErrorLog \${APACHE_LOG_DIR}/error.log
    CustomLog \${APACHE_LOG_DIR}/access.log combined
</VirtualHost>
EOF
    status "Creado archivo de configuración de Apache"

    # Verificar permisos del directorio temporal
    chmod -R u+rw "$temp_dir"
    status "Permisos del directorio temporal ajustados"

    # Cambiar al directorio temporal
    cd "$temp_dir" || { echo -e "${RED}✘ Error al cambiar al directorio temporal $temp_dir${NC}"; log_message "ERROR" "No se pudo cambiar al directorio temporal"; exit 1; }

    # Construir imagen Docker con salida detallada
    progress_bar "Construyendo imagen Docker" 5
    docker build --no-cache -t "$DOCKER_IMAGE_NAME" . > "$LOG_FILE.build" 2>&1
    if [ $? -ne 0 ]; then
        echo -e "${RED}✘ Error al construir la imagen Docker${NC}"
        echo -e "${YELLOW}Consulta $LOG_FILE.build para detalles específicos del error.${NC}"
        echo -e "${YELLOW}Posibles causas:${NC}"
        echo -e "${YELLOW}- Problemas de red al descargar dependencias (verifica la conexión a internet).${NC}"
        echo -e "${YELLOW}- Permisos insuficientes en Docker (ejecuta: sudo usermod -aG docker \$USER y reinicia la sesión).${NC}"
        echo -e "${YELLOW}- Archivos faltantes o corruptos en $temp_dir (verifica server, templates/, source/).${NC}"
        echo -e "${YELLOW}- Versión incompatible de dependencias Python ($PYTHON_DEPS).${NC}"
        echo -e "${YELLOW}- Espacio en disco insuficiente o recursos limitados.${NC}"
        log_message "ERROR" "Fallo al construir la imagen Docker. Detalles en $LOG_FILE.build"
        cat "$LOG_FILE.build" >> "$LOG_FILE"
        exit 1
    fi
    status "Imagen Docker construida"
    rm -f "$LOG_FILE.build"

    # Verificar que la imagen existe
    if ! docker images -q "$DOCKER_IMAGE_NAME" | grep -q .; then
        echo -e "${RED}✘ Error: No se creó la imagen Docker${NC}"
        echo -e "${YELLOW}Consulta $LOG_FILE para más detalles. Verifica el Dockerfile y los permisos de Docker.${NC}"
        log_message "ERROR" "No se creó la imagen Docker"
        exit 1
    fi
    status "Imagen Docker verificada"

    # Limpiar archivos temporales
    cd - || { echo -e "${RED}✘ Error al volver al directorio original${NC}"; log_message "ERROR" "No se pudo volver al directorio original"; exit 1; }
    rm -rf "$temp_dir"
    status "Archivos temporales eliminados"

    # Copiar setup.sh a /etc/artone/
    SETUP_SCRIPT_DEST="/etc/artone/setup.sh"
    mkdir -p "$(dirname "$SETUP_SCRIPT_DEST")"
    cp "$SCRIPT_DIR/setup.sh" "$SETUP_SCRIPT_DEST"
    chmod 755 "$SETUP_SCRIPT_DEST"
    status "Copiado setup.sh a $SETUP_SCRIPT_DEST"

    # Crear comando artone para Docker
    cat > /usr/local/bin/artone << EOF
#!/bin/bash
SETUP_SCRIPT="/etc/artone/setup.sh"

# Procesar argumentos
while [ \$# -gt 0 ]; do
    case "\$1" in
        -h|--help)
            sudo "\$SETUP_SCRIPT" -h
            exit 0
            ;;
        -u)
            sudo "\$SETUP_SCRIPT" -u
            exit 0
            ;;
        -a)
            sudo "\$SETUP_SCRIPT" -a
            exit 0
            ;;
        *)
            echo "Opción inválida: \$1"
            echo "Uso: artone [-h|-u|-a]"
            exit 1
            ;;
    esac
done

# Iniciar el contenedor si no hay opciones
if ! docker ps -q -f name="$DOCKER_CONTAINER_NAME" | grep -q .; then
    # Iniciar el contenedor si no está corriendo
    docker run -d --name "$DOCKER_CONTAINER_NAME" \\
        -p 80:80 -p 4135:4135 -p 8443:8443 \\
        -v /etc/letsencrypt:/etc/letsencrypt:ro \\
        "$DOCKER_IMAGE_NAME"
    if [ \$? -ne 0 ]; then
        echo "Error al iniciar el contenedor. Verifica los logs con: docker logs $DOCKER_CONTAINER_NAME"
        exit 1
    fi
fi
# Mostrar mensaje de inicio
echo "ART-One está corriendo en el contenedor $DOCKER_CONTAINER_NAME"
echo "Accede al panel en: http://$DOMAIN:4135/login"
echo "Revisa logs con: docker logs $DOCKER_CONTAINER_NAME"
EOF
    chmod +x /usr/local/bin/artone
    status "Creado comando artone para Docker"
}

# Función para realizar el setup (sin Docker)
run_setup() {
    clear_screen
    echo -e "${YELLOW}🚀 Configurando ART-One Enterprise C2${NC}"
    echo -e "${BLUE}──────────────────────────────────────────────────────────────${NC}"
    echo -e "${CYAN}Dominio:${NC} $DOMAIN"
    confirm_action "🔧 ¿Iniciar configuración con dominio $DOMAIN?" || { echo -e "${RED}Configuración cancelada.${NC}"; log_message "INFO" "Configuración cancelada por el usuario"; exit 0; }

    progress_bar "Actualizando sistema" 2
    apt-get update -y && apt-get upgrade -y
    status "Sistema actualizado"

    progress_bar "Instalando paquetes" 2
    apt-get install -y apache2 ufw libapache2-mod-wsgi-py3 certbot python3-certbot-apache sqlite3 netcat-traditional lsof curl
    status "Paquetes instalados"

    progress_bar "Limpiando configuraciones antiguas de Apache" 1
    # Clean up all ART-One related Apache configurations
    for fname in "$APACHE_CONF_DIR"/*.conf; do
        if [ -f "$fname" ] && { grep -q "DocumentRoot /var/www/html/artone" "$fname" || grep -q "SSLCertificateFile /etc/letsencrypt/live" "$fname"; } 2>/dev/null; then
            site=$(basename "$fname" .conf)
            a2dissite "$site" &>/dev/null
            rm -f "$fname"
            rm -f "$APACHE_ENABLED_DIR/$site.conf" 2>/dev/null
            status "Eliminada configuración antigua: $fname"
        fi
    done
    # Remove all enabled site links
    rm -f "$APACHE_ENABLED_DIR"/*.conf
    # Restart Apache to ensure a clean state
    apache2ctl configtest &>> "$LOG_FILE"
    if [ $? -eq 0 ]; then
        systemctl restart apache2 && status "Apache reiniciado" || { echo -e "${RED}✘ Error al reiniciar Apache${NC}"; log_message "ERROR" "Fallo al reiniciar Apache"; exit 1; }
    else
        echo -e "${YELLOW}⚠ Configuración de Apache inválida, intentando corregir${NC}"
        systemctl restart apache2 && status "Apache reiniciado tras corrección" || { echo -e "${RED}✘ Error crítico al reiniciar Apache${NC}"; log_message "ERROR" "Fallo crítico al reiniciar Apache"; exit 1; }
    fi

    progress_bar "Configurando Apache" 1
    a2enmod wsgi ssl proxy proxy_http
    systemctl start apache2
    status "Apache configurado"

    conf_file="$APACHE_CONF_DIR/$DOMAIN.conf"
    cat > "$conf_file" << EOF
<VirtualHost *:80>
    ServerName $DOMAIN
    DocumentRoot /var/www/html/
    <Directory $PROJECT_DEST>
        Options -Indexes
    </Directory>
    <Directory $PROJECT_DEST/templates>
        Require all denied
    </Directory>
    ErrorLog \${APACHE_LOG_DIR}/error.log
    CustomLog \${APACHE_LOG_DIR}/access.log combined
</VirtualHost>
EOF
    a2ensite "$DOMAIN"
    apache2ctl configtest &>> "$LOG_FILE"
    if [ $? -eq 0 ]; then
        systemctl reload apache2 && status "Configuración inicial de Apache" || { echo -e "${RED}✘ Error al recargar Apache${NC}"; log_message "ERROR" "Fallo al recargar Apache"; exit 1; }
    else
        echo -e "${RED}✘ Configuración de Apache inválida: $conf_file${NC}"
        log_message "ERROR" "Configuración de Apache inválida para $DOMAIN"
        rm -f "$conf_file"
        rm -f "$APACHE_ENABLED_DIR/$DOMAIN.conf"
        systemctl restart apache2 && status "Apache reiniciado tras corrección" || { echo -e "${RED}✘ Error crítico al reiniciar Apache${NC}"; log_message "ERROR" "Fallo crítico al reiniciar Apache"; exit 1; }
        exit 1
    fi

    progress_bar "Verificando certificados SSL" 3
# Verificar si ya existe un certificado para el dominio
if [ -d "/etc/letsencrypt/live/$DOMAIN" ]; then
    echo -e "${YELLOW}⚠ Se encontró un certificado existente para $DOMAIN${NC}"
    echo -ne "${CYAN}¿Desea renovar el certificado? [s/n]: ${NC}"
    read -n 1 renew_choice
    echo ""
    if [[ "$renew_choice" =~ ^[Ss]$ ]]; then
        echo -e "${YELLOW}🔄 Renovando certificado para $DOMAIN...${NC}"
        certbot renew --cert-name "$DOMAIN" &>> "$LOG_FILE"
        if [ $? -eq 0 ]; then
            status "Certificado renovado"
        else
            echo -e "${YELLOW}⚠ Error al renovar el certificado. Continuando con el certificado existente...${NC}"
            log_message "WARNING" "Fallo al renovar el certificado para $DOMAIN"
        fi
    else
        echo -e "${YELLOW}⚠ No se renovará el certificado. Continuando con HTTP...${NC}"
        log_message "INFO" "Usuario eligió no renovar el certificado para $DOMAIN"
        # Configurar Apache para HTTP
        a2dissite "$DOMAIN" &>/dev/null
        rm -f "$conf_file"
        rm -f "$APACHE_ENABLED_DIR/$DOMAIN.conf"
        cat > "$conf_file" << EOF
<VirtualHost *:80>
    ServerName $DOMAIN
    DocumentRoot /var/www/html/
    <Directory $PROJECT_DEST>
        Options -Indexes
    </Directory>
    <Directory $PROJECT_DEST/templates>
        Require all denied
    </Directory>
    ErrorLog \${APACHE_LOG_DIR}/error.log
    CustomLog \${APACHE_LOG_DIR}/access.log combined
</VirtualHost>
EOF
        a2ensite "$DOMAIN"
        apache2ctl configtest &>> "$LOG_FILE"
        if [ $? -eq 0 ]; then
            systemctl reload apache2 && status "Configuración HTTP actualizada (sin SSL)" || { echo -e "${RED}✘ Error al recargar Apache con HTTP${NC}"; log_message "ERROR" "Fallo al recargar Apache con HTTP"; exit 1; }
        else
            echo -e "${RED}✘ Configuración HTTP inválida${NC}"
            log_message "ERROR" "Configuración HTTP inválida para $DOMAIN"
            rm -f "$conf_file"
            rm -f "$APACHE_ENABLED_DIR/$DOMAIN.conf"
            systemctl restart apache2 && status "Apache reiniciado tras corrección" || { echo -e "${RED}✘ Error crítico al reiniciar Apache${NC}"; log_message "ERROR" "Fallo crítico al reiniciar Apache"; exit 1; }
            exit 1
        fi
        # Continuar con el resto de la configuración
        continue
    fi
else
    # Generar un nuevo certificado si no existe
    certbot --apache -d "$DOMAIN" --non-interactive --agree-tos --email admin@$DOMAIN && \
    certbot install --cert-name "$DOMAIN"
    if [ $? -eq 0 ]; then
        status "Certificados SSL generados"
        cat > "$conf_file" << EOF
<VirtualHost *:80>
    ServerName $DOMAIN
    Redirect permanent / https://$DOMAIN/
    <Directory $PROJECT_DEST>
        Options -Indexes
    </Directory>
    <Directory $PROJECT_DEST/templates>
        Require all denied
    </Directory>
    ErrorLog \${APACHE_LOG_DIR}/error.log
    CustomLog \${APACHE_LOG_DIR}/access.log combined
</VirtualHost>
<VirtualHost *:443>
    ServerName $DOMAIN
    DocumentRoot /var/www/html/
    SSLEngine on
    SSLCertificateFile /etc/letsencrypt/live/$DOMAIN/fullchain.pem
    SSLCertificateKeyFile /etc/letsencrypt/live/$DOMAIN/privkey.pem
    SSLProtocol TLSv1.3
    <Directory $PROJECT_DEST>
        Options -Indexes
    </Directory>
    <Directory $PROJECT_DEST/templates>
        Require all denied
    </Directory>
    ErrorLog \${APACHE_LOG_DIR}/error.log
    CustomLog \${APACHE_LOG_DIR}/access.log combined
</VirtualHost>
EOF
        a2ensite "$DOMAIN"
        apache2ctl configtest &>> "$LOG_FILE"
        if [ $? -eq 0 ]; then
            systemctl reload apache2 && status "Configuración HTTPS actualizada" || { echo -e "${RED}✘ Error al recargar Apache con HTTPS${NC}"; log_message "ERROR" "Fallo al recargar Apache con HTTPS"; exit 1; }
        else
            echo -e "${YELLOW}⚠ Configuración HTTPS inválida, revirtiendo a HTTP${NC}"
            rm -f "$conf_file"
            rm -f "$APACHE_ENABLED_DIR/$DOMAIN.conf"
            cat > "$conf_file" << EOF
<VirtualHost *:80>
    ServerName $DOMAIN
    DocumentRoot /var/www/html/
    <Directory $PROJECT_DEST>
        Options -Indexes
    </Directory>
    <Directory $PROJECT_DEST/templates>
        Require all denied
    </Directory>
    ErrorLog \${APACHE_LOG_DIR}/error.log
    CustomLog \${APACHE_LOG_DIR}/access.log combined
</VirtualHost>
EOF
            a2ensite "$DOMAIN"
            systemctl reload apache2
            status "Configuración HTTP actualizada (sin SSL)"
        fi
    else
        echo -e "${YELLOW}⚠ Error al generar SSL. Continuando con HTTP...${NC}"
        log_message "WARNING" "Fallo al generar certificados SSL para $DOMAIN"
        a2dissite "$DOMAIN" &>/dev/null
        rm -f "$conf_file"
        rm -f "$APACHE_ENABLED_DIR/$DOMAIN.conf"
        cat > "$conf_file" << EOF
<VirtualHost *:80>
    ServerName $DOMAIN
    DocumentRoot /var/www/html/
    <Directory $PROJECT_DEST>
        Options -Indexes
    </Directory>
    <Directory $PROJECT_DEST/templates>
        Require all denied
    </Directory>
    ErrorLog \${APACHE_LOG_DIR}/error.log
    CustomLog \${APACHE_LOG_DIR}/access.log combined
</VirtualHost>
EOF
        a2ensite "$DOMAIN"
        apache2ctl configtest &>> "$LOG_FILE"
        if [ $? -eq 0 ]; then
            systemctl reload apache2 && status "Configuración HTTP actualizada (sin SSL)" || { echo -e "${RED}✘ Error al recargar Apache con HTTP${NC}"; log_message "ERROR" "Fallo al recargar Apache con HTTP"; exit 1; }
        else
            echo -e "${RED}✘ Configuración HTTP inválida${NC}"
            log_message "ERROR" "Configuración HTTP inválida para $DOMAIN"
            rm -f "$conf_file"
            rm -f "$APACHE_ENABLED_DIR/$DOMAIN.conf"
            systemctl restart apache2 && status "Apache reiniciado tras corrección" || { echo -e "${RED}✘ Error crítico al reiniciar Apache${NC}"; log_message "ERROR" "Fallo crítico al reiniciar Apache"; exit 1; }
            exit 1
        fi
    fi
fi

    # Crear y configurar artone.db
    progress_bar "Creando base de datos artone.db" 1
    DB_FILE="$PROJECT_DIR/artone.db"
    sqlite3 "$DB_FILE" <<EOF
CREATE TABLE IF NOT EXISTS config (
    key TEXT PRIMARY KEY,
    value TEXT
);
INSERT OR REPLACE INTO config (key, value) VALUES ('SERVER_IP', '$DOMAIN');
EOF
    [ $? -eq 0 ] && status "Base de datos artone.db creada y SERVER_IP configurado a $DOMAIN" || { echo -e "${RED}✘ Error al crear artone.db${NC}"; log_message "ERROR" "Fallo al crear artone.db"; exit 1; }

    templates_src="$PROJECT_DIR/templates"
    source_src="$PROJECT_DIR/source"
    server_py_src="$PROJECT_DIR/server"
    templates_dest="$PROJECT_DEST/templates"
    source_dest="$PROJECT_DEST/source"

    [ ! -d "$templates_src" ] && mkdir -p "$templates_dest" && echo -e "${YELLOW}⚠ Creando directorio templates vacío${NC}"
    [ ! -d "$source_src" ] && mkdir -p "$source_dest" && echo -e "${YELLOW}⚠ Creando directorio source vacío${NC}"
    [ ! -f "$server_py_src" ] && { echo -e "${RED}🚫 Falta server en $PROJECT_DIR${NC}"; log_message "ERROR" "Falta server en $PROJECT_DIR"; exit 1; }

    progress_bar "Desplegando recursos" 2
    [ -d "$PROJECT_DEST" ] && rm -rf "$PROJECT_DEST"
    mkdir -p "$PROJECT_DEST"
    [ -d "$templates_src" ] && cp -r "$templates_src" "$templates_dest" && status "Copiados templates"
    [ -d "$source_src" ] && cp -r "$source_src" "$source_dest" && status "Copiados source"
    cp "$server_py_src" "$PROJECT_DEST/server" && status "Copiado server"
    mv "$DB_FILE" "$PROJECT_DEST/artone.db" && status "Movida base de datos artone.db"

    wsgi_file="$PROJECT_DEST/app.wsgi"
    cat > "$wsgi_file" << EOF
import sys
sys.path.insert(0, '$PROJECT_DEST')
from server import app as application
EOF
    chown www-data:www-data "$wsgi_file"
    chmod 644 "$wsgi_file"
    status "Creado app.wsgi"

    robots="/var/www/html/robots.txt"
    cat > "$robots" << EOF
User-agent: *
Disallow: /
EOF
    chown www-data:www-data "$robots"
    chmod 644 "$robots"
    status "Creado robots.txt"

    chown -R www-data:www-data "$PROJECT_DEST"
    chmod -R 755 "$PROJECT_DEST"
    status "Permisos ajustados"

    if [ -d "/etc/letsencrypt/live/$DOMAIN" ]; then
        progress_bar "Configurando permisos SSL" 1
        cert_files=(
            "/etc/letsencrypt/live/$DOMAIN/fullchain.pem"
            "/etc/letsencrypt/live/$DOMAIN/cert.pem"
            "/etc/letsencrypt/live/$DOMAIN/chain.pem"
        )
        for cert_file in "${cert_files[@]}"; do
            [ -f "$cert_file" ] && chmod 644 "$cert_file" && chown www-data:www-data "$cert_file"
        done
        privkey="/etc/letsencrypt/live/$DOMAIN/privkey.pem"
        [ -f "$privkey" ] && chmod 600 "$privkey" && chown www-data:www-data "$privkey"
        letsencrypt_dirs=(
            "/etc/letsencrypt/live/"
            "/etc/letsencrypt/live/$DOMAIN/"
            "/etc/letsencrypt/archive/"
            "/etc/letsencrypt/archive/$DOMAIN/"
            "/etc/letsencrypt/"
        )
        for dir_path in "${letsencrypt_dirs[@]}"; do
            [ -d "$dir_path" ] && chmod 750 "$dir_path" && chown -R www-data:www-data "$dir_path"
        done
        privkey_files=$(find "/etc/letsencrypt/archive/$DOMAIN/" -name "privkey*.pem" 2>/dev/null)
        for privkey_file in $privkey_files; do
            chmod 600 "$privkey_file"
        done
        status "Permisos SSL configurados"
    fi

    progress_bar "Finalizando configuración" 1
    a2dismod proxy_http proxy
    apache2ctl configtest &>> "$LOG_FILE"
    if [ $? -eq 0 ]; then
        systemctl reload apache2 && status "Módulos proxy deshabilitados" || { echo -e "${RED}✘ Error al recargar Apache${NC}"; log_message "ERROR" "Fallo al recargar Apache"; exit 1; }
    else
        echo -e "${RED}✘ Configuración final de Apache inválida${NC}"
        log_message "ERROR" "Configuración final de Apache inválida para $DOMAIN"
        exit 1
    fi

    # Copiar setup.sh a /etc/artone/
    SETUP_SCRIPT_DEST="/etc/artone/setup.sh"
    mkdir -p "$(dirname "$SETUP_SCRIPT_DEST")"
    cp "$SCRIPT_DIR/setup.sh" "$SETUP_SCRIPT_DEST"
    chmod 755 "$SETUP_SCRIPT_DEST"
    status "Copiado setup.sh a $SETUP_SCRIPT_DEST"

    # Crear comando artone para non-Docker setup
    cat > /usr/local/bin/artone << EOF
#!/bin/bash
SETUP_SCRIPT="/etc/artone/setup.sh"

# Procesar argumentos
while [ $# -gt 0 ]; do
    case "$1" in
        -h|--help)
            sudo "$SETUP_SCRIPT" -h
            exit 0
            ;;
        -u)
            sudo "$SETUP_SCRIPT" -u
            exit 0
            ;;
        -a)
            sudo "$SETUP_SCRIPT" -a
            exit 0
            ;;
        *)
            echo "Opción inválida: $1"
            echo "Uso: artone [-h|-u|-a]"
            exit 1
            ;;
    esac
done

# Directorio del proyecto
PROJECT_DEST="/var/www/html/artone"

# Cambiar al directorio del proyecto
cd "\$PROJECT_DEST" || { echo "Error: No se pudo cambiar al directorio \$PROJECT_DEST"; exit 1; }

SERVER_BIN="\$PROJECT_DEST/server"
if [ ! -f "\$SERVER_BIN" ]; then
    echo "Error: El ejecutable \$SERVER_BIN no existe."
    exit 1
fi

# Ejecutar el binario
"\$SERVER_BIN"
EOF
    chmod +x /usr/local/bin/artone
    status "Creado comando artone"
}

# Función para mostrar diagnóstico final
display_diagnostics() {
    clear_screen
    echo -e "${YELLOW}🔍 Diagnósticos finales${NC}"
    echo -e "${BLUE}──────────────────────────────────────────────────────────────${NC}"
    if [ "$USE_DOCKER" = true ]; then
        docker ps -q -f name="$DOCKER_CONTAINER_NAME" >/dev/null && echo -e "${GREEN}✔ Contenedor Docker activo${NC}" || echo -e "${YELLOW}⚠ Contenedor Docker no activo (iniciará con 'sudo artone')${NC}"
        docker images -q "$DOCKER_IMAGE_NAME" | grep -q . && echo -e "${GREEN}✔ Imagen Docker creada${NC}" || echo -e "${RED}✘ Imagen Docker no creada${NC}"
    else
        systemctl is-active --quiet apache2 && echo -e "${GREEN}✔ Apache activo${NC}" || echo -e "${RED}✘ Apache no activo${NC}"
    fi
    for port in "${REQUIRED_PORTS[@]}"; do
        nc -z 127.0.0.1 $port 2>/dev/null && echo -e "${GREEN}✔ Puerto $port abierto${NC}" || echo -e "${YELLOW}⚠ Puerto $port cerrado${NC}"
    done
    [ -f "/usr/local/bin/artone" ] && echo -e "${GREEN}✔ Comando artone creado${NC}" || echo -e "${RED}✘ Comando artone no creado${NC}"
    if [ "$USE_DOCKER" = false ]; then
        [ -d "/etc/letsencrypt/live/$DOMAIN" ] && echo -e "${GREEN}✔ Certificados SSL generados${NC}" || echo -e "${YELLOW}⚠ Certificados SSL no generados${NC}"
    fi
    echo -e "${BLUE}──────────────────────────────────────────────────────────────${NC}"
    log_message "INFO" "Diagnósticos finales completados"
    sleep 3
}

# Función para mostrar resumen final
display_summary() {
    clear_screen
    echo -e "${GREEN}🎉 ART-One Ver. $VERSION instalado exitosamente${NC}"
    echo -e "${BLUE}──────────────────────────────────────────────────────────────${NC}"
    echo -e "${CYAN}Instrucciones:${NC}"
    echo -e "  - Inicia el servidor con: ${GREEN}sudo artone${NC}"
    echo -e "  - Accede al panel en: ${GREEN}http://$DOMAIN:4135/login${NC}"
    echo -e "  - Credenciales por defecto: ${RED}Usuario: admin / Contraseña: artone${NC}"
    echo -e "  - Log de instalación: ${GREEN}$LOG_FILE${NC}"
    if [ "$USE_DOCKER" = true ]; then
        echo -e "  - Revisa logs de Docker: ${GREEN}docker logs $DOCKER_CONTAINER_NAME${NC}"
        echo -e "  - Nota: Configura SSL en el host usando Certbot para habilitar HTTPS."
    else
        echo -e "  - Revisa logs de Apache: ${GREEN}sudo journalctl -xeu apache2.service${NC}"
    fi
    echo -e "  - Desinstala con: ${GREEN}sudo artone -u${NC}"
    echo -e "  - Actualiza con: ${GREEN}sudo artone -a${NC}"
    echo -e "${BLUE}──────────────────────────────────────────────────────────────${NC}"
    log_message "INFO" "Instalación completada exitosamente"
    exit 0
}

# Configurar logging
mkdir -p "$(dirname "$LOG_FILE")" || { echo -e "${RED}🚫 Error al crear directorio de log${NC}"; exit 1; }
touch "$LOG_FILE" || { echo -e "${RED}🚫 Error al crear archivo de log${NC}"; exit 1; }
echo "=== ART-One Setup Log - $(date) ===" > "$LOG_FILE"
exec 1> >(tee -a "$LOG_FILE")
exec 2> >(tee -a "$LOG_FILE" >&2)
log_message "INFO" "Inicio del script de configuración ART-One Ver. $VERSION"

# Configurar logging
mkdir -p "$(dirname "$LOG_FILE")" || { echo -e "${RED}🚫 Error al crear directorio de log${NC}"; exit 1; }
touch "$LOG_FILE" || { echo -e "${RED}🚫 Error al crear archivo de log${NC}"; exit 1; }
echo "=== ART-One Setup Log - $(date) ===" > "$LOG_FILE"
exec 1> >(tee -a "$LOG_FILE")
exec 2> >(tee -a "$LOG_FILE" >&2)
log_message "INFO" "Inicio del script de configuración ART-One Ver. $VERSION"

# Verificar permisos de sudo
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}🚫 Este script requiere permisos de superusuario. Ejecútalo con: sudo $0${NC}"
    exit 1
fi

# Parsear argumentos
while [ $# -gt 0 ]; do
    case "$1" in
        -h|--help)
            display_help
            ;;
        -d)
            if [ -n "$2" ] && [[ ! "$2" =~ ^- ]]; then
                DOMAIN="$2"
                shift 2
            else
                echo -e "${RED}🚫 El argumento -d requiere un dominio${NC}"
                display_help
            fi
            ;;
        -u)
            UNINSTALL=true
            shift
            ;;
        -a)
            UPDATE=true
            shift
            ;;
        --docker)
            USE_DOCKER=true
            shift
            ;;
        *)
            echo -e "${RED}🚫 Argumento inválido: $1${NC}"
            display_help
            ;;
    esac
done

# Validar combinaciones de argumentos
action_count=0
[ "$UNINSTALL" = true ] && ((action_count++))
[ "$UPDATE" = true ] && ((action_count++))
if [ $action_count -gt 1 ]; then
    echo -e "${RED}🚫 No se pueden combinar -u y -a${NC}"
    exit 1
fi

# Ejecutar desinstalación si se solicita
if [ "$UNINSTALL" = true ]; then
    uninstall
fi

# Mostrar y validar aceptación de términos y condiciones solo para instalación o actualización
if [ "$UNINSTALL" = false ]; then
    display_terms_and_conditions
fi

# Verificar instalación existente
if [ "$UNINSTALL" = false ] && [ "$UPDATE" = false ] && [ -f "$SETUP_MARKER" ]; then
    clear_screen
    echo -e "${YELLOW}⚠ ART-One Ver. $VERSION ya está instalado.${NC}"
    echo -e "${BLUE}──────────────────────────────────────────────────────────────${NC}"
    echo -e "Usa -u para desinstalar primero o -a para actualizar."
    echo -e "${BLUE}──────────────────────────────────────────────────────────────${NC}"
    log_message "WARNING" "Instalación existente detectada"
    exit 0
fi

# Ejecutar actualización si se solicita
if [ "$UPDATE" = true ]; then
    update_files
fi

# Verificar directorios y archivos
if [ ! -d "$PROJECT_DIR" ]; then
    clear_screen
    echo -e "${RED}🚫 El directorio $PROJECT_DIR no existe${NC}"
    log_message "ERROR" "El directorio $PROJECT_DIR no existe"
    exit 1
fi

# Limpiar configuraciones antiguas antes de la instalación
if [ "$USE_DOCKER" = false ] && [ "$UNINSTALL" = false ] && [ "$UPDATE" = false ]; then
    clear_screen
    echo -e "${YELLOW}🧹 Limpiando configuraciones antiguas antes de la instalación${NC}"
    progress_bar "Eliminando configuraciones antiguas" 2
    clear_setup
fi

# Verificar prerrequisitos
check_prerequisites

# Configurar dominio para instalación
if [ "$UNINSTALL" = false ] && [ "$UPDATE" = false ]; then
    configure_domain
fi

# Ejecutar instalación
if [ "$USE_DOCKER" = true ]; then
    setup_docker
else
    setup_venv
    run_setup
fi
display_diagnostics
display_summary
